// Bug hunt 2026-11-10 (newb): the bell after an aircraft is grounded a second time.
// Demo: mark N208MA grounded in its profile, mark the alert read, return it to
// service, ground it again. REPRODUCED (exit 1) while the second grounding
// shows as already read (no unread badge); NOT REPRODUCED (exit 0) once fixed.
const { chromium } = require("playwright");
const BASE = process.env.ANGELONE_URL || "http://127.0.0.1:4400";

async function setProfile(page, status) {
  await page.evaluate(async (status) => {
    await new Promise((resolve, reject) => {
      const request = indexedDB.open("angel-one-v1");
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const db = request.result;
        const tx = db.transaction("snapshots", "readwrite");
        const cursor = tx.objectStore("snapshots").openCursor();
        cursor.onsuccess = () => {
          const entry = cursor.result;
          if (!entry) return;
          const s = entry.value;
          const a = (s.aircraft || []).find((x) => x.registration === "N208MA");
          if (a) a.operationalStatus = status;
          entry.update(s);
          entry.continue();
        };
        tx.oncomplete = () => { db.close(); resolve(); };
        tx.onerror = () => reject(tx.error);
      };
    });
  }, status);
  await page.goto(BASE + "/alerts");
  await page.getByRole("heading", { name: "What needs attention." }).waitFor();
  await page.waitForTimeout(500);
}
const bell = (page) => page.locator("a.alert-bell").getAttribute("aria-label");
const row = (page) => page.locator(".mx-alert-row", { hasText: "N208MA is grounded" });

(async () => {
  let browser;
  try { browser = await chromium.launch(); } catch { browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" }); }
  const page = await (await browser.newContext()).newPage();
  await page.addInitScript(() => sessionStorage.setItem("angel-one-demo", "true"));
  await page.goto(BASE + "/alerts");
  await page.getByRole("heading", { name: "What needs attention." }).waitFor();
  await setProfile(page, "grounded");
  console.log("grounded #1:", await bell(page), "| row:", (await row(page).innerText()).split("\n")[0]);
  await page.getByRole("button", { name: "Mark read: N208MA is grounded" }).click();
  await page.waitForTimeout(300);
  const before = await bell(page);
  await setProfile(page, "airworthy");
  console.log("returned to service:", await bell(page), "| rows:", await row(page).count());
  await setProfile(page, "grounded");
  const after = await bell(page);
  const text = (await row(page).innerText()).split("\n")[0];
  console.log("grounded #2:", after, "| row:", text);
  await page.screenshot({ path: "shots/newb-bell-regrounded.png" });
  await browser.close();
  if (text.startsWith("Read:") && after === before) {
    console.log("REPRODUCED: the second grounding of N208MA is shown as already read; bell says '" + after + "'");
    process.exit(1);
  }
  console.log("NOT REPRODUCED");
})().catch((e) => { console.error(e); process.exit(2); });
