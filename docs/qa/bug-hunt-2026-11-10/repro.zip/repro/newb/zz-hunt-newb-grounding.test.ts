/**
 * Responsibility: Bug-hunt 2026-11-10 repro (area newb): an aircraft grounded
 *   by an open grounding discrepancy, or by an expired deferral, must reach
 *   people as an urgent alert and in the digest. Asserts the CORRECT
 *   behaviour and fails today.
 * Layer: Test. convex-test suite with a stubbed Resend; never shipped.
 * Dependencies: convex/urgentAlerts.ts, convex/alerts.ts,
 *   src/domain/alerts.ts, tests/fixtures/alertProgram.ts.
 */
import { afterEach, expect, it, vi } from "vitest";
import { api, internal } from "./_generated/api";
import { computeAlerts } from "../src/domain/alerts";
import { localDate } from "../src/domain/model";
import {
  DEMO_PROGRAM,
  seedAlertProgram,
  sentEmails,
  stubResend,
  type AlertWorld,
} from "../tests/fixtures/alertProgram";

afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
  vi.useRealTimers();
});

async function groundByDiscrepancy(world: AlertWorld) {
  await world.t.run(async (ctx) => {
    // No other urgent alert: the seeded inspection is far from due.
    for (const i of await ctx.db.query("inspections").collect())
      await ctx.db.patch(i._id, { dueDate: "2999-01-01" });
    await ctx.db.insert("discrepancies", {
      uuid: "22222222-2222-4222-8222-222222222222",
      aircraftUuid: world.ids.aircraftUuid,
      description: "Nose gear oleo flat after landing",
      status: "open",
      authorId: world.ids.reader.userId,
      createdAt: Date.now(),
      grounding: true,
    });
  });
}

it("NB-13: the bell shows the aircraft grounded by an open grounding discrepancy (control)", async () => {
  const world = await seedAlertProgram();
  await groundByDiscrepancy(world);
  const snapshot = await world.a.query(api.operations.snapshot, {});
  const alerts = computeAlerts(snapshot!, localDate());
  expect(alerts.map((a) => a.title)).toContain("N206MA is grounded");
});

it("NB-13: an aircraft grounded by an open grounding discrepancy is emailed at once", async () => {
  const world = await seedAlertProgram();
  await groundByDiscrepancy(world);
  const request = stubResend();
  const result = await world.t.action(internal.urgentAlerts.sendImmediate, {
    programUuid: DEMO_PROGRAM,
  });
  expect(sentEmails(request).map((e) => e.text).join("\n")).toContain(
    "N206MA is grounded",
  );
  expect(result).toMatchObject({ sent: 1 });
});

it("NB-13: the daily digest lists an aircraft grounded by an open grounding discrepancy", async () => {
  const world = await seedAlertProgram();
  await groundByDiscrepancy(world);
  const request = stubResend();
  await world.t.action(internal.alerts.sendDigests, {});
  expect(sentEmails(request).map((e) => e.text).join("\n")).toContain(
    "N206MA is grounded",
  );
});

it("NB-13: a grounding problem report synced by a pilot emails the program administrator within the scheduled check", async () => {
  const world = await seedAlertProgram();
  vi.useFakeTimers();
  await world.t.run(async (ctx) => {
    for (const i of await ctx.db.query("inspections").collect())
      await ctx.db.patch(i._id, { dueDate: "2999-01-01" });
    // Let the reader report problems, as a pilot group does.
    const reader = await ctx.db.get(world.ids.reader.userId);
    await ctx.db.patch(reader!.groupIds![0], {
      permissions: ["read", "flight", "discrepancy"],
    });
  });
  const request = stubResend();
  await world.reader.mutation(api.operations.submit, {
    operation: {
      programUuid: DEMO_PROGRAM,
      kind: "discrepancy",
      uuid: crypto.randomUUID(),
      authorId: world.ids.reader.userId,
      aircraftUuid: world.ids.aircraftUuid,
      description: "Nose gear oleo flat after landing",
      grounding: true,
    },
  });
  await world.t.finishAllScheduledFunctions(vi.runAllTimers);
  const stored = await world.t.run((ctx) =>
    ctx.db.query("discrepancies").collect(),
  );
  expect(stored.map((d) => d.grounding)).toEqual([true]);
  expect(sentEmails(request).map((e) => e.subject)).toEqual([
    "Mission operations: 1 urgent alert",
  ]);
});
