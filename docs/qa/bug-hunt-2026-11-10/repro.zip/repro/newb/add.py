"""Appends one finding (JSON on stdin) to findings/newb.jsonl after validating it."""
import json, sys, os
H = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
f = json.load(sys.stdin)
base = {"area": "newb", "regression_of": None, "needs_owner_decision": False, "notes": ""}
base.update(f)
need = ["id","area","title","severity","kind","steps","expected","actual","evidence","repro","suspect","confidence","regression_of","needs_owner_decision","notes"]
missing = [k for k in need if k not in base]
assert not missing, missing
with open(os.path.join(H, "findings", "newb.jsonl"), "a") as out:
    out.write(json.dumps(base, ensure_ascii=False) + "\n")
print("added", base["id"])
