/**
 * Responsibility: Bug-hunt 2026-11-10 repros (area newb), lower severity: the
 *   weekly summary's day boundary and push subscriptions a push service
 *   refuses for good. Each test asserts the CORRECT behaviour.
 * Layer: Test. convex-test suite with a stubbed push service; never shipped.
 * Dependencies: convex/auditHistory.ts, convex/push.ts,
 *   src/domain/auditSummary.ts, tests/fixtures/alertProgram.ts.
 */
import { afterEach, expect, it, vi } from "vitest";
import { api, internal } from "./_generated/api";
import { toBase64Url } from "./webPushProtocol";
import { summaryPeriod } from "../src/domain/auditSummary";
import { DEMO_PROGRAM, seedAlertProgram } from "../tests/fixtures/alertProgram";

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

it("NB-15: 'Last 7 days' includes a change made this evening west of UTC", async () => {
  const { a, ids } = await seedAlertProgram();
  vi.useFakeTimers({ toFake: ["Date"] });
  // 20:00 on 10 Nov in New York.
  vi.setSystemTime(new Date("2026-11-11T01:00:00Z"));
  await a.mutation(api.expiringItems.save, {
    programUuid: DEMO_PROGRAM,
    payload: JSON.stringify({
      action: "save",
      item: {
        uuid: "11111111-1111-4111-8111-111111111111",
        programUuid: DEMO_PROGRAM,
        kind: "insurance",
        label: "Hull",
        expiresOn: "2030-01-31",
        aircraftUuid: ids.aircraftUuid,
        version: 0,
      },
    }),
  });
  // What the Weekly summary tab asks for on that device (localDate() there
  // is 2026-11-10).
  const period = summaryPeriod("7d", "2026-11-10");
  const { summary } = await a.query(api.auditHistory.summary, {
    programUuid: DEMO_PROGRAM,
    ...period,
  });
  expect(summary.total).toBe(1);
});

it("NB-16: a subscription the push service refuses for good (403 after a VAPID key change) is not retried on every check", async () => {
  const world = await seedAlertProgram();
  vi.useFakeTimers();
  const pair = await crypto.subtle.generateKey(
    { name: "ECDSA", namedCurve: "P-256" },
    true,
    ["sign", "verify"],
  );
  vi.stubEnv(
    "VAPID_PUBLIC_KEY",
    toBase64Url(
      new Uint8Array(await crypto.subtle.exportKey("raw", pair.publicKey)),
    ),
  );
  vi.stubEnv(
    "VAPID_PRIVATE_KEY",
    (await crypto.subtle.exportKey("jwk", pair.privateKey)).d!,
  );
  vi.stubEnv("VAPID_SUBJECT", "mailto:alerts@example.test");
  await world.a.mutation(api.pushSubscriptions.subscribe, {
    programUuid: DEMO_PROGRAM,
    endpoint: "https://push.example.test/x",
    keys: {
      p256dh:
        "BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4",
      auth: "BTBZMqHH6r4Tts7J_aSIgg",
    },
  });
  const request = vi
    .fn<typeof fetch>()
    .mockImplementation(async () => new Response(null, { status: 403 }));
  vi.stubGlobal("fetch", request);
  const error = vi.spyOn(console, "error").mockImplementation(() => {});
  for (let i = 0; i < 5; i++) {
    await world.t.action(internal.urgentAlerts.sendImmediate, {
      programUuid: DEMO_PROGRAM,
    });
    await world.t.finishAllScheduledFunctions(vi.runAllTimers);
  }
  error.mockRestore();
  // Five saves in the program: at most one or two attempts, then the dead
  // subscription is dropped or parked.
  expect(request.mock.calls.length).toBeLessThan(5);
});

it("NB-17: one program's unreadable record does not stop the other programs' digests", async () => {
  const { stubResend, sentEmails } = await import(
    "../tests/fixtures/alertProgram"
  );
  const { t } = await seedAlertProgram();
  // A stored expiring date that no longer matches its schema, in the first
  // program only.
  await t.run((ctx) =>
    ctx.db.insert("expiringItems", {
      uuid: "44444444-4444-4444-8444-444444444444",
      programUuid: DEMO_PROGRAM,
      payload: JSON.stringify({ label: "from an older release" }),
    }),
  );
  const request = stubResend();
  const error = vi.spyOn(console, "error").mockImplementation(() => {});
  await t.action(internal.alerts.sendDigests, {}).catch(() => undefined);
  error.mockRestore();
  expect(sentEmails(request).map((e) => e.to[0])).toContain(
    "other@example.test",
  );
});

it("NB-19: one transient provider error does not leave an urgent alert unsent until the next change or the next day", async () => {
  const { stubResend, sentEmails } = await import(
    "../tests/fixtures/alertProgram"
  );
  const { t } = await seedAlertProgram();
  vi.useFakeTimers();
  stubResend();
  // Resend answers 503 once, then recovers.
  let calls = 0;
  const request = vi.fn<typeof fetch>().mockImplementation(async () => {
    calls++;
    return new Response("{}", { status: calls === 1 ? 503 : 200 });
  });
  vi.stubGlobal("fetch", request);
  const error = vi.spyOn(console, "error").mockImplementation(() => {});
  await t.action(internal.urgentAlerts.sendImmediate, {
    programUuid: DEMO_PROGRAM,
  });
  // Let an hour pass with no other change in the program.
  vi.advanceTimersByTime(3_600_000);
  await t.finishAllScheduledFunctions(vi.runAllTimers);
  error.mockRestore();
  expect(sentEmails(request).length).toBeGreaterThan(1);
});
