# Repros for area "newb" (alerts, urgent email, Web Push, expiring dates, weekly summary, crons)

Server repros are vitest files that assert the correct behaviour, so they fail today.
From a clean checkout:

    cp <H>/repro/newb/zz-hunt-newb-*.test.ts convex/
    npx vitest run convex/zz-hunt-newb-urgent.test.ts      # NB-1, NB-2, NB-3, NB-4
    npx vitest run convex/zz-hunt-newb-push.test.ts        # NB-5, NB-5b, NB-6, NB-7, NB-8, NB-2 (push)
    npx vitest run convex/zz-hunt-newb-history.test.ts     # NB-9, NB-10, NB-11 (tests NB-11 and NB-12)
    npx vitest run convex/zz-hunt-newb-grounding.test.ts   # NB-13 (first test is a passing control)
    npx vitest run convex/zz-hunt-newb-low.test.ts         # NB-15, NB-16, NB-17, NB-19
    rm convex/zz-hunt-newb-*.test.ts

`vitest-output.txt` is the result on commit 73e51a9 (21 failing, 1 passing control).

Browser repros (demo app on ANGELONE_URL, default http://127.0.0.1:4400):

    node <H>/repro/newb/sw-push-cards.cjs      # NB-14, exits 1 while reproduced
    node <H>/repro/newb/bell-regrounded.cjs    # NB-18, exits 1 while reproduced

`add.py` only appended findings to findings/newb.jsonl; it is not a repro.
There is no finding NB-12: that number is the second test of NB-11.
