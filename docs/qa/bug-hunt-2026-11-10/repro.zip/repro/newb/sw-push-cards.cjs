// Bug hunt 2026-11-10 (newb): the service worker's push cards.
// Delivers two push messages for one program through Chromium's DevTools
// protocol and counts the notification cards the worker shows.
// REPRODUCED (exit 1) while a second message for the same program adds a
// second card instead of replacing the first; NOT REPRODUCED (exit 0) once fixed.
const { chromium } = require("playwright");
const BASE = process.env.ANGELONE_URL || "http://127.0.0.1:4400";

(async () => {
  let browser;
  try {
    browser = await chromium.launch();
  } catch {
    browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" });
  }
  const context = await browser.newContext();
  await context.grantPermissions(["notifications"], { origin: BASE });
  const page = await context.newPage();
  await page.addInitScript(() => sessionStorage.setItem("angel-one-demo", "true"));
  await page.goto(BASE + "/");
  const registrationId = await page.evaluate(async () => {
    const reg = await navigator.serviceWorker.ready;
    return reg.scope;
  });
  const cdp = await context.newCDPSession(page);
  await cdp.send("ServiceWorker.enable");
  const versions = await new Promise((resolve) => {
    cdp.on("ServiceWorker.workerRegistrationUpdated", (e) => {
      if (e.registrations.length) resolve(e.registrations);
    });
  });
  const reg = versions.find((r) => r.scopeURL.startsWith(BASE));
  const push = (payload) =>
    cdp.send("ServiceWorker.deliverPushMessage", {
      origin: BASE,
      registrationId: reg.registrationId,
      data: JSON.stringify(payload),
    });
  await push({ title: "Mission operations: 1 urgent alert", body: "N206MA is grounded", url: "/alerts" });
  await push({ title: "Mission operations: 2 urgent alerts", body: "N206MA is grounded\nInspection overdue: Annual", url: "/alerts" });
  await page.waitForTimeout(1000);
  const cards = await page.evaluate(async () => {
    const r = await navigator.serviceWorker.ready;
    return (await r.getNotifications()).map((n) => ({ title: n.title, tag: n.tag, data: n.data }));
  });
  console.log(JSON.stringify(cards, null, 1), registrationId);
  await browser.close();
  if (cards.length > 1) {
    console.log("REPRODUCED: " + cards.length + " cards for one program; the tag carries the count, so a newer message does not replace the older");
    process.exit(1);
  }
  console.log("NOT REPRODUCED");
})().catch((e) => { console.error(e); process.exit(2); });
