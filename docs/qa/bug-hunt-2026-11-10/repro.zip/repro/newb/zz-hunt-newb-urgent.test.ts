/**
 * Responsibility: Bug-hunt 2026-11-10 repros (area newb) for urgent alerts and
 *   the digest: each test asserts the CORRECT behaviour and fails today.
 * Layer: Test. convex-test suite with a stubbed Resend; never shipped.
 * Dependencies: convex/urgentAlerts.ts, convex/alerts.ts,
 *   tests/fixtures/alertProgram.ts.
 */
import { afterEach, expect, it, vi } from "vitest";
import { internal } from "./_generated/api";
import { IMMEDIATE_EMAILS_PER_DAY } from "./urgentAlerts";
import {
  DEMO_PROGRAM,
  seedAlertProgram,
  sentEmails,
  stubResend,
  type AlertWorld,
} from "../tests/fixtures/alertProgram";

const inProgram = { programUuid: DEMO_PROGRAM };

afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
  vi.useRealTimers();
});

const sendImmediate = (t: AlertWorld["t"]) =>
  t.action(internal.urgentAlerts.sendImmediate, inProgram);
const setInspectionDue = (t: AlertWorld["t"], dueDate: string) =>
  t.run(async (ctx) => {
    for (const i of await ctx.db.query("inspections").collect())
      await ctx.db.patch(i._id, { dueDate });
  });
const setProfile = (
  t: AlertWorld["t"],
  uuid: string,
  operationalStatus: "grounded" | "airworthy",
) =>
  t.run(async (ctx) => {
    const a = (await ctx.db.query("aircraft").collect()).find(
      (x) => x.uuid === uuid,
    )!;
    await ctx.db.patch(a._id, { operationalStatus } as never);
  });

it("NB-1: a failed send does not spend the day's immediate emails", async () => {
  const { t } = await seedAlertProgram();
  stubResend(503);
  const error = vi.spyOn(console, "error").mockImplementation(() => {});
  for (let i = 0; i < IMMEDIATE_EMAILS_PER_DAY; i++)
    expect(await sendImmediate(t)).toMatchObject({ sent: 0, failed: 1 });
  error.mockRestore();
  // Resend recovers; nothing was ever delivered today.
  const request = stubResend(200);
  expect(await sendImmediate(t)).toMatchObject({ sent: 1, capped: 0 });
  expect(request).toHaveBeenCalledTimes(1);
});

it("NB-2: an urgent alert that cleared and came back is emailed again", async () => {
  const { t, ids } = await seedAlertProgram();
  // Start with no other urgent alert in the program.
  await setInspectionDue(t, "2999-01-01");
  const request = stubResend();
  await setProfile(t, ids.aircraftUuid, "grounded");
  expect(await sendImmediate(t)).toMatchObject({ sent: 1 });
  expect(sentEmails(request)[0].text).toContain("N206MA is grounded");
  // Returned to service: the alert clears.
  await setProfile(t, ids.aircraftUuid, "airworthy");
  expect(await sendImmediate(t)).toMatchObject({ sent: 0 });
  // Grounded again weeks later: the same reason, so the same key.
  await setProfile(t, ids.aircraftUuid, "grounded");
  expect(await sendImmediate(t)).toMatchObject({ sent: 1 });
  expect(request).toHaveBeenCalledTimes(2);
});

it("NB-3: a digest alert that cleared and came back is emailed again", async () => {
  const { t, ids } = await seedAlertProgram();
  await setInspectionDue(t, "2999-01-01");
  const request = stubResend();
  await setProfile(t, ids.aircraftUuid, "grounded");
  expect(await t.action(internal.alerts.sendDigests, {})).toMatchObject({
    sent: 1,
  });
  await setProfile(t, ids.aircraftUuid, "airworthy");
  expect(await t.action(internal.alerts.sendDigests, {})).toMatchObject({
    sent: 0,
  });
  await setProfile(t, ids.aircraftUuid, "grounded");
  expect(await t.action(internal.alerts.sendDigests, {})).toMatchObject({
    sent: 1,
  });
  expect(request).toHaveBeenCalledTimes(2);
});

it("NB-4: no 'overdue' or 'grounded' email on the due date itself, in the evening west of UTC", async () => {
  const { t } = await seedAlertProgram();
  // 20:00 on 10 Nov in New York (UTC-5) is 01:00 UTC on 11 Nov.
  vi.useFakeTimers({ toFake: ["Date"] });
  vi.setSystemTime(new Date("2026-11-11T01:00:00Z"));
  await setInspectionDue(t, "2026-11-10");
  const request = stubResend();
  const result = await sendImmediate(t);
  // GLOSSARY "Overdue": a calendar limit is overdue from the day AFTER its
  // due date. On the device it is still 10 Nov: due soon, airworthy.
  expect(sentEmails(request).map((e) => e.text)).toEqual([]);
  expect(result).toMatchObject({ sent: 0 });
});
