/**
 * Responsibility: Bug-hunt 2026-11-10 repros (area newb) for expiring dates
 *   in Change history: each test asserts the CORRECT behaviour.
 * Layer: Test. convex-test suite; never shipped.
 * Dependencies: convex/expiringItems.ts, convex/auditHistory.ts,
 *   convex/operations.ts, tests/fixtures/alertProgram.ts.
 */
import { expect, it } from "vitest";
import { api, internal } from "./_generated/api";
import { DEMO_PROGRAM, seedAlertProgram } from "../tests/fixtures/alertProgram";

const inProgram = { programUuid: DEMO_PROGRAM };
const item = (patch: object = {}) => ({
  uuid: "11111111-1111-4111-8111-111111111111",
  programUuid: DEMO_PROGRAM,
  kind: "insurance",
  label: "Hull policy 4471-SECRET",
  note: "Broker login is in the safe",
  expiresOn: "2030-01-31",
  version: 0,
  ...patch,
});
const save = (i: object) => ({
  ...inProgram,
  payload: JSON.stringify({ action: "save", item: i }),
});
const today = () => new Date().toISOString().slice(0, 10);

it("NB-9: a member without administrator permission cannot read an aircraft's expiring date through Change history", async () => {
  const { a, reader, ids } = await seedAlertProgram();
  await a.mutation(
    api.expiringItems.save,
    save(item({ aircraftUuid: ids.aircraftUuid })),
  );
  // The snapshot keeps the list from the reader...
  const snapshot = await reader.query(api.operations.snapshot, {});
  expect(snapshot?.expiringItems).toEqual([]);
  // ...and so must the snapshot's change log and the history page.
  const page = await reader.query(api.auditHistory.page, {
    ...inProgram,
    cursor: null,
    numItems: 50,
  });
  const leaked = [...(snapshot?.audit ?? []), ...page.page].filter((e) =>
    JSON.stringify(e).includes("4471-SECRET"),
  );
  expect(leaked.map((e) => e.action)).toEqual([]);
});

it("NB-10: an administrator finds a program's expiring-date change in Change history and its weekly summary", async () => {
  const { a } = await seedAlertProgram();
  await a.mutation(api.expiringItems.save, save(item()));
  const page = await a.query(api.auditHistory.page, {
    ...inProgram,
    cursor: null,
    numItems: 50,
  });
  expect(page.page.map((e) => e.action)).toContain("expiring-date.saved");
  const { summary } = await a.query(api.auditHistory.summary, {
    ...inProgram,
    from: today(),
    to: today(),
  });
  expect(summary.total).toBe(1);
});

it("NB-11: the weekly summary counts a refused sign-in the server really recorded", async () => {
  const { t, a } = await seedAlertProgram();
  // What convex/identities.ts writes when an SSO sign-in is refused.
  await t.mutation(internal.identities.recordRefusal, {
    provider: "google",
    providerAccountId: "1234567890",
    email: "stranger@example.test",
    reason: "no_account",
  });
  const rows = await t.run((ctx) => ctx.db.query("audit").collect());
  expect(rows.map((r) => r.action)).toEqual(["user.sign_in_refused"]);
  const { summary } = await a.query(api.auditHistory.summary, {
    ...inProgram,
    from: today(),
    to: today(),
  });
  expect(summary.refusedSignIns).toBe(1);
});

it("NB-12: the weekly summary lists a permission change made in the program as a notable event", async () => {
  const { t, a } = await seedAlertProgram();
  await a.mutation(api.admin.saveGroup, {
    ...inProgram,
    name: "Mechanics",
    aircraftIds: [],
    allAircraft: true,
    permissions: ["read", "maintenance"],
  });
  const rows = await t.run((ctx) => ctx.db.query("audit").collect());
  expect(rows.map((r) => [r.action, r.programUuid])).toEqual([
    ["group.saved", DEMO_PROGRAM],
  ]);
  const { summary } = await a.query(api.auditHistory.summary, {
    ...inProgram,
    from: today(),
    to: today(),
  });
  expect(summary.notable.map((n) => n.kind)).toEqual(["permission-change"]);
  expect(summary.families.access).toBe(1);
});
