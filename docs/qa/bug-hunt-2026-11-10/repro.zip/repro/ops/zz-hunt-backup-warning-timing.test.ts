/**
 * Responsibility: OP-5 repro. The stale-backup warning is only evaluated by the
 *   daily digest (13:00 UTC, convex/crons.ts) while the backup runs at 08:41 UTC
 *   (.github/workflows/backup.yml), so one missed night is never reported.
 * Layer: Test. Copy to src/domain/ and run
 *   `npx vitest run src/domain/zz-hunt-backup-warning-timing.test.ts`.
 * Dependencies: src/domain/offsiteBackups.ts.
 */
import { describe, expect, it } from "vitest";
import { offsiteFreshness } from "./offsiteBackups";

const utc = (text: string) => Date.parse(text);

describe("stale off-site backup warning against the real schedules", () => {
  // Monday's backup succeeded at 08:45 UTC. Tuesday's 08:41 run failed.
  const lastGoodCopy = { completedAt: utc("2026-11-16T08:45:00Z") };

  it("warns in the first digest after a missed nightly backup", () => {
    const tuesdayDigest = utc("2026-11-17T13:00:00Z");
    // Fails today: the copy is 28 h 15 min old, under the 36-hour limit, so the
    // digest says nothing although last night's backup did not happen.
    expect(offsiteFreshness(lastGoodCopy, tuesdayDigest).status).toBe("stale");
  });

  it("characterizes current behaviour: the first warning is 52 hours after the last good copy", () => {
    const wednesdayDigest = utc("2026-11-18T13:00:00Z");
    expect(offsiteFreshness(lastGoodCopy, wednesdayDigest)).toEqual({
      status: "stale",
      message:
        "No off-site backup for 2 days. Check the Nightly backup job in GitHub Actions.",
    });
  });
});
