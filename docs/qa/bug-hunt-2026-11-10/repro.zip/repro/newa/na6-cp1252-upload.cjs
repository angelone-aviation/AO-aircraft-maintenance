// NA-6: a setup CSV saved by Excel as "CSV (Comma delimited)" is Windows-1252.
// The wizard decodes every upload as UTF-8, so non-ASCII characters become
// U+FFFD and are planned for saving with no error or warning.
// Run: node na6-cp1252-upload.cjs
const { start, BASE, result } = require("./lib.cjs");
const HEAD = "name,interval_hours,interval_months,interval_cycles,interval_landings,last_done_date,last_done_hours,last_done_cycles,last_done_landings,manual_reference";
(async () => {
  const { browser, page } = await start();
  await page.goto(`${BASE}/aircraft/setup/demo-206?step=inspections`);
  // Windows-1252 bytes for: Inspección anual ... §91.409 – 12 mo
  const cp1252 = Buffer.concat([
    Buffer.from(HEAD + "\r\nInspecci"), Buffer.from([0xf3]), Buffer.from("n anual,,12,,,2026-03-15,,,,"),
    Buffer.from([0xa7]), Buffer.from("91.409 "), Buffer.from([0x96]), Buffer.from(" 12 mo\r\n"),
  ]);
  await page.getByLabel("Inspections CSV file").setInputFiles({ name: "inspection-setup.csv", mimeType: "text/csv", buffer: cp1252 });
  const table = page.locator("table[aria-label='Inspections rows']");
  await table.waitFor();
  const row = (await table.locator("tbody tr").first().innerText()).replace(/\s+/g, " ");
  const alerts = await page.locator("[role=alert]").allInnerTexts();
  await page.goto(`${BASE}/aircraft/setup/demo-206?step=review`);
  await page.getByRole("heading", { name: "Review (dry run)" }).waitFor();
  const review = (await page.locator(".setup-panel").innerText()).replace(/\s+/g, " ");
  console.log("parsed row:", row);
  console.log("alerts on the step:", JSON.stringify(alerts));
  console.log("review mentions a problem:", /Fix before saving|Check\b.*encoding|�.*(warning|check)/i.test(review));
  await browser.close();
  result(row.includes("�") && alerts.length === 0 && /To save.*Inspections 1 0/i.test(review.replace(/\t/g, " ")),
    "a Windows-1252 CSV is accepted with U+FFFD in the inspection name and manual reference, and planned for saving without a warning");
})();
