/**
 * Responsibility: Hunt repro NA-13 (sibling of NA-1): a component template
 *   CSV without the optional ID column gets positional row ids ("1", "2").
 *   "Already applied to this aircraft" is keyed on that id, so after the
 *   template is edited with a row inserted above, the new row inherits an
 *   applied id and is silently skipped when the template is applied again.
 * Layer: Test. Copy to src/domain/ and run
 *   `npx vitest run src/domain/zz-hunt-newa-template-row-ids.test.ts`.
 * Dependencies: src/domain/componentTemplates.ts, src/data/demo.ts.
 */
import { expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import {
  applyComponentTemplate,
  parseComponentTemplateCsv,
  saveComponentTemplate,
} from "./componentTemplates";

const HEADER = "Component type,ATA chapter,Part number,Component Name";
const FIRST = `${HEADER}\nEngine,72,IO-520-F,Engine\nPropeller,61,D3A34C401,Propeller`;
// The administrator adds the magnetos at the top of the list and re-imports.
const EDITED = `${HEADER}\nAppliance,74,10-500556-101,Left magneto\nEngine,72,IO-520-F,Engine\nPropeller,61,D3A34C401,Propeller`;

it("recommends a row added to a template when the template is applied again", () => {
  const s = demoSnapshot();
  const a = s.aircraft[0];
  const t = saveComponentTemplate(s, {
    uuid: crypto.randomUUID(),
    version: 0,
    name: "C206 components",
    make: a.make,
    model: a.model,
    rows: parseComponentTemplateCsv(FIRST),
  });
  applyComponentTemplate(s, {
    templateUuid: t.uuid,
    version: t.version,
    aircraftUuid: a.uuid,
    rowIds: t.rows.map((r) => r.id),
  });
  const edited = saveComponentTemplate(s, {
    uuid: t.uuid,
    version: t.version,
    name: t.name,
    make: a.make,
    model: a.model,
    rows: parseComponentTemplateCsv(EDITED),
  });
  // Apply only the new row, as a person would after seeing it in the preview.
  const magneto = edited.rows.find((r) => r.model === "Left magneto")!;
  const added = applyComponentTemplate(s, {
    templateUuid: edited.uuid,
    version: edited.version,
    aircraftUuid: a.uuid,
    rowIds: [magneto.id],
  });
  expect(added.map((d) => d.row.model)).toEqual(["Left magneto"]);
});
