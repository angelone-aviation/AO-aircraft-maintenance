/**
 * Responsibility: Hunt repro NA-18: the records package mixes UTC and local
 *   dates without saying which. A Form 337 copy uploaded on the evening of
 *   31 Oct (US Central) is listed as "Uploaded 2026-11-01 02:00" beside the
 *   package file "form-337/2026-10-31-...", and discrepancy "Reported" /
 *   "Resolved" times are UTC under headings that do not say so.
 * Layer: Test. Copy to src/domain/ and run
 *   `TZ=America/Chicago npx vitest run src/domain/zz-hunt-newa-package-dates.test.ts`.
 * Dependencies: src/domain/recordsPackage.ts, src/data/demo.ts.
 */
import { expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import { buildRecordsPackage } from "./recordsPackage";

// 31 Oct 2026 21:00 in Chicago (CDT, UTC-5).
const EVENING = Date.parse("2026-11-01T02:00:00Z");

it("dates one event the same way everywhere, or labels the zone", () => {
  const s = demoSnapshot();
  s.aircraftFiles = [
    {
      uuid: "f1",
      aircraftUuid: "demo-206",
      category: "form-337",
      name: "337.pdf",
      type: "application/pdf",
      size: 1000,
      uploadedAt: EVENING,
      url: "data:application/pdf;base64,AA==",
    },
  ];
  s.discrepancies = [
    {
      uuid: "d1",
      aircraftUuid: "demo-206",
      description: "Nav light inoperative",
      status: "open",
      authorId: "demo-admin",
      createdAt: EVENING,
    },
  ] as never;
  const pkg = buildRecordsPackage(s, "demo-206", "2026-11-10", {
    entries: [],
    complete: true,
  });
  const copies = pkg.sections.find((x) => x.id === "form337Copies")!;
  const reports = pkg.sections.find((x) => x.id === "discrepancies")!;
  const uploaded = copies.rows[0][copies.columns.indexOf("Uploaded")];
  const path = copies.rows[0][copies.columns.indexOf("Package file")];
  const reportedHeading = reports.columns[0];
  const reported = reports.rows[0][0];
  const pathDate = /form-337\/(\d{4}-\d{2}-\d{2})-/.exec(path)![1];
  expect({
    uploadedAgreesWithPath: uploaded.startsWith(pathDate),
    reportedSaysItsZone:
      /UTC/.test(reportedHeading) || /UTC|Z$/.test(reported),
  }).toEqual({ uploadedAgreesWithPath: true, reportedSaysItsZone: true });
});
