/**
 * Responsibility: Hunt repro NA-8: the records package leaves out the logbook
 *   page photos (signed-page and flight-line photos) kept on the aircraft.
 * Layer: Test. Copy to src/domain/ and run
 *   `npx vitest run src/domain/zz-hunt-newa-package-photos.test.ts`.
 * Dependencies: src/domain/recordsPackage.ts, src/data/demo.ts.
 */
import { expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import { buildRecordsPackage, recordsReadme } from "./recordsPackage";

it("carries or at least lists the aircraft's logbook page photos", () => {
  const s = demoSnapshot();
  s.aircraftFiles = [
    {
      uuid: "photo-1",
      aircraftUuid: "demo-206",
      category: "logbook-page",
      linkedKind: "work-order",
      linkedUuid: "wo-1",
      name: "signed-annual-page.jpg",
      type: "image/jpeg",
      size: 1000,
      uploadedAt: Date.parse("2026-11-01T12:00:00Z"),
      url: "data:image/jpeg;base64,AA==",
    },
  ];
  const pkg = buildRecordsPackage(s, "demo-206", "2026-11-10", {
    entries: [],
    complete: true,
  });
  const everything = JSON.stringify([
    pkg.files,
    pkg.sections.map((x) => x.rows),
    recordsReadme(pkg, { at: "now", by: "me" }, []),
  ]);
  expect(everything).toContain("signed-annual-page.jpg");
});
