/**
 * Responsibility: Hunt repro NA-11: the setup wizard's "a second run cannot
 *   duplicate" promise is kept only by the browser's snapshot. A second plan
 *   made from a stale snapshot (another administrator, another tab) saves
 *   every inspection again; only ADs are guarded on the server. Also pins
 *   what held: normal commands, one audit row each, idempotent request ids,
 *   and a pilot is refused.
 * Layer: Test. convex-test; copy to convex/ and run
 *   `npx vitest run convex/zz-hunt-newa-wizard-duplicates.test.ts`.
 * Dependencies: convex/management, convex/airworthiness, convex/schema,
 *   src/domain/aircraftSetup, src/data/demo.
 */
import { convexTest } from "convex-test";
import { expect, it } from "vitest";
import schema from "./schema";
import { api } from "./_generated/api";
import { demoSnapshot } from "../src/data/demo";
import {
  adSetupHeaders,
  inspectionSetupHeaders,
  parseAdSetupCsv,
  parseInspectionSetupCsv,
  planAircraftSetup,
  type SetupAction,
} from "../src/domain/aircraftSetup";

const modules = import.meta.glob([
  "./**/*.ts",
  "./_generated/*.js",
  "!./**/*.test.ts",
  "!./**/*.d.ts",
]);
const INSPECTIONS = [
  inspectionSetupHeaders.join(","),
  "Annual,,12,,,2026-01-31,,,,91.409(a)",
  "100-hour,100,,,,2026-08-14,2300.5,,,91.409(b)",
].join("\n");
const ADS = [
  adSetupHeaders.join(","),
  "2011-10-09,Seat rails,yes,2026-01-31,2200,Inspected,2400,,yes,",
  "2019-08-13,Exhaust,no,,,,,,,Not this serial range",
].join("\n");

// Each call is one administrator's dry run against the same (stale) snapshot.
const plan = () =>
  planAircraftSetup(demoSnapshot(), "demo-206", {
    inspections: parseInspectionSetupCsv(INSPECTIONS),
    ads: parseAdSetupCsv(ADS),
  });

it("does not save the same inspections twice when two setups run on one aircraft", async () => {
  const t = convexTest(schema, modules);
  const subject = await t.run(async (ctx) => {
    await ctx.db.insert("aircraft", demoSnapshot().aircraft[0]);
    await ctx.db.insert("programs", demoSnapshot().programs![0]);
    const admin = await ctx.db.insert("users", {
      name: "Admin",
      active: true,
      isAdmin: true,
      groupIds: [],
    });
    const session = await ctx.db.insert("authSessions", {
      userId: admin,
      expirationTime: Date.now() + 86400000,
    });
    return `${admin}|${session}`;
  });
  const admin = t.withIdentity({ subject });
  const send = (a: SetupAction) => {
    const args = {
      programUuid: "demo-program",
      payload: JSON.stringify(a.command),
    };
    return a.step === "inspections"
      ? admin.mutation(api.management.execute, args)
      : admin.mutation(api.airworthiness.save, args);
  };
  const counts = () =>
    t.run(async (ctx) => ({
      inspections: (await ctx.db.query("inspections").collect()).length,
      ads: (await ctx.db.query("airworthiness").collect()).length,
      audit: (await ctx.db.query("audit").collect()).length,
    }));

  const first = plan();
  for (const a of first.actions) await send(a);
  expect(await counts()).toEqual({ inspections: 2, ads: 2, audit: 4 });
  // Held: a retry with the same request ids writes nothing more.
  for (const a of first.actions) await send(a);
  expect(await counts()).toEqual({ inspections: 2, ads: 2, audit: 4 });

  // The second administrator's commit: ADs are refused as duplicates...
  const second = plan();
  const outcomes = await Promise.all(
    second.actions.map((a) =>
      send(a).then(
        () => `${a.key} saved`,
        () => `${a.key} refused`,
      ),
    ),
  );
  // ...and correct behaviour is that the inspections are not doubled either.
  expect({ outcomes, ...(await counts()) }).toMatchObject({ inspections: 2 });
});
