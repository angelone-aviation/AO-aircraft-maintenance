// NA-2: the paper check files a flight under the UTC date of its start, not
// the pilot's local date. A flight logged at 23:30 on 31 Oct (US Central) is
// missing from October's check and appears in November's dated 2026-11-01.
// Run: node na2-paper-check-utc-month.cjs
const fs = require("fs");
const { start, BASE, result } = require("./lib.cjs");
async function saved(page, trigger) {
  const downloading = page.waitForEvent("download");
  await trigger();
  const d = await downloading;
  return { name: d.suggestedFilename(), text: fs.readFileSync(await d.path(), "utf8") };
}
(async () => {
  const { browser, page } = await start({ timezoneId: "America/Chicago" });
  await page.goto(BASE + "/flights");
  await page.getByRole("button", { name: "Log a completed flight", exact: true }).click();
  const dialog = page.getByRole("dialog");
  const select = dialog.getByLabel("Aircraft", { exact: true });
  await select.selectOption(await select.locator("option").filter({ hasText: "N206MA" }).getAttribute("value"));
  await dialog.getByLabel("Flight date & time").fill("2026-10-31T23:30");
  const starting = Number(await dialog.getByLabel("Starting Hobbs (hours)").inputValue());
  await dialog.getByLabel("Ending Hobbs", { exact: false }).fill((starting + 0.4).toFixed(1));
  await dialog.getByLabel("Origin", { exact: true }).fill("NA2");
  await dialog.getByRole("button", { name: "Save flight", exact: true }).click();
  await dialog.waitFor({ state: "hidden" });
  const shown = await page.getByRole("row").filter({ hasText: "NA2" }).first().innerText();
  await page.getByRole("button", { name: "Paper check (month)", exact: true }).click();
  const pc = page.getByRole("dialog").filter({ hasText: "Paper check" });
  const csvFor = async (month) => {
    await pc.getByLabel("Month", { exact: true }).fill(month);
    return (await saved(page, () => pc.getByRole("button", { name: "Save CSV", exact: true }).click())).text;
  };
  const october = await csvFor("2026-10");
  const november = await csvFor("2026-11");
  console.log("flight log row (local time):", shown.replace(/\s+/g, " ").slice(0, 120));
  console.log("October CSV:\n" + october.replace(/^﻿/, ""));
  console.log("November CSV:\n" + november.replace(/^﻿/, ""));
  await browser.close();
  const wrong = !/"Flight","2026-10-31"/.test(october) && /"Flight","2026-11-01"/.test(november);
  result(wrong, "a flight flown 31 Oct 23:30 local is absent from October's paper check and listed in November's as 2026-11-01");
})();
