/**
 * Responsibility: Hunt repro NA-14: an aircraft owner's snapshot (the
 *   server-side owner whitelist) carries logbook page photos with their
 *   storage URLs and linked flight ids, although the owner view is meant to
 *   hold only current Form 337 copies and no flights.
 * Layer: Test. convex-test; copy to convex/ and run
 *   `npx vitest run convex/zz-hunt-newa-owner-photos.test.ts`.
 * Dependencies: convex/operations, convex/memberships, convex/schema,
 *   src/data/demo.
 */
import { convexTest } from "convex-test";
import { expect, it } from "vitest";
import schema from "./schema";
import { api, internal } from "./_generated/api";
import { demoSnapshot } from "../src/data/demo";

const modules = import.meta.glob([
  "./**/*.ts",
  "./_generated/*.js",
  "!./**/*.test.ts",
  "!./**/*.d.ts",
]);

it("sends an aircraft owner the Form 337 copies but not the logbook page photos", async () => {
  const t = convexTest(schema, modules);
  const demo = demoSnapshot();
  const aircraftUuid = demo.aircraft[0].uuid;
  const subject = await t.run(async (ctx) => {
    await ctx.db.insert("programs", demo.programs![0]);
    await ctx.db.insert("aircraft", demo.aircraft[0]);
    const storageId = await ctx.storage.store(new Blob(["x"]));
    await ctx.db.insert("aircraftFiles", {
      aircraftUuid,
      category: "form-337",
      storageId,
      name: "337-2019.pdf",
      type: "application/pdf",
      size: 1,
      uploadedAt: 1,
    });
    await ctx.db.insert("aircraftFiles", {
      aircraftUuid,
      category: "logbook-page",
      linkedKind: "flight",
      linkedUuid: "11111111-1111-4111-8111-111111111111",
      storageId,
      name: "flight-line.jpg",
      type: "image/jpeg",
      size: 1,
      uploadedAt: 2,
    });
    const owners = await ctx.db.insert("groups", {
      programUuid: "demo-program",
      name: "Aircraft owners",
      owner: true,
      aircraftIds: [aircraftUuid],
      permissions: ["read"],
    });
    const user = await ctx.db.insert("users", {
      name: "Owner",
      email: "owner@example.test",
      active: true,
      isAdmin: false,
      groupIds: [owners],
    });
    const session = await ctx.db.insert("authSessions", {
      userId: user,
      expirationTime: Date.now() + 86_400_000,
    });
    return `${user}|${session}`;
  });
  await t.mutation(internal.memberships.backfill, {});
  const s = (await t
    .withIdentity({ subject })
    .query(api.operations.snapshot, {}))!;
  // The owner view holds no flights...
  expect(s.flights).toEqual([]);
  // ...so it should hold no photos of flight log lines either.
  expect(s.aircraftFiles?.map((f) => `${f.category}:${f.name}`)).toEqual([
    "form-337:337-2019.pdf",
  ]);
});
