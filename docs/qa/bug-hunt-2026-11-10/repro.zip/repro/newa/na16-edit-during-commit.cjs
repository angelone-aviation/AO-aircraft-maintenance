// NA-16: the commit loop keeps the draft object of the render that started it.
// Leaving the Save step while rows are still being sent does not stop the
// loop, shows no progress, and every saved row writes the OLD CSV text back
// over whatever is typed in the Inspections or AD step meanwhile.
// Run: node na16-edit-during-commit.cjs
const { start, BASE, result } = require("./lib.cjs");
const HEAD = "name,interval_hours,interval_months,interval_cycles,interval_landings,last_done_date,last_done_hours,last_done_cycles,last_done_landings,manual_reference";
const rows = (n) => Array.from({ length: n }, (_, i) => `Hunt item ${i + 1},100,,,,,2300.5,,,ref`).join("\n");
(async () => {
  const { browser, page } = await start();
  await page.goto(`${BASE}/aircraft/setup/demo-206?step=inspections`);
  await page.getByLabel("Inspections rows (CSV)").fill(`${HEAD}\n${rows(400)}`);
  await page.getByRole("button", { name: /Save$/ }).click(); // stepper: 6 Save
  await page.getByRole("button", { name: /^Save 400 inspections/ }).click();
  await page.locator(".setup-progress-saved").first().waitFor();
  // The administrator notices a missing row and goes back while the save runs.
  await page.getByRole("button", { name: /Inspections/ }).first().click();
  const box = page.getByLabel("Inspections rows (CSV)");
  await box.waitFor();
  const panelText = (await page.locator(".setup-page").innerText()).replace(/\s+/g, " ");
  const edited = `${HEAD}\n${rows(400)}\nHunt added row,,12,,,2026-03-15,,,,ref`;
  await box.fill(edited);
  await page.waitForTimeout(1500);
  const after = await box.inputValue();
  const draft = await page.evaluate(() => {
    const k = Object.keys(localStorage).find((x) => x.startsWith("angel-one-setup"));
    const d = JSON.parse(localStorage.getItem(k));
    return { hasAdded: d.inspectionCsv.includes("Hunt added row"), done: d.done.length };
  });
  console.log("progress or 'saving' notice visible on the Inspections step:", /Saving|Saved \d+ of|in progress/i.test(panelText));
  console.log("textarea still holds the added row after 1.5 s:", after.includes("Hunt added row"));
  console.log("stored draft:", JSON.stringify(draft));
  await browser.close();
  result(!after.includes("Hunt added row") && draft.done > 0, "a row typed into the Inspections step while the commit was still running was wiped by the commit loop, with no sign that a save was in progress");
})();
