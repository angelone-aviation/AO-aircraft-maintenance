// NA-17: leaving the Save step while a commit is running and coming back
// shows the Save button again (the running commit is invisible). Clicking it
// starts a second loop over the rows the first has not reached yet, with new
// record ids and request ids, so those inspections are saved twice.
// Run: node na17-second-commit-doubles.cjs
const { start, readSnapshot, BASE, result } = require("./lib.cjs");
const HEAD = "name,interval_hours,interval_months,interval_cycles,interval_landings,last_done_date,last_done_hours,last_done_cycles,last_done_landings,manual_reference";
const N = 300;
const rows = Array.from({ length: N }, (_, i) => `Hunt item ${i + 1},100,,,,,2300.5,,,ref`).join("\n");
(async () => {
  const { browser, page } = await start();
  await page.goto(`${BASE}/aircraft/setup/demo-206?step=inspections`);
  await page.getByLabel("Inspections rows (CSV)").fill(`${HEAD}\n${rows}`);
  const step = (name) => page.locator(".setup-steps button").filter({ hasText: name }).click();
  await step("Save");
  await page.getByRole("button", { name: new RegExp(`^Save ${N} inspections`) }).click();
  await page.locator(".setup-progress-saved").first().waitFor();
  // Look at the review while it runs, then come back to Save.
  await step("Review (dry run)");
  await page.getByRole("heading", { name: "Review (dry run)" }).waitFor();
  await step("Save");
  const button = page.locator(".setup-panel button.primary").first();
  const label = await button.innerText();
  console.log("Save step on return shows:", label);
  if (/^Save \d+ inspection/.test(label)) await button.click();
  await page.getByText("Setup saved for N206MA").waitFor({ timeout: 120000 });
  await page.waitForTimeout(4000); // let the first loop finish too
  const s = (await readSnapshot(page))[0];
  const names = s.inspections.filter((i) => i.aircraftUuid === "demo-206" && i.description.startsWith("Hunt item")).map((i) => i.description);
  const doubled = names.length - new Set(names).size;
  console.log(`inspections saved: ${names.length} for ${N} rows; saved twice: ${doubled}`);
  await browser.close();
  result(doubled > 0, `${doubled} of ${N} inspections were saved twice after Save was clicked again on returning to the step`);
})();
