// NA-9: on a device that has not exported a PDF before, the records package
// and the paper check (even Save CSV) fail offline with the browser's raw
// module error, because their chunks statically import the PDF library, which
// the service worker caches only after first use online.
// Run: node na9-offline-export-raw-error.cjs
const { start, BASE, result } = require("./lib.cjs");
(async () => {
  const { browser, page, context } = await start();
  await page.evaluate(() => navigator.serviceWorker.ready);
  await page.reload();
  await page.getByRole("heading", { name: "Your fleet, at a glance." }).waitFor();
  await page.getByRole("button", { name: /View aircraft/i }).first().click();
  const detail = page.getByRole("dialog", { name: "N206MA" });
  await detail.getByRole("button", { name: "Export records package", exact: true }).waitFor();
  await context.setOffline(true);
  await detail.getByRole("button", { name: "Export records package", exact: true }).click();
  const exportAlert = await detail.getByRole("alert").first().innerText({ timeout: 15000 }).catch(() => "");
  // The paper check, from the Flight log (client-side navigation works offline).
  await page.keyboard.press("Escape");
  await page.getByRole("link", { name: "Flight log", exact: true }).click();
  await page.getByRole("button", { name: "Paper check (month)", exact: true }).click();
  const pc = page.getByRole("dialog");
  let downloaded = false;
  page.once("download", () => { downloaded = true; });
  await pc.getByRole("button", { name: "Save CSV", exact: true }).click();
  const csvAlert = await pc.getByRole("alert").first().innerText({ timeout: 8000 }).catch(() => "");
  console.log("paper check CSV downloaded offline:", downloaded);
  console.log("records package alert:", exportAlert);
  console.log("paper check CSV alert:", csvAlert);
  await browser.close();
  const raw = /dynamically imported module|Importing a module script failed/i;
  result(raw.test(exportAlert) || raw.test(csvAlert), "offline export shows the raw module-load error instead of a message a user can act on");
})();
