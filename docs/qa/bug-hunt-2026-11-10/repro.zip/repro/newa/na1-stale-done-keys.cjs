// NA-1: the setup wizard remembers saved rows by spreadsheet row number
// ("inspection:2"), and keeps them when the CSV text is replaced or edited.
// A second file (or a file with a row removed/added above) has its rows
// skipped as "Already saved by this setup" although they were never saved.
// Run: node na1-stale-done-keys.cjs   (ANGELONE_URL defaults to :4400)
const { start, readSnapshot, BASE, result } = require("./lib.cjs");
const HEAD = "name,interval_hours,interval_months,interval_cycles,interval_landings,last_done_date,last_done_hours,last_done_cycles,last_done_landings,manual_reference";
const FILE_A = [HEAD, "Hunt annual,,12,,,2026-03-15,,,,91.409(a)", "Hunt 100-hour,100,,,,,2300.5,,,91.409(b)"].join("\n");
const FILE_B = [HEAD, "Hunt ELT battery,,24,,,2025-06-10,,,,91.207", "Hunt pitot-static,,24,,,2025-08-01,,,,91.411"].join("\n");
(async () => {
  const { browser, page } = await start();
  const open = (step) => page.goto(`${BASE}/aircraft/setup/demo-206?step=${step}`);
  await open("inspections");
  const box = page.getByLabel("Inspections rows (CSV)");
  await box.fill(FILE_A);
  await open("commit");
  await page.getByRole("button", { name: "Save 2 inspections and 0 ADs" }).click();
  await page.getByText("Setup saved for N206MA").waitFor();
  // The administrator finds two more inspections in the logbook and loads a second file.
  await open("inspections");
  await page.getByLabel("Inspections rows (CSV)").fill(FILE_B);
  await open("review");
  await page.getByRole("heading", { name: "Review (dry run)" }).waitFor();
  const reviewText = await page.locator(".setup-panel").innerText();
  await page.locator("details summary").click().catch(() => {});
  const skippedText = await page.locator("details").innerText().catch(() => "");
  await page.screenshot({ path: process.env.SHOT || "/dev/null" }).catch(() => {});
  await open("commit");
  const saveLabel = await page.locator(".setup-panel button.primary").first().innerText();
  const snaps = await readSnapshot(page);
  const names = snaps[0].inspections.filter((i) => i.aircraftUuid === "demo-206").map((i) => i.description);
  console.log("review:", reviewText.replace(/\n+/g, " | ").slice(0, 400));
  console.log("skipped:", skippedText.replace(/\n+/g, " | "));
  console.log("commit button:", saveLabel);
  console.log("inspections on N206MA:", names.join(", "));
  await browser.close();
  const lost = !names.includes("Hunt ELT battery") && /Hunt ELT battery: Already saved by this setup/.test(skippedText) && /Nothing to save/.test(saveLabel);
  result(lost, "a second inspections file is skipped as 'Already saved by this setup' and cannot be saved; its rows were never written");
})();
