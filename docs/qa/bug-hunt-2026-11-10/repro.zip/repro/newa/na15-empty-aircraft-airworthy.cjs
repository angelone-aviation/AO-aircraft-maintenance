// NA-15: an aircraft created in step 1 of the setup wizard, with no
// inspections, no components and no ADs reviewed yet, is shown as "Airworthy"
// on the Aircraft page and the Dashboard.
// Run: node na15-empty-aircraft-airworthy.cjs
const { start, BASE, result } = require("./lib.cjs");
(async () => {
  const { browser, page } = await start();
  await page.goto(`${BASE}/aircraft/setup`);
  const panel = page.locator(".setup-panel");
  await panel.getByLabel("Registration").fill("N15NEW");
  await panel.getByLabel("Make", { exact: true }).fill("Cessna");
  await panel.getByLabel("Model", { exact: true }).fill("182P");
  await panel.getByLabel("Serial number").fill("18261234");
  await panel.getByLabel("Current Hobbs (hours)").fill("2300.0");
  await panel.getByLabel("Current tach (hours)").fill("2250.0");
  await panel.getByLabel("Current landings").fill("100");
  await panel.getByRole("button", { name: "Add aircraft" }).click();
  await page.waitForURL(/\/aircraft\/setup\/[0-9a-f-]+/);
  await page.goto(BASE + "/aircraft");
  await page.getByText("N15NEW").first().waitFor();
  const main = (await page.locator("main").innerText()).replace(/\s+/g, " ");
  const fleet = main.slice(main.indexOf("N15NEW"), main.indexOf("N15NEW") + 330);
  await page.screenshot({ path: process.env.SHOT || "/dev/null", fullPage: true }).catch(() => {});
  await page.goto(BASE + "/");
  await page.getByRole("heading", { name: "Your fleet, at a glance." }).waitFor();
  const dashAll = (await page.locator("main").innerText()).replace(/\s+/g, " ");
  const dash = dashAll.slice(dashAll.indexOf("N15NEW"), dashAll.indexOf("N15NEW") + 200);
  console.log("Aircraft page:", fleet);
  console.log("Dashboard:", dash);
  await browser.close();
  result(/Airworthy/.test(fleet) && /Inspections missing/.test(fleet), "a new aircraft with 'Inspections missing' and 'ADs not reviewed' is labelled Airworthy");
})();
