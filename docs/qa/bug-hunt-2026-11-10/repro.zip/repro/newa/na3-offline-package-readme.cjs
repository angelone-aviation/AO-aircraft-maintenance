// NA-3: an offline records package holds only the recent change-log entries on
// the device, but README.txt (and change-log.csv) do not say so; the README
// still states "the change log lists every change".
// Run: node na3-offline-package-readme.cjs   (needs `unzip` on PATH? no: uses fflate-free parsing via the app's own zip is avoided; we unzip with python3)
const fs = require("fs");
const os = require("os");
const path = require("path");
const { execFileSync } = require("child_process");
const { start, BASE, result } = require("./lib.cjs");
(async () => {
  const { browser, page, context } = await start();
  // Wait for the service worker to install and precache, then reload so it controls the page.
  const sw = await page.evaluate(async () => {
    if (!("serviceWorker" in navigator)) return "unsupported";
    const reg = await Promise.race([navigator.serviceWorker.ready, new Promise((r) => setTimeout(() => r(null), 20000))]);
    return reg ? "ready" : "none";
  });
  console.log("service worker:", sw);
  await page.reload();
  await page.getByRole("heading", { name: "Your fleet, at a glance." }).waitFor();
  console.log("controlled:", await page.evaluate(() => !!navigator.serviceWorker.controller));
  await page.getByRole("button", { name: /View aircraft/i }).first().click();
  const detail = page.getByRole("dialog", { name: "N206MA" });
  await detail.getByRole("button", { name: "Export records package", exact: true }).waitFor();
  // One export online first, so the PDF library and print font are in the
  // service worker's on-demand cache (they are not precached); then go offline.
  const first = page.waitForEvent("download", { timeout: 30000 });
  await detail.getByRole("button", { name: "Export records package", exact: true }).click();
  await first;
  await page.waitForTimeout(1000);
  await context.setOffline(true);
  await page.waitForTimeout(500);
  const downloading = page.waitForEvent("download", { timeout: 30000 }).catch(() => null);
  await detail.getByRole("button", { name: "Export records package", exact: true }).click();
  const d = await downloading;
  if (!d) {
    console.log("status/alert:", await detail.locator("[role=alert],[role=status]").allInnerTexts());
    await browser.close();
    console.log("INCONCLUSIVE: no package was produced offline");
    process.exitCode = 2;
    return;
  }
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "na3-"));
  const zip = path.join(dir, "pkg.zip");
  await d.saveAs(zip);
  const read = (name) => execFileSync("python3", ["-I", "-c", "import zipfile,sys;sys.stdout.buffer.write(zipfile.ZipFile(sys.argv[1]).read(sys.argv[2]))", zip, name]).toString("utf8");
  const readme = read("README.txt");
  const log = read("change-log.csv");
  console.log(readme);
  console.log("change-log.csv first lines:\n" + log.split("\r\n").slice(0, 3).join("\n").slice(0, 300));
  await browser.close();
  const saysPartial = /only the recent|partial|not complete|incomplete|reconnect/i.test(readme);
  const claimsComplete = /the change log lists every change/.test(readme);
  result(!saysPartial && claimsComplete, "offline package: README.txt does not say the change log is partial and still claims it lists every change");
})();
