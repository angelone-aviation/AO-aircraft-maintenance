/**
 * Responsibility: Hunt repro NA-5: the AD setup template accepts an AD number
 *   that a spreadsheet has turned into a date ("10/9/2011" for 2011-10-09).
 * Layer: Test. Copy to src/domain/ and run
 *   `npx vitest run src/domain/zz-hunt-newa-ad-number.test.ts`.
 * Dependencies: src/domain/aircraftSetup.ts, src/data/demo.ts.
 */
import { describe, expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import {
  adSetupHeaders,
  parseAdSetupCsv,
  planAircraftSetup,
} from "./aircraftSetup";

const NOW = Date.parse("2026-11-09T12:00:00Z");
// What Excel writes after opening the template row
// "2011-10-09,Seat rail,yes,2026-02-10,2200,..." and saving as CSV (US locale):
// the AD number and the date are both rewritten as M/D/YYYY.
const EXCEL_ROW = "10/9/2011,Seat rail,yes,,,,,,no,";

describe("AD setup template and spreadsheet-mangled AD numbers", () => {
  it("does not plan an AD whose number is a slash date", () => {
    let planned: string[] = [];
    let problems: string[] = [];
    try {
      const ads = parseAdSetupCsv(`${adSetupHeaders.join(",")}\n${EXCEL_ROW}`);
      const plan = planAircraftSetup(
        demoSnapshot(),
        "demo-206",
        { inspections: [], ads },
        { now: NOW },
      );
      planned = plan.actions.map((a) => a.label);
      problems = [...plan.errors, ...plan.warnings].filter((m) =>
        /AD number/i.test(m),
      );
    } catch (e) {
      problems = [(e as Error).message];
    }
    // Correct behaviour: the row is refused or at least flagged before saving.
    expect({ planned, flagged: problems.length > 0 }).toEqual({
      planned: [],
      flagged: true,
    });
  });
});
