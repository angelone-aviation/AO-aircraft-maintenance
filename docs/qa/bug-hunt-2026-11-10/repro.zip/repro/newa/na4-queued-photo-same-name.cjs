// NA-4: a queued logbook photo is keyed by "<flight uuid>:<file name>". iOS
// names every camera capture "image.jpg", so a second photo taken for the same
// offline flight silently replaces the first: one photo is lost on the device.
// Online, two files of the same name are both kept.
// Run: node na4-queued-photo-same-name.cjs
const fs = require("fs");
const { start, BASE, result } = require("./lib.cjs");
// Two different 1x1 PNGs (red, blue) sent with a JPEG name/type as a camera would.
const RED = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8DwHwAFBQIAX8jx0gAAAABJRU5ErkJggg==", "base64");
const BLUE = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPj/HwADBwIAMCbHYQAAAABJRU5ErkJggg==", "base64");
(async () => {
  const { browser, page, context } = await start();
  await page.goto(BASE + "/flights");
  await page.getByRole("button", { name: "Log a completed flight", exact: true }).click();
  const dialog = page.getByRole("dialog");
  const select = dialog.getByLabel("Aircraft", { exact: true });
  await select.selectOption(await select.locator("option").filter({ hasText: "N206MA" }).getAttribute("value"));
  const d = new Date(Date.now() - 3600e3);
  const pad = (n) => String(n).padStart(2, "0");
  await dialog.getByLabel("Flight date & time").fill(`${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`);
  const starting = Number(await dialog.getByLabel("Starting Hobbs (hours)").inputValue());
  await dialog.getByLabel("Ending Hobbs", { exact: false }).fill((starting + 1).toFixed(1));
  await dialog.getByLabel("Origin", { exact: true }).fill("NA4");
  await context.setOffline(true);
  await dialog.getByRole("button", { name: "Save flight", exact: true }).click();
  await dialog.waitFor({ state: "hidden" });
  const prompt = page.locator(".lp-prompt");
  const input = prompt.locator("input[type=file]");
  await input.setInputFiles({ name: "image.jpg", mimeType: "image/jpeg", buffer: RED });
  await prompt.getByRole("img", { name: "image.jpg, waiting to upload" }).first().waitFor();
  await input.setInputFiles({ name: "image.jpg", mimeType: "image/jpeg", buffer: BLUE });
  await page.waitForTimeout(800);
  const waiting = await prompt.getByRole("img", { name: "image.jpg, waiting to upload" }).count();
  const notice = await page.locator("[role=status],[role=alert]").allInnerTexts();
  await page.getByRole("link", { name: /awaiting sync/ }).click();
  await page.getByText("Photo waiting", { exact: true }).first().waitFor();
  const photoRows = await page.getByText("Photo waiting", { exact: true }).count();
  console.log("thumbnails waiting in the prompt:", waiting, "| 'Photo waiting' rows in Sync center:", photoRows);
  console.log("notices:", JSON.stringify(notice).slice(0, 300));
  await context.setOffline(false);
  await page.getByText("Everything is synchronized").waitFor();
  await page.getByRole("link", { name: "Flight log", exact: true }).click();
  const row = page.getByRole("row").filter({ hasText: "NA4" });
  await row.getByRole("button", { name: /Open logbook photo/ }).first().waitFor();
  const uploaded = await row.getByRole("button", { name: /Open logbook photo/ }).count();
  console.log("photos on the flight after sync:", uploaded);
  await browser.close();
  result(uploaded === 1 && photoRows === 1, "two different photos named image.jpg were taken for one offline flight; only one was kept and uploaded, with no warning");
})();
