/**
 * Responsibility: Hunt repro NA-10: an overdue inspection loaded by the setup
 *   wizard without a manual_reference grounds the aircraft with a blank
 *   reason (" overdue"), because the status uses `reference` alone.
 * Layer: Test. Copy to src/domain/ and run
 *   `npx vitest run src/domain/zz-hunt-newa-blank-reference.test.ts`.
 * Dependencies: src/domain/aircraftSetup.ts, aircraftStatus.ts, management.ts,
 *   src/data/demo.ts.
 */
import { expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import {
  inspectionSetupHeaders,
  parseInspectionSetupCsv,
  planAircraftSetup,
} from "./aircraftSetup";
import { aircraftStatus } from "./aircraftStatus";
import { applyManagement } from "./management";

const NOW = Date.parse("2026-11-09T12:00:00Z");

it("names the overdue inspection that grounds the aircraft when it has no reference", () => {
  const s = demoSnapshot();
  // manual_reference is optional in the template ("Blank cells mean unknown").
  const csv = `${inspectionSetupHeaders.join(",")}\nTransponder check,,24,,,2024-10-15,,,,`;
  const plan = planAircraftSetup(
    s,
    "demo-208",
    { inspections: parseInspectionSetupCsv(csv), ads: [] },
    { now: NOW },
  );
  expect(plan.errors).toEqual([]);
  for (const a of plan.actions)
    if (a.step === "inspections") applyManagement(s, a.command, NOW);
  const status = aircraftStatus(s, "demo-208", "2026-11-09");
  const labels = JSON.stringify(status);
  expect(labels).toContain("Transponder check overdue");
});
