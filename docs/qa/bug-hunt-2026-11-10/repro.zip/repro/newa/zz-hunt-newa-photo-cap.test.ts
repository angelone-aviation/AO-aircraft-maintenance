/**
 * Responsibility: Hunt repro NA-7: logbook page photos share the aircraft's
 *   200-document cap with Form 337 copies, so 200 flight photos (a few months
 *   of flying) block the next photo AND every Form 337 upload.
 * Layer: Test. convex-test; copy to convex/ and run
 *   `npx vitest run convex/zz-hunt-newa-photo-cap.test.ts`.
 * Dependencies: convex/aircraftFiles, convex/schema, src/data/demo.
 */
import { convexTest } from "convex-test";
import { expect, it } from "vitest";
import schema from "./schema";
import { api } from "./_generated/api";
import { demoSnapshot } from "../src/data/demo";

const modules = import.meta.glob([
  "./**/*.ts",
  "./_generated/*.js",
  "!./**/*.test.ts",
  "!./**/*.d.ts",
]);
const FLIGHT_UUID = "11111111-1111-4111-8111-111111111111";

it("still files a Form 337 copy on an aircraft whose pilots have attached 200 flight photos", async () => {
  const t = convexTest(schema, modules);
  const demo = demoSnapshot();
  const aircraftUuid = demo.aircraft[0].uuid;
  const subject = await t.run(async (ctx) => {
    await ctx.db.insert("programs", demo.programs![0]);
    await ctx.db.insert("aircraft", demo.aircraft[0]);
    await ctx.db.insert("flights", {
      uuid: FLIGHT_UUID,
      aircraftUuid,
      authorId: "pilot",
      pilotId: "pilot",
      submittedAt: 1,
      status: "accepted" as const,
      startTime: "2026-03-04T10:00:00Z",
      hobbsOn: 3600,
      landings: 1,
      cycles: 1,
      origin: "AAA",
      destination: "BBB",
      operation: "Mission" as const,
      flightRules: "VFR" as const,
      remarks: "",
      discrepancy: "",
    });
    const storageId = await ctx.storage.store(new Blob(["x"]));
    // 200 current photos of flight lines, as pilots attach one per flight.
    for (let i = 0; i < 200; i++)
      await ctx.db.insert("aircraftFiles", {
        aircraftUuid,
        category: "logbook-page",
        linkedKind: "flight",
        linkedUuid: FLIGHT_UUID,
        storageId,
        name: `line-${i}.jpg`,
        type: "image/jpeg",
        size: 1,
        uploadedAt: i,
      });
    const group = await ctx.db.insert("groups", {
      programUuid: "demo-program",
      name: "mechanics",
      aircraftIds: [aircraftUuid],
      permissions: ["read", "maintenance"],
    });
    const user = await ctx.db.insert("users", {
      name: "Mechanic",
      active: true,
      isAdmin: false,
      groupIds: [group],
      activeProgramUuid: "demo-program",
    });
    const session = await ctx.db.insert("authSessions", {
      userId: user,
      expirationTime: Date.now() + 86400000,
    });
    return `${user}|${session}`;
  });
  const tech = t.withIdentity({ subject });
  // Correct behaviour: a permanent 91.417(a)(2)(vi) status record is not
  // crowded out by reconciliation photos.
  await expect(
    tech.action(api.aircraftFiles.upload, {
      aircraftUuid,
      programUuid: "demo-program",
      category: "form-337",
      name: "337-2019-alteration.pdf",
      type: "application/pdf",
      bytes: new TextEncoder().encode("%PDF-1.4 Form 337").buffer,
    }),
  ).resolves.toBeNull();
});
