// NA-12: for an aircraft whose total time is Hobbs + an adjustment (any real
// aircraft whose Hobbs meter was replaced), the Inspections screen prints the
// due TOTAL time with the unit "h Hobbs". The Hobbs reading it is due at is
// lower by the adjustment.
// Run: node na12-total-time-labelled-hobbs.cjs
const { start, BASE, result } = require("./lib.cjs");
const IH = "name,interval_hours,interval_months,interval_cycles,interval_landings,last_done_date,last_done_hours,last_done_cycles,last_done_landings,manual_reference";
(async () => {
  const { browser, page } = await start();
  await page.goto(`${BASE}/aircraft/setup`);
  const panel = page.locator(".setup-panel");
  await panel.getByLabel("Registration").fill("N12HB");
  await panel.getByLabel("Make", { exact: true }).fill("Cessna");
  await panel.getByLabel("Model", { exact: true }).fill("182P");
  await panel.getByLabel("Serial number").fill("18261234");
  // Hobbs replaced at 37.2 h of airframe time: total 2,337.2 = Hobbs 2,300.0 + 37.2.
  await panel.getByLabel("Current Hobbs (hours)").fill("2300.0");
  await panel.getByLabel("Current tach (hours)").fill("2250.0");
  await panel.getByLabel("Total time adjustment (hours)").fill("37.2");
  await panel.getByLabel("Current landings").fill("100");
  await panel.getByRole("button", { name: "Add aircraft" }).click();
  await page.waitForURL(/\/aircraft\/setup\/[0-9a-f-]+/);
  const uuid = new URL(page.url()).pathname.split("/").pop();
  await page.goto(`${BASE}/aircraft/setup/${uuid}?step=inspections`);
  // Last done at 2,290.0 h total time; due at 2,390.0 total = Hobbs 2,352.8.
  await page.getByLabel("Inspections rows (CSV)").fill(`${IH}\n100-hour,100,,,,2026-08-14,2290.0,,,91.409(b)`);
  await page.goto(`${BASE}/aircraft/setup/${uuid}?step=commit`);
  await page.locator(".setup-panel button.primary").first().click();
  await page.getByText("Setup saved for N12HB").waitFor();
  await page.goto(BASE + "/inspections");
  const row = page.getByRole("row").filter({ hasText: "N12HB" }).first();
  await row.waitFor();
  const text = (await row.innerText()).replace(/\s+/g, " ");
  await page.screenshot({ path: process.env.SHOT || "/dev/null" }).catch(() => {});
  console.log("Inspections row:", text.slice(0, 160));
  await browser.close();
  result(/Due 2,390\.0 h Hobbs/.test(text), "the row reads 'Due 2,390.0 h Hobbs' although 2,390.0 is total time; the Hobbs meter will read 2,352.8 when it is due");
})();
