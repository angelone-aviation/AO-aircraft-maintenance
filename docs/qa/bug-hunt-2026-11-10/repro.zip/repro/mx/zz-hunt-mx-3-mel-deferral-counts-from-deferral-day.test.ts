/**
 * Responsibility: Repro MX-3. An MEL deferral's repair interval is counted
 *   from the day the deferral is entered, not the day the defect was
 *   recorded.
 * Layer: Test. Bug-hunt repro (2026-11-10); asserts the correct behaviour,
 *   so it fails while the bug exists.
 * Dependencies: src/domain/deferrals.ts, aircraftStatus.ts, src/data/demo.ts.
 *
 * Run: cp <this file> src/domain/ && npx vitest run
 *   src/domain/zz-hunt-mx-3-mel-deferral-counts-from-deferral-day.test.ts
 */
import { describe, expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import { aircraftStatus } from "./aircraftStatus";
import { deferDiscrepancy } from "./deferrals";

const DAY_MS = 86_400_000;
const REPORTED = Date.parse("2026-11-02T15:00:00Z");

describe("MX-3: MEL category B (3 calendar days excluding the day of discovery)", () => {
  it("expires 3 days after the defect was recorded, however late the deferral is entered", () => {
    const s = demoSnapshot();
    const d = s.discrepancies.find((x) => x.status === "open")!;
    d.createdAt = REPORTED;
    d.grounding = true;
    // Entered five days after the pilot reported the defect.
    const now = REPORTED + 5 * DAY_MS;
    const deferred = deferDiscrepancy(
      s,
      {
        uuid: d.uuid,
        deferredOn: "2026-11-07",
        deferral: {
          type: "mel",
          melItem: "34-1",
          category: "B",
          placard: "INOP",
        },
      },
      now,
    );
    // Recorded 2 Nov, so the category B interval ends 5 Nov.
    expect(deferred.deferral!.expiresOn).toBe("2026-11-05");
    s.discrepancies = s.discrepancies.map((x) =>
      x.uuid === d.uuid ? deferred : x,
    );
    expect(
      aircraftStatus(s, d.aircraftUuid, "2026-11-08").reasons.map(
        (r) => r.kind,
      ),
    ).toContain("deferral");
  });
});
