const L = require("./lib.cjs");
(async () => {
  const { browser, page } = await L.start();
  const snaps = await L.readSnapshot(page);
  console.log("snapshots", snaps.length);
  const s = snaps[0];
  console.log(Object.keys(s));
  console.log("aircraft", JSON.stringify(s.aircraft.map(a => ({u:a.uuid,r:a.registration,m:a.meter,h:a.currentHobbs,t:a.currentTach,c:a.cycles,l:a.landings,op:a.operationalStatus,adj:a.adjustmentSeconds,heli:a.helicopter}))));
  console.log("inspections", JSON.stringify(s.inspections));
  console.log("mgmt kinds", JSON.stringify((s.management||[]).map(r=>[r.kind,r.uuid,r.aircraftUuid,r.componentType||r.description||r.name])));
  console.log("ads", JSON.stringify((s.airworthiness||[]).map(r=>[r.uuid,r.aircraftUuid,r.source.number,r.applicability,r.tasks.length])));
  console.log("disc", JSON.stringify(s.discrepancies));
  console.log("user", JSON.stringify(s.user), JSON.stringify(s.groups));
  const links = await page.locator("a[href]").evaluateAll(els => els.map(e => e.getAttribute("href") + " :: " + e.textContent.trim().slice(0,40)));
  console.log(links.join("\n"));
  await browser.close();
})();
