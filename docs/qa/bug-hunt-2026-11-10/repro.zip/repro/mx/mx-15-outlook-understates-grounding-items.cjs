// MX-15: Overview's Maintenance outlook words two grounding items as if they
// were not: a usage limit at exactly 0 reads "0.0 h" (no "overdue"/"due
// now"), and an expired MEL deferral reads "Deferred" in the warning tone.
// Run: node <this file>   (needs lib.cjs and states.cjs beside it)
const L = require("./lib.cjs");
const { PATCH } = require("./states.cjs");
(async () => {
  const { browser, page } = await L.start();
  let bug = false, msg = "";
  try {
    await L.patchSnapshot(page, PATCH, { today: L.localDate(), yesterday: L.shiftDays(-1), tenAgo: L.shiftDays(-10) });
    const row = async (text) => {
      const r = page.locator(".dash-outlook-row").filter({ hasText: text });
      const value = r.locator(".dash-outlook-value");
      return { text: (await r.innerText()).replace(/\n+/g, " | "), value: await value.innerText(), tone: await value.getAttribute("class") };
    };
    const zero = await row("Zero hours inspection");
    const mel = await row("N7MEL");
    const card = async (reg) => (await page.locator(".dash-card").filter({ hasText: reg }).innerText()).replace(/\n+/g, " | ").slice(0, 120);
    console.log("N2ZERO card:", await card("N2ZERO"), "\n  outlook:", zero.text, "[" + zero.tone + "]");
    console.log("N7MEL card:", await card("N7MEL"), "\n  outlook:", mel.text, "[" + mel.tone + "]");
    await page.locator(".dash-outlook").screenshot({ path: L.SHOTS + "/mx-15-outlook.png" });
    const zeroWrong = !/overdue|due now/i.test(zero.value);
    const melWrong = !/expired/i.test(mel.text) || /tone-warn/.test(mel.tone);
    if (zeroWrong || melWrong) {
      bug = true;
      msg = `outlook value for a reached hours limit is "${zero.value}"; an expired, grounding MEL deferral reads "${mel.value}" (${mel.tone.replace("dash-outlook-value ", "")})`;
    }
  } finally {
    await browser.close();
  }
  L.result(bug, msg);
})();
