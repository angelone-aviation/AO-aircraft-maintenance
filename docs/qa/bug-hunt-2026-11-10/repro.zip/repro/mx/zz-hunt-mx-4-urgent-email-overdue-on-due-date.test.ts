/**
 * Responsibility: Repro MX-4. The server's urgent alert email judges
 *   calendar limits on the UTC date, so on the evening of a due date in the
 *   Americas it announces "overdue" and "grounded" while the limit is still
 *   valid and the dispatch gate still lets the aircraft fly.
 * Layer: Test. Bug-hunt repro (2026-11-10), convex-test with a stubbed
 *   Resend; asserts the correct behaviour, so it fails while the bug exists.
 * Dependencies: convex/urgentAlerts.ts,
 *   src/domain/aircraftStatus.ts, tests/fixtures/alertProgram.ts.
 *
 * Run: cp <this file> convex/ && npx vitest run
 *   convex/zz-hunt-mx-4-urgent-email-overdue-on-due-date.test.ts
 */
import { afterEach, expect, it, vi } from "vitest";
import { internal } from "./_generated/api";
import { earliestLocalDate } from "../src/domain/aircraftStatus";
import {
  DEMO_PROGRAM,
  seedAlertProgram,
  sentEmails,
  stubResend,
} from "../tests/fixtures/alertProgram";

const DUE = "2026-11-30";
// 17:30 on 30 Nov in Los Angeles, 20:30 in New York: the due date itself.
const EVENING_OF_DUE_DATE = Date.parse("2026-12-01T01:30:00Z");

afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
  vi.useRealTimers();
});

async function seedDueToday() {
  const world = await seedAlertProgram();
  await world.t.run(async (ctx) => {
    for (const i of await ctx.db.query("inspections").collect())
      await ctx.db.patch(i._id, { dueDate: DUE });
  });
  return world;
}

it("the dispatch gate's date still treats the limit as valid at that moment", () => {
  expect(earliestLocalDate(EVENING_OF_DUE_DATE)).toBe(DUE);
});

it("sends no 'overdue / grounded' urgent email while the due date has not ended for the user", async () => {
  vi.useFakeTimers({ toFake: ["Date"] });
  vi.setSystemTime(EVENING_OF_DUE_DATE);
  const { t } = await seedDueToday();
  const request = stubResend();
  const result = await t.action(internal.urgentAlerts.sendImmediate, {
    programUuid: DEMO_PROGRAM,
  });
  const texts = sentEmails(request).map((e) => e.text);
  expect(texts.join("\n")).not.toContain("is grounded");
  expect(texts.join("\n")).not.toContain("Inspection overdue");
  expect(result).toMatchObject({ sent: 0 });
});
