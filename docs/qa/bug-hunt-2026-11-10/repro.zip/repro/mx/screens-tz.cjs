// Same seven states, in a browser set to America/Los_Angeles while UTC is
// already on the next calendar day (run between 00:00 and 08:00 UTC).
const fs = require("fs");
const L = require("./lib.cjs");
const { PATCH } = require("./states.cjs");
(async () => {
  const { browser, page, errors } = await L.start({ timezoneId: "America/Los_Angeles", acceptDownloads: true });
  const dates = await page.evaluate(() => {
    const f = (ms) => { const d = new Date(ms); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };
    return { today: f(Date.now()), yesterday: f(Date.now() - 86400000), tenAgo: f(Date.now() - 10 * 86400000), utc: new Date().toISOString() };
  });
  console.log("browser dates", dates);
  await L.patchSnapshot(page, PATCH, dates);
  for (const route of ["/", "/planning", "/inspections", "/alerts", "/board", "/discrepancies"]) {
    await page.goto(L.BASE + route);
    await page.waitForTimeout(1200);
    const text = (await page.locator("main").innerText()).replace(/\n+/g, " | ");
    const picks = ["N1RM66", "N3TODAY", "N7MEL"].map((r) => { const i = text.indexOf(r + " |"); return i < 0 ? "" : text.slice(i, i + 260); });
    console.log("==== " + route + "\n" + (route === "/" ? picks.join("\n") : text.slice(route === "/alerts" ? 150 : 400, 2200)));
  }
  // Inspection completion dialog defaults
  await page.goto(L.BASE + "/inspections");
  await page.waitForTimeout(800);
  const row = page.getByRole("row").filter({ hasText: "Due today annual" });
  await row.getByRole("button", { name: "Complete" }).click();
  const d = page.getByRole("dialog").first();
  await d.waitFor();
  const inputs = await d.locator("input, textarea, select").evaluateAll((els) => els.map((e) => `${e.getAttribute("aria-label") || e.name || e.id}=${e.value}`));
  console.log("COMPLETE DIALOG", (await d.innerText()).replace(/\n+/g, " | ").slice(0, 500), "\nINPUTS", inputs.join(" ; "));
  console.log("errors", errors);
  await browser.close();
})();
