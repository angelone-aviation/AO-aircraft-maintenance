/**
 * Responsibility: Repro MX-8. An AD action limited by a due date or hours
 *   without a repeat interval reads "Not set" (owner portal, board view) and
 *   "-" (status sheet) for what remains, even while it is Overdue.
 * Layer: Test. Bug-hunt repro (2026-11-10); asserts the correct behaviour,
 *   so it fails while the bug exists.
 * Dependencies: src/domain/ownerDue.ts, statusSheet.ts, model.ts,
 *   tests/fixtures/dueFleet.ts.
 *
 * Run: cp <this file> src/domain/ && npx vitest run
 *   src/domain/zz-hunt-mx-8-ad-limit-not-set-while-overdue.test.ts
 */
import { describe, expect, it } from "vitest";
import { DUE_FLEET_TODAY, dueFleet } from "../../tests/fixtures/dueFleet";
import { totalSeconds } from "./model";
import { ownerDueItems } from "./ownerDue";
import { statusSheet } from "./statusSheet";

const HOUR = 3600;

// One-time actions, as most ADs start: "within 10 hours time in service" and
// "before 1 January 2020". Neither has a repeat interval.
function fleetWithOneTimeLimits() {
  const { s, a } = dueFleet();
  s.inspections = [];
  s.management = [];
  const hours = totalSeconds(a) / HOUR;
  const base = s.airworthiness!.find((r) => r.uuid === "ad-overdue")!;
  const limited = (uuid: string, limits: object) => ({
    ...structuredClone(base),
    uuid,
    source: { ...base.source, number: uuid.toUpperCase() },
    tasks: [
      {
        ...base.tasks[0],
        intervalDays: null,
        dueDate: "",
        recurrence: "One-time" as const,
        ...limits,
      },
    ],
  });
  s.airworthiness = [
    limited("ad-date", { dueDate: "2020-01-01" }),
    limited("ad-hours", { dueHours: hours + 10 }),
  ];
  return { s, a };
}

describe("MX-8: the limit of an AD action without a repeat interval", () => {
  it("is shown to the owner and the board, not 'Not set'", () => {
    const { s, a } = fleetWithOneTimeLimits();
    const rows = ownerDueItems(s, a, DUE_FLEET_TODAY);
    const overdue = rows.find((r) => r.uuid === "ad-date")!;
    const soon = rows.find((r) => r.uuid === "ad-hours")!;
    expect(overdue.status).toBe("overdue");
    expect(soon.status).toBe("due-soon");
    expect(overdue.remaining).not.toBe("Not set");
    expect(soon.remaining).toContain("10.0");
  });

  it("is printed on the status sheet (AD status 'with next due', ADR-0004)", () => {
    const { s, a } = fleetWithOneTimeLimits();
    const rows = statusSheet(s, a.uuid, DUE_FLEET_TODAY).sections.find(
      (x) => x.id === "airworthiness",
    )!.rows;
    const overdue = rows.find((r) => r[0] === "AD-DATE")!;
    expect(overdue[4]).toBe("Overdue");
    expect(overdue[3]).not.toBe("-");
    expect(overdue.join(" ")).toContain("2020-01-01");
  });
});
