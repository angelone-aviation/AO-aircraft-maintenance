/**
 * Responsibility: Repro MX-1. A repeating AD action with no fixed interval
 *   ignores every due limit entered after its first compliance.
 * Layer: Test. Bug-hunt repro (2026-11-10); asserts the correct behaviour,
 *   so it fails while the bug exists.
 * Dependencies: src/domain/airworthiness.ts, aircraftStatus.ts, alerts.ts,
 *   src/data/demo.ts.
 *
 * Run: cp <this file> src/domain/ && npx vitest run
 *   src/domain/zz-hunt-mx-1-ad-due-ignored-after-compliance.test.ts
 */
import { describe, expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import {
  adStatus,
  adTaskStatus,
  applyADCommand,
  blankAD,
  blankADTask,
  type ADCompliance,
} from "./airworthiness";
import { aircraftStatus } from "./aircraftStatus";
import { computeAlerts } from "./alerts";

const NOW = Date.parse("2026-11-10T15:00:00Z");

function compliance(taskUuid: string): ADCompliance {
  return {
    uuid: crypto.randomUUID(),
    taskUuid,
    date: "2026-11-01",
    hours: null,
    cycles: null,
    method: "Inspected per paragraph (g) at the annual",
    serviceBulletin: "",
    terminatedBy: "",
    workOrderUuid: "",
    mechanic: "A Mechanic",
    certificate: "",
    evidence: "",
    recordedAt: 0,
    recordedBy: "",
  };
}

// "Repeat at each annual inspection": recurring, but no fixed interval, so
// the next due date is entered by hand after each compliance.
function trackedSnapshot() {
  const s = demoSnapshot();
  const a = s.aircraft[0];
  s.inspections = [];
  s.management = [];
  s.discrepancies = [];
  s.airworthiness = [];
  a.operationalStatus = "airworthy";
  const r = blankAD(a.uuid);
  r.source.number = "2026-20-01";
  r.source.subject = "Inspect at each annual inspection";
  r.source.recurring = "Yes";
  r.applicability = "Applicable";
  r.reviewRequired = false;
  r.tasks = [
    {
      ...blankADTask(),
      description: "Inspect the fitting",
      dueDate: "2026-11-30",
      recurrence: "Recurring",
    },
  ];
  applyADCommand(s, { kind: "save", record: r }, NOW);
  const saved = s.airworthiness![0];
  applyADCommand(
    s,
    {
      kind: "comply",
      uuid: saved.uuid,
      version: saved.version,
      entry: compliance(saved.tasks[0].uuid),
    },
    NOW,
  );
  const next = structuredClone(s.airworthiness![0]);
  next.tasks[0].dueDate = "2027-11-30";
  applyADCommand(
    s,
    { kind: "save", record: next, reason: "Next due at the 2027 annual" },
    NOW,
  );
  return { s, a, ad: s.airworthiness![0] };
}

describe("MX-1: a due limit entered after compliance on an AD action without an interval", () => {
  it("is Scheduled before its new due date, not 'Due not set'", () => {
    const { s, ad } = trackedSnapshot();
    expect(ad.tasks[0].dueDate).toBe("2027-11-30");
    expect(adTaskStatus(s, ad, ad.tasks[0], "2027-06-01")).toBe("Scheduled");
  });

  it("is Due soon within 30 days of the new due date", () => {
    const { s, ad } = trackedSnapshot();
    expect(adTaskStatus(s, ad, ad.tasks[0], "2027-11-15")).toBe("Due soon");
  });

  it("is Overdue, grounds the aircraft and alerts once the date has passed", () => {
    const { s, a, ad } = trackedSnapshot();
    const today = "2027-12-01";
    expect(adStatus(s, ad, today)).toBe("Overdue");
    expect(aircraftStatus(s, a.uuid, today).level).toBe("grounded");
    expect(computeAlerts(s, today).map((x) => x.kind)).toContain("ad-overdue");
  });
});
