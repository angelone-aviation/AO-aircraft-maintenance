const fs = require("fs");
const L = require("./lib.cjs");
const { PATCH } = require("./states.cjs");
(async () => {
  const { browser, page, errors } = await L.start();
  await L.patchSnapshot(page, PATCH, { today: L.localDate(), yesterday: L.shiftDays(-1), tenAgo: L.shiftDays(-10) });
  // AD register for N4AD
  await page.goto(L.BASE + "/airworthiness");
  await page.waitForTimeout(800);
  const sel = page.locator("main select").first();
  await sel.selectOption({ label: "N4AD · 206 Stationair" });
  await page.waitForTimeout(800);
  console.log("#### AD REGISTER N4AD\n" + (await page.locator("main").innerText()).replace(/\n+/g, " | ").slice(300, 1700));
  await page.screenshot({ path: `${L.SHOTS}/mx-screens-ad-register.png`, fullPage: true });
  // Owner preview
  await page.goto(L.BASE + "/");
  await page.getByRole("button", { name: "Preview owner portal" }).click();
  await page.waitForTimeout(1500);
  const owner = await page.locator("body").innerText();
  fs.writeFileSync(`${L.SHOTS}/mx-screens-owner.txt`, owner);
  console.log("#### OWNER\n" + owner.replace(/\n+/g, " | ").slice(0, 4000));
  await page.screenshot({ path: `${L.SHOTS}/mx-screens-owner.png`, fullPage: true });
  await page.getByRole("button", { name: "Exit owner preview" }).click();
  await page.waitForTimeout(1000);
  await page.getByRole("button", { name: "Preview board view" }).click();
  await page.waitForTimeout(1500);
  const board = await page.locator("body").innerText();
  fs.writeFileSync(`${L.SHOTS}/mx-screens-board-preview.txt`, board);
  console.log("#### BOARD PREVIEW\n" + board.replace(/\n+/g, " | ").slice(0, 2500));
  await page.screenshot({ path: `${L.SHOTS}/mx-screens-board-preview.png`, fullPage: true });
  console.log("errors", errors);
  await browser.close();
})();
