const fs = require("fs");
const { execFileSync } = require("child_process");
const L = require("./lib.cjs");
const { PATCH, EXPECTED } = require("./states.cjs");
(async () => {
  const { browser, page, errors } = await L.start({ acceptDownloads: true });
  await L.patchSnapshot(page, PATCH, { today: L.localDate(), yesterday: L.shiftDays(-1), tenAgo: L.shiftDays(-10) });
  const only = process.argv[2];
  for (const reg of Object.keys(EXPECTED)) {
    if (only && only !== reg) continue;
    await page.goto(L.BASE + "/");
    await page.waitForTimeout(700);
    const card = page.locator(".dash-card").filter({ hasText: reg });
    // Status sheet PDF
    await card.getByRole("button", { name: /View aircraft/ }).first().click();
    const dlg = page.getByRole("dialog").first();
    await dlg.waitFor();
    try {
      const [download] = await Promise.all([
        page.waitForEvent("download", { timeout: 15000 }),
        dlg.getByRole("button", { name: "Export status sheet" }).click(),
      ]);
      const file = `${L.SHOTS}/mx-status-${reg}.pdf`;
      await download.saveAs(file);
      const text = execFileSync("pdftotext", ["-layout", file, "-"]).toString();
      fs.writeFileSync(`${L.SHOTS}/mx-status-${reg}.txt`, text);
      console.log(`#### PDF ${reg}\n` + text.replace(/\n\s*\n/g, "\n").slice(0, 1800));
    } catch (e) {
      console.log(`#### PDF ${reg} FAILED: ${String(e).slice(0, 200)} | body: ${(await page.locator("body").innerText()).slice(0, 300).replace(/\n/g, " | ")}`);
    }
    // Dispatch gate
    await page.goto(L.BASE + "/");
    await page.waitForTimeout(700);
    await page.locator(".dash-card").filter({ hasText: reg }).getByRole("button", { name: /Log flight/ }).first().click();
    await page.waitForTimeout(1500);
    const body = await page.locator("body").innerText();
    const crash = body.includes("Something went wrong");
    const d2 = page.getByRole("dialog").first();
    const t = (await d2.count()) ? await d2.innerText() : body;
    console.log(`#### LOGFLIGHT ${reg} crash=${crash}\n` + t.replace(/\n+/g, " | ").slice(0, 1500));
    await page.screenshot({ path: `${L.SHOTS}/mx-logflight-${reg}.png` });
  }
  console.log("errors", errors);
  await browser.close();
})();
