const fs = require("fs");
const L = require("./lib.cjs");
const { PATCH, EXPECTED } = require("./states.cjs");
(async () => {
  const { browser, page, errors } = await L.start({ acceptDownloads: true });
  await L.patchSnapshot(page, PATCH, { today: L.localDate(), yesterday: L.shiftDays(-1), tenAgo: L.shiftDays(-10) });
  for (const reg of Object.keys(EXPECTED)) {
    await page.goto(L.BASE + "/");
    await page.waitForTimeout(800);
    const card = page.locator(".dash-card").filter({ hasText: reg });
    await card.getByRole("button", { name: /View aircraft/ }).or(card.getByRole("link", { name: /View aircraft/ })).first().click();
    await page.waitForTimeout(1000);
    const dlg = page.getByRole("dialog");
    const text = (await dlg.count()) ? await dlg.first().innerText() : await page.locator("main").innerText();
    console.log(`#### DETAIL ${reg} url=${page.url()}\n` + text.replace(/\n+/g, " | ").slice(0, 1800));
    const buttons = await ((await dlg.count()) ? dlg.first() : page.locator("main")).getByRole("button").allInnerTexts();
    console.log("buttons:", buttons.join(" ; ").slice(0, 400));
    await page.screenshot({ path: `${L.SHOTS}/mx-detail-${reg}.png` });
  }
  console.log("errors", errors);
  await browser.close();
})();
