/**
 * Responsibility: Repro MX-16. Correcting an aircraft's total time to below
 *   the hours of a recorded AD compliance is accepted, leaving a recurring
 *   AD action with more hours remaining than its whole interval.
 * Layer: Test. Bug-hunt repro (2026-11-10); asserts the correct behaviour,
 *   so it fails while the bug exists.
 * Dependencies: src/domain/fleet.ts, airworthiness.ts, adRemaining.ts,
 *   model.ts, src/data/demo.ts.
 *
 * Run: cp <this file> src/domain/ && npx vitest run
 *   src/domain/zz-hunt-mx-16-total-time-below-ad-compliance.test.ts
 */
import { describe, expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import { adRemaining } from "./adRemaining";
import { applyADCommand, blankAD, blankADTask } from "./airworthiness";
import { aircraftInputSchema, applyFleet } from "./fleet";
import { totalSeconds } from "./model";

const HOUR = 3600;
const NOW = Date.parse("2026-11-10T15:00:00Z");
const TODAY = "2026-11-10";
const INTERVAL_HOURS = 100;

// N206MA at 2341.2 h with an AD action repeating every 100 h, complied with
// at 2340 h on 1 Nov: next due 2440 h, 98.8 h remaining.
function aircraftWithRecentCompliance() {
  const s = demoSnapshot();
  s.inspections = [];
  s.flights = [];
  const a = s.aircraft[0];
  const r = blankAD(a.uuid);
  r.source.number = "2026-01-01";
  r.source.subject = "Repetitive inspection";
  r.source.recurring = "Yes";
  r.applicability = "Applicable";
  r.reviewRequired = false;
  r.tasks = [
    {
      ...blankADTask(),
      description: "Inspect",
      intervalHours: INTERVAL_HOURS,
      dueHours: 2340,
      recurrence: "Recurring",
    },
  ];
  applyADCommand(s, { kind: "save", record: r }, NOW);
  const saved = s.airworthiness![0];
  applyADCommand(
    s,
    {
      kind: "comply",
      uuid: saved.uuid,
      version: saved.version,
      entry: {
        uuid: crypto.randomUUID(),
        taskUuid: saved.tasks[0].uuid,
        date: "2026-11-01",
        hours: 2340,
        cycles: null,
        method: "Inspected per paragraph (g)",
        serviceBulletin: "",
        terminatedBy: "",
        workOrderUuid: "",
        mechanic: "A Mechanic",
        certificate: "",
        evidence: "",
        recordedAt: 0,
        recordedBy: "",
      },
    },
    NOW,
  );
  return { s, a };
}

describe("MX-16: aircraft total time corrected to below an AD compliance", () => {
  it("is refused, or at least never leaves more remaining than the interval", () => {
    const { s, a } = aircraftWithRecentCompliance();
    expect(totalSeconds(a) / HOUR).toBeCloseTo(2341.2);
    let refused = false;
    try {
      applyFleet(
        s,
        {
          requestUuid: crypto.randomUUID(),
          reason: "Total time corrected after a logbook audit",
          action: "aircraft.save",
          // 2341.2 h on the meter, corrected to 2000.0 h total.
          aircraft: aircraftInputSchema.parse({
            ...a,
            adjustmentSeconds: -341.2 * HOUR,
          }),
        },
        NOW,
      );
    } catch {
      // An inspection with compliance at 2340 h refuses this: "Correction
      // would move usage before recorded inspection compliance."
      refused = true;
    }
    if (refused) return;
    const ad = s.airworthiness![0];
    const [hours] = adRemaining(s, ad, ad.tasks[0], TODAY);
    expect(Number(hours.value)).toBeLessThanOrEqual(INTERVAL_HOURS);
  });
});
