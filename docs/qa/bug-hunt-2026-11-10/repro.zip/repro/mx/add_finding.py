import json, sys
H = "hunt"
f = json.load(sys.stdin)
base = {"area": "mx", "regression_of": None, "needs_owner_decision": False, "notes": ""}
base.update(f)
with open(H + "/findings/mx.jsonl", "a") as out:
    out.write(json.dumps(base, ensure_ascii=False) + "\n")
print("added", base["id"])
