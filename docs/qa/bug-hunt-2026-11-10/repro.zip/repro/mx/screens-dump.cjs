const fs = require("fs");
const L = require("./lib.cjs");
const { PATCH } = require("./states.cjs");
(async () => {
  const { browser, page, errors } = await L.start();
  await L.patchSnapshot(page, PATCH, { today: L.localDate(), yesterday: L.shiftDays(-1), tenAgo: L.shiftDays(-10) });
  const out = {};
  for (const route of ["/", "/aircraft", "/planning", "/inspections", "/airworthiness", "/components", "/alerts", "/discrepancies", "/board"]) {
    await page.goto(L.BASE + route);
    await page.waitForLoadState("networkidle").catch(() => {});
    await page.waitForTimeout(1200);
    const text = await page.locator("main").innerText().catch(async () => page.locator("body").innerText());
    out[route] = text;
    const name = route === "/" ? "overview" : route.slice(1);
    fs.writeFileSync(`${L.SHOTS}/mx-screens-${name}.txt`, text);
    await page.screenshot({ path: `${L.SHOTS}/mx-screens-${name}.png`, fullPage: true });
    console.log("==== " + route + " (" + text.length + " chars)");
  }
  console.log("page errors:", errors);
  await browser.close();
})();
