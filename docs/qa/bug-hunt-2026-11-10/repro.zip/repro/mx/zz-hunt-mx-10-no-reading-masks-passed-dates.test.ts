/**
 * Responsibility: Repro MX-10. RM-66 made a calendar-only inspection go
 *   overdue on an aircraft whose meter has no reading; an hours-or-calendar
 *   inspection, a component calendar limit and an AD cycles or landings
 *   limit on the same aircraft still stay "unknown" past their limits.
 * Layer: Test. Bug-hunt repro (2026-11-10); asserts the correct behaviour,
 *   so it fails while the bug exists.
 * Dependencies: src/domain/aircraftStatus.ts, dueItems.ts,
 *   tests/fixtures/dueFleet.ts.
 *
 * Run: cp <this file> src/domain/ && npx vitest run
 *   src/domain/zz-hunt-mx-10-no-reading-masks-passed-dates.test.ts
 */
import { describe, expect, it } from "vitest";
import {
  DUE_FLEET_TODAY,
  dueFleet,
  withoutMeterReading,
} from "../../tests/fixtures/dueFleet";
import { aircraftStatus } from "./aircraftStatus";
import { dueItems } from "./dueItems";

const HOUR = 3600;

function unreadFleet() {
  const { s, c } = dueFleet();
  s.inspections = [];
  s.airworthiness = [];
  s.management = [];
  withoutMeterReading(s, c);
  s.inspections = [];
  s.airworthiness = [];
  return { s, c };
}

const levels = (s: Parameters<typeof dueItems>[0], uuid: string) =>
  dueItems(s, uuid, DUE_FLEET_TODAY).map((d) => d.level);

describe("MX-10: limits already passed on an aircraft whose meter has no reading", () => {
  it("an hours-or-calendar inspection past its due date is overdue and grounds", () => {
    const { s, c } = unreadFleet();
    s.inspections = [
      {
        uuid: "i-annual-100",
        aircraftUuid: c.uuid,
        reference: "Annual / 100-hour",
        description: "Hours or calendar, whichever first",
        dueSeconds: 5000 * HOUR,
        dueDate: "2020-01-01",
      },
    ];
    expect(levels(s, c.uuid)).toEqual(["overdue"]);
    expect(aircraftStatus(s, c.uuid, DUE_FLEET_TODAY).level).toBe("grounded");
  });

  it("a component calendar limit past its due date is overdue and grounds", () => {
    const { s, c } = unreadFleet();
    const fleet = dueFleet().s.management!;
    const pump = fleet.find((r) => r.uuid === "pump")!;
    const limit = fleet.find((r) => r.uuid === "r-today")!;
    s.management = [
      { ...pump, aircraftUuid: c.uuid },
      { ...limit, aircraftUuid: c.uuid, dueDate: "2020-01-01" },
    ] as typeof fleet;
    expect(levels(s, c.uuid)).toEqual(["overdue"]);
    expect(aircraftStatus(s, c.uuid, DUE_FLEET_TODAY).level).toBe("grounded");
  });

  it("an aircraft AD whose landings limit is reached is overdue and grounds", () => {
    const { s, c } = unreadFleet();
    const base = dueFleet().s.airworthiness!.find(
      (r) => r.uuid === "ad-overdue",
    )!;
    s.airworthiness = [
      {
        ...base,
        aircraftUuid: c.uuid,
        tasks: [
          {
            ...base.tasks[0],
            dueDate: "",
            intervalDays: null,
            dueLandings: c.landings - 1,
          },
        ],
      },
    ];
    expect(levels(s, c.uuid)).toEqual(["overdue"]);
    expect(aircraftStatus(s, c.uuid, DUE_FLEET_TODAY).level).toBe("grounded");
  });
});
