// Seven demo aircraft, each in exactly one maintenance state, built by
// patching the demo snapshot. `today` is the browser's local date.
const PATCH = `
const { today, yesterday } = arg;
const base = s.aircraft.find((a) => a.uuid === "demo-206");
const mk = (n, reg, extra) => ({ ...base, uuid: "hunt-" + n, registration: reg, serial: "HUNT-" + n, operationalStatus: "airworthy", ...extra });
const total = base.currentHobbs;
s.aircraft = [
  mk(1, "N1RM66", { flightTimeLog: true, meter: "flightTimeLog", currentFlightTimeLog: undefined }),
  mk(2, "N2ZERO"), mk(3, "N3TODAY"), mk(4, "N4AD"), mk(5, "N5COMP"), mk(6, "N6DISC"), mk(7, "N7MEL"), mk(8, "N8OK"),
];
delete s.aircraft[0].currentFlightTimeLog;
for (const g of s.groups) g.aircraftIds = s.aircraft.map((a) => a.uuid);
s.flights = []; s.workOrders = []; s.taskCards = []; s.flightPlans = []; s.partsRequests = [];
const insp = (n, ref, f) => ({ uuid: "hunt-insp-" + n, aircraftUuid: "hunt-" + n, reference: ref, description: ref + " description", ...f });
s.inspections = [
  insp(1, "RM66 annual by date", { dueDate: yesterday }),
  insp(2, "Zero hours inspection", { dueSeconds: total }),
  insp(3, "Due today annual", { dueDate: today }),
  insp(8, "Far annual", { dueDate: "2030-01-31" }),
];
s.airworthiness = [{
  uuid: "11111111-1111-4111-8111-111111111104", version: 1, programUuid: "demo-program", aircraftUuid: "hunt-4", componentUuid: "",
  source: { number: "2026-04-04", amendment: "", issued: "", effective: "", subject: "Hunt AD", recurring: "Yes", supersededBy: "", url: "", source: "Manual entry", section: "Airframe", make: "", model: "", sourceNotes: "" },
  applicability: "Applicable", reason: "", history: [], sourceHistory: [], reviewRequired: false, updatedAt: 0,
  tasks: [{ uuid: "22222222-2222-4222-8222-222222222204", description: "Inspect bracket", dueDate: yesterday, dueHours: null, dueCycles: null, intervalDays: null, intervalHours: null, intervalCycles: null, recurrence: "Recurring", workOrderUuid: "" }],
}];
s.management = [
  { uuid: "hunt-comp-5", version: 1, kind: "component", programUuid: "demo-program", aircraftUuid: "hunt-5", componentType: "Fuel pump", partNumber: "PN-5", serial: "SN-5", manufacturer: "", notes: "", trackTime: true, trackCycles: true, trackCalendar: true, installed: true, installedDate: "2026-01-01", installPosition: "Engine", installedSeconds: total - 36000, installedCycles: base.cycles, timeSinceNew: 360000, timeSinceOverhaul: null, timeSinceRepair: null, cyclesSinceNew: 20, serviceDaysBase: 0 },
  { uuid: "hunt-req-5", version: 1, kind: "componentRequirement", programUuid: "demo-program", componentUuid: "hunt-comp-5", aircraftUuid: "hunt-5", requirementType: "Life Limits", description: "Pump life limit", notes: "", calendarIntervalUnit: "MONTHS", timeBasis: "TSN", timeLimitMode: "ABSOLUTE", cycleLimitMode: "ABSOLUTE", intervalSeconds: 378000, dueSeconds: 378000, warningCalendarMonths: 0, warningSeconds: 36000, warningCycles: 0 },
];
const now = Date.now();
s.discrepancies = [
  { uuid: "hunt-disc-6", aircraftUuid: "hunt-6", description: "Hunt: cracked exhaust stack", status: "open", authorId: "demo-admin", createdAt: now - 86400000, grounding: true },
  { uuid: "hunt-disc-7", aircraftUuid: "hunt-7", description: "Hunt: cabin light inoperative", status: "open", authorId: "demo-admin", createdAt: now - 10 * 86400000,
    deferral: { type: "mel", melItem: "33-1", category: "B", placard: "INOP", deferredOn: arg.tenAgo, deferredAt: now - 10 * 86400000, deferredBy: "demo-admin", deferredByName: "Alex Morgan", expiresOn: yesterday } },
];
`;
// What every screen should say for each aircraft.
const EXPECTED = {
  N1RM66: "grounded", N2ZERO: "grounded", N3TODAY: "due-soon", N4AD: "grounded",
  N5COMP: "grounded", N6DISC: "grounded", N7MEL: "grounded", N8OK: "airworthy",
};
module.exports = { PATCH, EXPECTED };
