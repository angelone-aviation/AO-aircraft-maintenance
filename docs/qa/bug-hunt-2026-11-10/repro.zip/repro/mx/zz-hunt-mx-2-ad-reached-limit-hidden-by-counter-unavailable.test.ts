/**
 * Responsibility: Repro MX-2. An AD action whose cycles or landings limit is
 *   reached reads "Counter unavailable" when its hours limit cannot be read.
 * Layer: Test. Bug-hunt repro (2026-11-10); asserts the correct behaviour,
 *   so it fails while the bug exists.
 * Dependencies: src/domain/airworthiness.ts, aircraftStatus.ts, alerts.ts,
 *   tests/fixtures/dueFleet.ts.
 *
 * Run: cp <this file> src/domain/ && npx vitest run
 *   src/domain/zz-hunt-mx-2-ad-reached-limit-hidden-by-counter-unavailable.test.ts
 */
import { describe, expect, it } from "vitest";
import { DUE_FLEET_TODAY, dueFleet } from "../../tests/fixtures/dueFleet";
import { adTaskStatus } from "./airworthiness";
import { aircraftStatus } from "./aircraftStatus";
import { computeAlerts } from "./alerts";

// "ad-counter" is on the installed component "cycles-only" (20 cycles since
// new, time not tracked) with an hours limit, so its hours cannot be read.
function fleetWithReachedLimit(limit: "dueCycles" | "dueLandings") {
  const { s, a } = dueFleet();
  s.airworthiness = s.airworthiness!.filter((r) => r.uuid === "ad-counter");
  const ad = s.airworthiness[0];
  // Whichever occurs first: 500 hours, or a cycles/landings limit long passed.
  ad.tasks[0][limit] = 1;
  return { s, a, ad };
}

describe("MX-2: a reached usage limit on an AD action whose hours counter is unavailable", () => {
  it.each(["dueCycles", "dueLandings"] as const)(
    "%s reached reads Overdue, grounds the aircraft and alerts",
    (limit) => {
      const { s, a, ad } = fleetWithReachedLimit(limit);
      expect(adTaskStatus(s, ad, ad.tasks[0], DUE_FLEET_TODAY)).toBe("Overdue");
      expect(
        aircraftStatus(s, a.uuid, DUE_FLEET_TODAY).reasons.map((r) => r.label),
      ).toContain("AD AD-COUNTER overdue");
      expect(computeAlerts(s, DUE_FLEET_TODAY).map((x) => x.kind)).toContain(
        "ad-overdue",
      );
    },
  );
});
