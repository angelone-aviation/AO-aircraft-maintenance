const L = require("./lib.cjs");
const { PATCH } = require("./states.cjs");
(async () => {
  const { browser, page, errors } = await L.start();
  const variant = process.argv[2] || "all";
  let patch = PATCH;
  if (variant === "nometer") patch = `const a = s.aircraft[0]; a.flightTimeLog = true; a.meter = "flightTimeLog"; delete a.currentFlightTimeLog;`;
  if (variant === "none") patch = `s.syncedAt = s.syncedAt;`;
  page.on("console", (m) => { if (m.type() === "error") console.log("console.error:", m.text().slice(0, 600)); });
  await L.patchSnapshot(page, patch, { today: L.localDate(), yesterday: L.shiftDays(-1), tenAgo: L.shiftDays(-10) });
  await page.goto(L.BASE + "/aircraft");
  await page.waitForTimeout(1500);
  let text = await page.locator("body").innerText();
  console.log(variant, "=>", text.includes("Something went wrong") ? "CRASH" : "ok", text.slice(0, 200).replace(/\n/g, " | "));
  const show = page.getByText("Show Error");
  if (await show.count()) { await show.click(); await page.waitForTimeout(300); console.log((await page.locator("body").innerText()).slice(0, 1500)); }
  console.log("pageerrors", errors.slice(0, 3));
  await browser.close();
})();
