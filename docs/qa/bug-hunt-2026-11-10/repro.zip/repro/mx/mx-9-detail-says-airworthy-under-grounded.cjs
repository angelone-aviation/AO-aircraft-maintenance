// MX-9: View aircraft for a grounded aircraft prints "Aircraft status:
// airworthy." (the profile field) under the Grounded badge and its reason.
// Run: node <this file>
const L = require("./lib.cjs");
(async () => {
  const { browser, page } = await L.start();
  let bug = false, msg = "";
  try {
    await L.patchSnapshot(page, `const a = s.aircraft.find((a) => a.uuid === "demo-182"); a.operationalStatus = "airworthy"; s.inspections.find((i) => i.uuid === "demo-insp-4").dueDate = arg;`, L.shiftDays(-1));
    const card = page.locator(".dash-card").filter({ hasText: "N182MA" });
    const cardText = (await card.innerText()).replace(/\n+/g, " | ");
    await card.getByRole("button", { name: /View aircraft/ }).first().click();
    const dlg = page.getByRole("dialog").first();
    await dlg.waitFor();
    const text = (await dlg.innerText()).replace(/\n+/g, " | ");
    await page.screenshot({ path: L.SHOTS + "/mx-9-detail.png" });
    console.log("Card:", cardText.slice(0, 200));
    console.log("Detail:", text.slice(0, 330));
    if (/^Grounded/.test(text) && /Aircraft status: airworthy\./.test(text)) {
      bug = true;
      msg = `aircraft detail badge "Grounded" with status note "Annual inspection overdue", followed by "Aircraft status: airworthy."`;
    }
  } finally {
    await browser.close();
  }
  L.result(bug, msg);
})();
