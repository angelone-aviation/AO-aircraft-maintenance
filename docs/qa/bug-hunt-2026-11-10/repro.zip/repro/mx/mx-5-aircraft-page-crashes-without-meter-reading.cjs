// MX-5: the Aircraft page (/aircraft) fails with "Something went wrong!" when
// one aircraft's time-source meter has no reading (the RM-66 state), so the
// reading cannot be entered through Edit aircraft. Run: node <this file>
const L = require("./lib.cjs");
(async () => {
  const { browser, page } = await L.start();
  let bug = false, msg = "";
  try {
    await L.patchSnapshot(page, `const a = s.aircraft.find((a) => a.uuid === "demo-182"); a.flightTimeLog = true; a.meter = "flightTimeLog"; delete a.currentFlightTimeLog;`);
    const overview = await page.locator("main").innerText();
    await page.goto(L.BASE + "/aircraft");
    await page.waitForTimeout(1500);
    const body = await page.locator("body").innerText();
    await page.screenshot({ path: L.SHOTS + "/mx-5-aircraft-page.png" });
    const crashed = body.includes("Something went wrong");
    const editable = await page.getByRole("button", { name: /Edit aircraft/ }).count();
    console.log("Overview renders:", overview.includes("N182MA"), "| /aircraft crashed:", crashed, "| Edit aircraft buttons:", editable);
    if (crashed) {
      await page.getByText("Show Error").click().catch(() => {});
      const detail = (await page.locator("body").innerText()).replace(/\n+/g, " | ").slice(0, 160);
      bug = true;
      msg = `Overview shows N182MA, but /aircraft shows "${detail}" and no Edit aircraft button for any aircraft`;
    }
  } finally {
    await browser.close();
  }
  L.result(bug, msg);
})();
