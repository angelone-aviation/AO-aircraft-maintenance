/**
 * Responsibility: Repro MX-13. A component overhaul, repair or baseline
 *   recorded directly (not through a work order) in the evening in a US time
 *   zone gets a movement-history entry dated the next day (the server's UTC
 *   date), not the date the user entered.
 * Layer: Test. Bug-hunt repro (2026-11-10), convex-test; asserts the correct
 *   behaviour, so it fails while the bug exists.
 * Dependencies: convex/management.ts, convex/schema.ts, src/data/demo.ts,
 *   tests/fixtures/workOrders.ts.
 *
 * Run: cp <this file> convex/ && npx vitest run
 *   convex/zz-hunt-mx-13-movement-dated-utc-tomorrow.test.ts
 */
import { convexTest } from "convex-test";
import { afterEach, expect, it, vi } from "vitest";
import schema from "./schema";
import { api } from "./_generated/api";
import { demoSnapshot } from "../src/data/demo";
import { workOrderComponent } from "../tests/fixtures/workOrders";

const modules = import.meta.glob([
  "./**/*.ts",
  "./_generated/*.js",
  "!./**/*.test.ts",
  "!./**/*.d.ts",
]);
const PROGRAM = "demo-program";
// 18:00 on 10 Nov in Los Angeles, 21:00 in New York.
const EVENING = Date.parse("2026-11-11T02:00:00Z");
const USER_TODAY = "2026-11-10";

afterEach(() => vi.useRealTimers());

it("dates the overhaul's movement entry on the date the mechanic entered", async () => {
  vi.useFakeTimers({ toFake: ["Date"] });
  vi.setSystemTime(EVENING);
  const t = convexTest(schema, modules);
  const s = demoSnapshot();
  // On the shelf, so it can be overhauled directly.
  const component = {
    ...workOrderComponent(),
    programUuid: PROGRAM,
    installed: false,
    partsLocation: "Shelf 1",
  };
  const identity = await t.run(async (ctx) => {
    await ctx.db.insert("aircraft", s.aircraft[0]);
    await ctx.db.insert("programs", s.programs![0]);
    await ctx.db.insert("management", {
      uuid: component.uuid,
      kind: component.kind,
      aircraftUuid: component.aircraftUuid,
      programUuid: PROGRAM,
      payload: JSON.stringify(component),
    });
    const user = await ctx.db.insert("users", {
      name: "Admin",
      active: true,
      isAdmin: true,
      groupIds: [],
    });
    const session = await ctx.db.insert("authSessions", {
      userId: user,
      expirationTime: Date.now() + 86_400_000,
    });
    return { subject: `${user}|${session}` };
  });
  const admin = t.withIdentity(identity);
  await admin.mutation(api.management.execute, {
    programUuid: PROGRAM,
    payload: JSON.stringify({
      requestUuid: crypto.randomUUID(),
      reason: "Overhauled by shop, 8130 on file",
      action: "component.service",
      uuid: component.uuid,
      version: component.version,
      operation: "overhaul",
      date: USER_TODAY,
    }),
  });
  const after = (await admin.query(api.operations.snapshot, {}))!;
  const saved = after.management!.find((r) => r.uuid === component.uuid);
  const movement = after.management!.find(
    (r) => r.kind === "componentMovement",
  );
  // The component itself keeps the entered date.
  expect(saved).toMatchObject({ calendarOverhaulDate: USER_TODAY });
  expect(movement).toMatchObject({ action: "OVERHAUL", date: USER_TODAY });
});
