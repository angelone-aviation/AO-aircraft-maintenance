/**
 * Responsibility: Repro MX-6 and MX-7. The aircraft status sheet (PDF, and
 *   the records package's status tables) leaves out what grounds the
 *   aircraft: a component past its life limit, a grounding discrepancy's
 *   flag, and an expired MEL deferral.
 * Layer: Test. Bug-hunt repro (2026-11-10); asserts the correct behaviour,
 *   so it fails while the bug exists.
 * Dependencies: src/domain/statusSheet.ts, aircraftStatus.ts,
 *   tests/fixtures/dueFleet.ts.
 *
 * Run: cp <this file> src/domain/ && npx vitest run
 *   src/domain/zz-hunt-mx-6-status-sheet-omits-grounding-items.test.ts
 */
import { describe, expect, it } from "vitest";
import { DUE_FLEET_TODAY, dueFleet } from "../../tests/fixtures/dueFleet";
import { aircraftStatus } from "./aircraftStatus";
import { statusSheet } from "./statusSheet";

const sheetText = (s: Parameters<typeof statusSheet>[0], uuid: string) =>
  JSON.stringify(statusSheet(s, uuid, DUE_FLEET_TODAY));

describe("MX-6: a component past its life limit on the status sheet", () => {
  it("is shown with its limit and an overdue status (91.417(a)(2)(ii), ADR-0004)", () => {
    const { s, a } = dueFleet();
    s.inspections = [];
    s.airworthiness = [];
    // Keep only the pump and its hours life limit, 5 hours past.
    s.management = s.management!.filter(
      (r) => r.uuid === "pump" || r.uuid === "r-now",
    );
    const limit = s.management.find((r) => r.uuid === "r-now")!;
    Object.assign(limit, { dueSeconds: 95 * 3600 });
    expect(aircraftStatus(s, a.uuid, DUE_FLEET_TODAY)).toMatchObject({
      level: "grounded",
      reasons: [{ label: "Type pump S/N SN-pump: r-now limit past due" }],
    });
    const text = sheetText(s, a.uuid);
    expect(text).toContain("r-now limit");
    expect(text).toMatch(/past due|overdue/i);
  });
});

describe("MX-7: what grounds the aircraft among its open discrepancies", () => {
  it("marks a grounding discrepancy as grounding", () => {
    const { s, a } = dueFleet();
    s.inspections = [];
    s.discrepancies = [
      {
        uuid: "d-ground",
        aircraftUuid: a.uuid,
        description: "Cracked exhaust stack",
        status: "open",
        authorId: s.user.id,
        createdAt: Date.parse("2026-10-29T12:00:00Z"),
        grounding: true,
      },
    ];
    const rows = statusSheet(s, a.uuid, DUE_FLEET_TODAY).sections.find(
      (x) => x.id === "discrepancies",
    )!.rows;
    expect(JSON.stringify(rows)).toMatch(/ground/i);
  });

  it("shows an MEL deferral and that it has expired", () => {
    const { s, a } = dueFleet();
    s.inspections = [];
    s.discrepancies = [
      {
        uuid: "d-mel",
        aircraftUuid: a.uuid,
        description: "Cabin light inoperative",
        status: "open",
        authorId: s.user.id,
        createdAt: Date.parse("2026-10-20T12:00:00Z"),
        deferral: {
          type: "mel",
          melItem: "33-1",
          category: "B",
          placard: "INOP",
          deferredOn: "2026-10-20",
          deferredAt: Date.parse("2026-10-20T12:00:00Z"),
          deferredBy: s.user.id,
          deferredByName: s.user.name,
          expiresOn: "2026-10-23",
        },
      },
    ];
    const rows = statusSheet(s, a.uuid, DUE_FLEET_TODAY).sections.find(
      (x) => x.id === "discrepancies",
    )!.rows;
    expect(JSON.stringify(rows)).toMatch(/MEL 33-1|deferr/i);
    expect(JSON.stringify(rows)).toContain("2026-10-23");
  });
});
