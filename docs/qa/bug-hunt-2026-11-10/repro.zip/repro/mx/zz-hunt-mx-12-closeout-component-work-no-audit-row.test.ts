/**
 * Responsibility: Repro MX-12. A component overhauled (or installed,
 *   removed, repaired) at work-order close-out gets no change-log row of its
 *   own, so the component's Change history never shows it.
 * Layer: Test. Bug-hunt repro (2026-11-10), convex-test; asserts the correct
 *   behaviour, so it fails while the bug exists.
 * Dependencies: convex/workOrders.ts, convex/schema.ts, src/data/demo.ts,
 *   tests/fixtures/workOrders.ts.
 *
 * Run: cp <this file> convex/ && npx vitest run
 *   convex/zz-hunt-mx-12-closeout-component-work-no-audit-row.test.ts
 */
import { convexTest } from "convex-test";
import { expect, it } from "vitest";
import schema from "./schema";
import { api } from "./_generated/api";
import { demoSnapshot } from "../src/data/demo";
import {
  workOrderCommand,
  workOrderComponent,
} from "../tests/fixtures/workOrders";

const modules = import.meta.glob([
  "./**/*.ts",
  "./_generated/*.js",
  "!./**/*.test.ts",
  "!./**/*.d.ts",
]);
const PROGRAM = "demo-program";
const DAY_MS = 86_400_000;
const today = () => new Date().toISOString().slice(0, 10);

it("writes a change-log row for the component a close-out overhauls", async () => {
  const t = convexTest(schema, modules);
  const s = demoSnapshot();
  const component = { ...workOrderComponent(), programUuid: PROGRAM };
  const identity = await t.run(async (ctx) => {
    for (const a of s.aircraft) await ctx.db.insert("aircraft", a);
    await ctx.db.insert("programs", s.programs![0]);
    await ctx.db.insert("management", {
      uuid: component.uuid,
      kind: component.kind,
      aircraftUuid: component.aircraftUuid,
      programUuid: PROGRAM,
      payload: JSON.stringify(component),
    });
    const group = await ctx.db.insert("groups", {
      programUuid: PROGRAM,
      name: "Maintenance",
      aircraftIds: [s.aircraft[0].uuid],
      permissions: ["read", "maintenance"],
    });
    const user = await ctx.db.insert("users", {
      name: "Tech",
      active: true,
      isAdmin: false,
      groupIds: [group],
    });
    const session = await ctx.db.insert("authSessions", {
      userId: user,
      expirationTime: Date.now() + DAY_MS,
    });
    return { subject: `${user}|${session}` };
  });
  const tech = t.withIdentity(identity);
  const send = (payload: unknown) =>
    tech.mutation(api.workOrders.save, {
      programUuid: PROGRAM,
      payload: JSON.stringify(payload),
    });
  const open = workOrderCommand();
  open.fields.dateOpened = today();
  open.componentUuids = [component.uuid];
  await send(open);
  await send({
    ...open,
    version: 1,
    fields: {
      ...open.fields,
      status: "completed",
      completionDate: today(),
      releaseOutcome: "Reviewed",
      finalReview: "Reviewed",
    },
    componentWork: [
      {
        componentUuid: component.uuid,
        version: component.version,
        action: "overhaul",
        description: "Overhauled",
        reference: "AMM 72",
      },
    ],
  });
  const after = (await tech.query(api.operations.snapshot, {}))!;
  // The record did change: time since overhaul reset, version advanced.
  expect(
    after.management!.find((r) => r.uuid === component.uuid),
  ).toMatchObject({ timeSinceOverhaul: 0, version: component.version + 1 });
  const rows = await t.run((ctx) =>
    ctx.db
      .query("audit")
      .withIndex("entity", (q) => q.eq("entityUuid", component.uuid))
      .collect(),
  );
  expect(rows.map((r) => r.action)).not.toEqual([]);
});
