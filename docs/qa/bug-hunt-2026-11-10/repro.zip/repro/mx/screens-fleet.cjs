const L = require("./lib.cjs");
const { PATCH } = require("./states.cjs");
(async () => {
  const { browser, page, errors } = await L.start();
  await L.patchSnapshot(page, PATCH + `; s.aircraft[0].meter = "hobbs"; s.aircraft[0].flightTimeLog = false;`, { today: L.localDate(), yesterday: L.shiftDays(-1), tenAgo: L.shiftDays(-10) });
  await page.goto(L.BASE + "/aircraft");
  await page.waitForTimeout(1500);
  console.log((await page.locator("main").innerText()).replace(/\n+/g, " | ").slice(0, 3000));
  await page.screenshot({ path: `${L.SHOTS}/mx-screens-aircraft-page.png`, fullPage: true });
  await browser.close();
})();
