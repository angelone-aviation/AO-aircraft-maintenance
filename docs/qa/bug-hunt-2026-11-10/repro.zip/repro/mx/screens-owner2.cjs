const fs = require("fs");
const L = require("./lib.cjs");
const { PATCH } = require("./states.cjs");
(async () => {
  const { browser, page, errors } = await L.start();
  await L.patchSnapshot(page, PATCH, { today: L.localDate(), yesterday: L.shiftDays(-1), tenAgo: L.shiftDays(-10) });
  await page.goto(L.BASE + "/");
  await page.getByRole("button", { name: "Preview owner portal" }).click();
  await page.waitForTimeout(1500);
  await L.patchSnapshot(page, `for (const g of s.groups) g.aircraftIds = arg;`, ["hunt-1","hunt-2","hunt-3","hunt-4","hunt-5","hunt-6","hunt-7","hunt-8"]);
  await page.waitForTimeout(1500);
  const owner = await page.locator("main").innerText().catch(() => page.locator("body").innerText());
  fs.writeFileSync(`${L.SHOTS}/mx-screens-owner.txt`, owner);
  console.log("#### OWNER\n" + owner.replace(/\n+/g, " | ").slice(0, 6000));
  await page.screenshot({ path: `${L.SHOTS}/mx-screens-owner.png`, fullPage: true });
  console.log("errors", errors);
  await browser.close();
})();
