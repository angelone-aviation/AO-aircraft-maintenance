/**
 * Responsibility: Repro MX-14. Set baseline accepts component totals below a
 *   service requirement's recorded last compliance, leaving the requirement
 *   with more time and cycles remaining than its whole interval.
 * Layer: Test. Bug-hunt repro (2026-11-10); asserts the correct behaviour,
 *   so it fails while the bug exists.
 * Dependencies: src/domain/management.ts, components.ts, model.ts,
 *   tests/fixtures/workOrders.ts, src/data/demo.ts.
 *
 * Run: cp <this file> src/domain/ && npx vitest run
 *   src/domain/zz-hunt-mx-14-baseline-below-requirement-compliance.test.ts
 */
import { describe, expect, it } from "vitest";
import { workOrderComponent } from "../../tests/fixtures/workOrders";
import { demoSnapshot } from "../data/demo";
import {
  requirementSchema,
  requirementStatus,
  type Component,
  type ComponentRequirement,
} from "./components";
import { applyManagement } from "./management";
import { totalSeconds } from "./model";

const HOUR = 3600;
const NOW = Date.parse("2026-11-10T15:00:00Z");
const TODAY = "2026-11-10";
const INTERVAL_HOURS = 100;
const INTERVAL_CYCLES = 100;

// An engine at 500 h and 410 cycles since new, inspected every 100 h or 100
// cycles, last at 480 h and 390 cycles: 80 h and 80 cycles remain.
function engineWithRecentCompliance() {
  const s = demoSnapshot();
  s.inspections = [];
  const a = s.aircraft[0];
  const engine: Component = {
    ...workOrderComponent(),
    programUuid: "demo-program",
    installPosition: "LEFT",
    timeSinceNew: 490 * HOUR,
    cyclesSinceNew: 400,
  };
  const requirement = requirementSchema.parse({
    uuid: "every-100",
    kind: "componentRequirement",
    version: 1,
    componentUuid: engine.uuid,
    aircraftUuid: a.uuid,
    programUuid: "demo-program",
    requirementType: "Inspection Requirement",
    description: "Inspect every 100 h or 100 cycles",
    notes: "",
    calendarIntervalUnit: "MONTHS",
    timeBasis: "TSN",
    timeLimitMode: "FROM_LAST_COMPLIED",
    cycleLimitMode: "FROM_LAST_COMPLIED",
    intervalSeconds: INTERVAL_HOURS * HOUR,
    lastSeconds: 480 * HOUR,
    dueSeconds: 580 * HOUR,
    intervalCycles: INTERVAL_CYCLES,
    lastCycles: 390,
    dueCycles: 490,
    warningCalendarMonths: 0,
    warningSeconds: 10 * HOUR,
    warningCycles: 5,
  });
  s.management = [engine, requirement];
  return { s, a, engine };
}

describe("MX-14: Set baseline to totals below a requirement's last compliance", () => {
  it("is refused, or at least never leaves more remaining than the interval", () => {
    const { s, a, engine } = engineWithRecentCompliance();
    const rebaseline = () =>
      applyManagement(
        s,
        {
          requestUuid: crypto.randomUUID(),
          reason: "Verified against the engine logbook",
          action: "component.baseline",
          uuid: engine.uuid,
          version: engine.version,
          installedSeconds: totalSeconds(a),
          installedCycles: a.cycles,
          timeSinceNew: 300 * HOUR,
          timeSinceOverhaul: 20 * HOUR,
          timeSinceRepair: null,
          cyclesSinceNew: 200,
          serviceDaysBase: 0,
          installedDate: TODAY,
        },
        NOW,
      );
    let refused = false;
    try {
      rebaseline();
    } catch {
      // The same baseline is refused when an inspection schedule records the
      // compliance: "Baseline would precede recorded inspection compliance."
      refused = true;
    }
    if (refused) return;
    const component = s.management!.find(
      (r) => r.uuid === engine.uuid,
    ) as Component;
    const requirement = s.management!.find(
      (r) => r.uuid === "every-100",
    ) as ComponentRequirement;
    const left = requirementStatus(requirement, component, a, TODAY);
    expect(left.seconds! / HOUR).toBeLessThanOrEqual(INTERVAL_HOURS);
    expect(left.cycles).toBeLessThanOrEqual(INTERVAL_CYCLES);
  });
});
