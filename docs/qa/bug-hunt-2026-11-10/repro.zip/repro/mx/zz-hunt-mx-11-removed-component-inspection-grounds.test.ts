/**
 * Responsibility: Repro MX-11. An overdue inspection of a component that has
 *   been removed to storage still grounds the aircraft it came off, unlike
 *   that component's service requirements and ADs.
 * Layer: Test. Bug-hunt repro (2026-11-10); asserts the correct behaviour,
 *   so it fails while the bug exists.
 * Dependencies: src/domain/aircraftStatus.ts, dueItems.ts, workOrders.ts,
 *   tests/fixtures/workOrders.ts, src/data/demo.ts.
 *
 * Run: cp <this file> src/domain/ && npx vitest run
 *   src/domain/zz-hunt-mx-11-removed-component-inspection-grounds.test.ts
 */
import { describe, expect, it } from "vitest";
import {
  workOrderCommand,
  workOrderComponent,
} from "../../tests/fixtures/workOrders";
import { demoSnapshot } from "../data/demo";
import { aircraftStatus, dispatchGate } from "./aircraftStatus";
import type { Component } from "./components";
import {
  newWorkTask,
  saveWorkOrder,
  workOrderFieldsSchema,
} from "./workOrders";

const NOW = Date.parse("2026-11-10T15:00:00Z");
const TODAY = "2026-11-10";
const HOUR = 3600;

// The engine (TSN 110 h) carries a borescope inspection due at 105 h TSN,
// already overdue, and is then removed to a shelf through a work order.
function removeEngineWithOverdueInspection() {
  const s = demoSnapshot();
  const a = s.aircraft[0];
  s.discrepancies = [];
  const engine: Component = { ...workOrderComponent(), programUuid: "demo-program" };
  s.management = [engine];
  s.inspections = [
    {
      uuid: "engine-borescope",
      aircraftUuid: a.uuid,
      componentUuid: engine.uuid,
      reference: "Engine borescope",
      description: "Engine S/N SN, by time since new",
      dueSeconds: 105 * HOUR,
    },
  ];
  const open = workOrderCommand();
  open.fields.dateOpened = "2026-11-01";
  open.tasks = [
    newWorkTask(
      { kind: "manual", uuid: crypto.randomUUID() },
      "Remove engine for exchange",
    ),
  ];
  const order = saveWorkOrder(s, open, NOW);
  saveWorkOrder(
    s,
    {
      action: "save",
      uuid: order.uuid,
      version: order.version,
      componentUuids: [],
      fields: {
        ...workOrderFieldsSchema.parse(order),
        status: "completed",
        completionDate: TODAY,
        releaseOutcome: "Engine removed",
        finalReview: "Reviewed",
      },
      tasks: order.tasks.map((t) => ({ ...t, status: "completed" as const })),
      componentWork: [
        {
          componentUuid: engine.uuid,
          version: engine.version,
          action: "remove",
          description: "Removed for exchange",
          reference: "",
          taskUuid: order.tasks[0].uuid,
          partsLocation: "Shelf 1",
        },
      ],
    },
    NOW,
  );
  return { s, a };
}

describe("MX-11: an overdue inspection of a component removed to storage", () => {
  it("was grounding the aircraft while the engine was installed (control)", () => {
    const s = demoSnapshot();
    const a = s.aircraft[0];
    s.discrepancies = [];
    s.management = [{ ...workOrderComponent(), programUuid: "demo-program" }];
    s.inspections = [
      {
        uuid: "engine-borescope",
        aircraftUuid: a.uuid,
        componentUuid: "engine",
        reference: "Engine borescope",
        description: "Engine S/N SN",
        dueSeconds: 105 * HOUR,
      },
    ];
    expect(aircraftStatus(s, a.uuid, TODAY).level).toBe("grounded");
  });

  it("does not ground or dispatch-block the aircraft the engine came off", () => {
    const { s, a } = removeEngineWithOverdueInspection();
    const engine = s.management!.find((r) => r.uuid === "engine") as Component;
    expect(engine.installed).toBe(false);
    expect(aircraftStatus(s, a.uuid, TODAY)).toEqual({
      level: "airworthy",
      reasons: [],
    });
    expect(() => dispatchGate(s, a.uuid, undefined, TODAY, NOW)).not.toThrow();
  });
});
