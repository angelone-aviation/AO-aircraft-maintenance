#!/usr/bin/env bash
# Size test repro: loads N years of realistic history into a LOCAL Convex
# backend and shows the first limit the workspace snapshot hits.
#
# From a clean checkout at 73e51a9 (with node_modules), nothing else running
# on ports 3210/3211:
#   bash <H>/repro/size/run.sh /path/to/checkout [years=3]
# Prints "REPRODUCED: ..." and exits 1 while the snapshot fails at that size;
# prints "NOT REPRODUCED" and exits 0 once it is served.
# It starts `npm run dev:local` itself, wipes that checkout's local Convex
# database first, and leaves the backend running (stop it with the printed
# pid). Never run it against anything but a local backend: every script
# refuses a non-local VITE_CONVEX_URL.
set -euo pipefail
WT="$(cd "${1:?checkout path}" && pwd)"; YEARS="${2:-3}"
HERE="$(cd "$(dirname "$0")" && pwd)"
export LT="${LT:-$(mktemp -d)}"
mkdir -p "$LT/results" "$WT/loadtest"
cp -r "$HERE/loadtest/." "$WT/loadtest/"; cp "$HERE/profile.json" "$LT/profile.json"
cd "$WT"
rm -f .convex/local/default/convex_local_backend.sqlite3 .env.local-admin.json
rm -rf .convex/local/default/convex_local_storage
npm run dev:local > "$LT/backend.log" 2>&1 & echo "backend pid $! (log: $LT/backend.log)"
until grep -q "Convex functions ready" "$LT/backend.log"; do sleep 2; done
npm run setup:auth >/dev/null && npm run test:local >/dev/null
node loadtest/seed.mjs            # program, 6 aircraft, users: through the real API
bash loadtest/gen/run.sh >/dev/null   # 20 yearly slices of import rows (zod-checked)
node loadtest/load.mjs init       # fixed records + aircraft end state
node loadtest/load.mjs step 1 && node loadtest/measure.mjs --step y01 --no-export | grep -E " snapshot | usage snapshot " || true
node loadtest/load.mjs step "$YEARS"
step=$(printf "y%02d" "$YEARS")
node loadtest/measure.mjs --step "$step" --no-export | tee "$LT/measure-$step.txt" | grep -vE "^\[CONVEX" || true
echo "results: $LT/results/server.jsonl"
if grep -q "$step snapshot pilot FAILED" "$LT/measure-$step.txt"; then
  echo "REPRODUCED: with $YEARS years loaded operations.snapshot fails: $(grep -m1 "$step usage snapshot" "$LT/measure-$step.txt" | grep -o '"error":"[^"]*' | cut -c1-200)"
  exit 1
fi
echo "NOT REPRODUCED"
