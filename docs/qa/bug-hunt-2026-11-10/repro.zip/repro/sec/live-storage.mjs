// Bug-hunt 2026-11-10, sec: file-storage edge on a LOCAL Convex backend.
// Run: cd <checkout> && node --input-type=module < repro/sec/live-storage.mjs
import { readFile } from "node:fs/promises";
import { ConvexHttpClient } from "convex/browser";
import { anyApi as api } from "convex/server";
const env = await readFile(".env.local", "utf8");
const url = env.match(/^VITE_CONVEX_URL=(.*)$/m)[1].trim();
if (!/^http:\/\/127\.0\.0\.1:/.test(url)) throw new Error("local only");
const a = JSON.parse(await readFile(".env.local-admin.json", "utf8"));
const admin = new ConvexHttpClient(url);
const login = await admin.action(api.auth.signIn, { provider: "password", params: { flow: "signIn", email: a.email, password: a.password } });
admin.setAuth(login.tokens.token);
let snap = await admin.query(api.operations.snapshot, {});
const aircraft = snap.aircraft[0];
const html = new TextEncoder().encode("<!doctype html><script>document.title='ran:'+location.origin</script><h1>not a pdf</h1>");
const tries = [
  ["form.pdf", "application/pdf"],
  ["form.html", "text/html"],
  ["form.svg", "image/svg+xml"],
  ["form.pdf", "text/html"],
  ["form.html.pdf", "application/pdf"],
  ["form.png", "image/png"],
  ["form.pdf", "application/pdf; charset=x"],
  ["form.PDF", "APPLICATION/PDF"],
];
for (const [name, type] of tries) {
  try {
    await admin.action(api.aircraftFiles.upload, { aircraftUuid: aircraft.uuid, programUuid: aircraft.programUuid, category: "form-337", name, type, bytes: html.buffer });
    console.log("ACCEPTED", name, type);
  } catch (e) { console.log("refused ", name, type, "::", String(e.message).split("\n").slice(0,2).join(" ").slice(0, 110)); }
}
snap = await admin.query(api.operations.snapshot, {});
for (const f of (snap.aircraftFiles ?? []).filter((f) => f.aircraftUuid === aircraft.uuid).slice(-4)) {
  const r = await fetch(f.url);
  console.log("GET", f.name, f.type, "->", r.status, JSON.stringify(Object.fromEntries([...r.headers].filter(([k]) => /content|x-|cache|access|security|disposition/i.test(k)))));
  console.log("   url shape:", f.url.replace(/[0-9a-f]{8}-[0-9a-f-]{27}/, "<uuid>"));
}
