/**
 * Responsibility: Bug-hunt 2026-11-10 repro SE-3: one Flight Program's
 *   administrator spends the deployment-wide cap of immediate urgent-alert
 *   emails, so another program's "aircraft grounded" email is held back.
 * Layer: Test. convex-test; asserts the CORRECT behaviour, so it fails today.
 * Dependencies: convex/urgentAlerts.ts, convex/expiringItems.ts,
 *   tests/fixtures/alertProgram.ts.
 *
 * Run: cp to convex/ then `npx vitest run convex/zz-hunt-sec-emailcap.test.ts`.
 */
import { afterEach, expect, it, vi } from "vitest";
import { api, internal } from "./_generated/api";
import { IMMEDIATE_EMAILS_PER_DAY } from "./urgentAlerts";
import {
  DEMO_PROGRAM,
  OTHER_PROGRAM,
  seedAlertProgram,
  sentEmails,
  stubResend,
} from "../tests/fixtures/alertProgram";

afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
  vi.useRealTimers();
});

it("SE-3: another program's administrator cannot hold back this program's urgent emails", async () => {
  const { t, b } = await seedAlertProgram();
  vi.useFakeTimers({ now: Date.parse("2026-11-10T12:00:00Z") });
  const request = stubResend();
  const uuid = "22222222-2222-4222-8222-222222222222";
  // The other program's administrator saves one already-expired date, then
  // moves its date a day at a time: each save is a new alert key, so each
  // sends them an immediate email and spends one of the day's 60.
  for (let n = 0; n < IMMEDIATE_EMAILS_PER_DAY; n++) {
    const day = String((n % 28) + 1).padStart(2, "0");
    const month = String(Math.floor(n / 28) + 1).padStart(2, "0");
    await b.mutation(api.expiringItems.save, {
      programUuid: OTHER_PROGRAM,
      payload: JSON.stringify({
        action: "save",
        item: {
          uuid,
          programUuid: OTHER_PROGRAM,
          kind: "insurance",
          label: "x",
          expiresOn: `2020-${month}-${day}`,
          version: n,
        },
      }),
    });
    await t.finishAllScheduledFunctions(vi.runAllTimers);
  }
  const toOther = sentEmails(request).filter((e) =>
    e.to.includes("other@example.test"),
  ).length;
  // Now the demo program's own urgent alerts (grounded aircraft, overdue
  // inspection) are checked for the first time today.
  const result = await t.action(internal.urgentAlerts.sendImmediate, {
    programUuid: DEMO_PROGRAM,
  });
  const toDemo = sentEmails(request).filter((e) =>
    e.to.includes("admin@example.test"),
  ).length;
  console.log("SE-3:", { emailsToAttacker: toOther, demoCheck: result, toDemo });
  expect(result).toMatchObject({ sent: 1, capped: 0 });
});
