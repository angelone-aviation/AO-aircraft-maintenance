// Bug-hunt 2026-11-10, sec: probes of a LOCAL Convex backend only.
// Run: cd <checkout> && node --input-type=module < repro/sec/live-probe.mjs
import { readFile } from "node:fs/promises";
import { randomBytes, randomUUID } from "node:crypto";
import { ConvexHttpClient } from "convex/browser";
import { anyApi as api } from "convex/server";

const env = await readFile(".env.local", "utf8");
const url = env.match(/^VITE_CONVEX_URL=(.*)$/m)[1].trim();
const site = env.match(/^VITE_CONVEX_SITE_URL=(.*)$/m)[1].trim();
if (!/^http:\/\/127\.0\.0\.1:/.test(url)) throw new Error("local only");
const adminAccount = JSON.parse(await readFile(".env.local-admin.json", "utf8"));
const pw = () => randomBytes(18).toString("base64url") + "aA1!";
const signIn = (c, email, password, flow = "signIn", extra = {}) =>
  c.action(api.auth.signIn, { provider: "password", params: { flow, email, password, ...extra } });
const outcome = async (p) => { try { return { ok: await p }; } catch (e) { return { err: String(e.message).slice(0, 160) }; } };
const log = (k, v) => console.log(k.padEnd(34), JSON.stringify(v));

const admin = new ConvexHttpClient(url);
const adminLogin = await signIn(admin, adminAccount.email, adminAccount.password);
admin.setAuth(adminLogin.tokens.token);
const snap = await admin.query(api.operations.snapshot, {});
const jwt = JSON.parse(Buffer.from(adminLogin.tokens.token.split(".")[1], "base64url").toString());
log("jwt lifetime (s)", jwt.exp - jwt.iat);
log("jwt claims", Object.keys(jwt));

// A. anonymous flows
const anon = new ConvexHttpClient(url);
for (const flow of ["signUp", "reset", "reset-verification", "email-verification"])
  log("anon flow " + flow, await outcome(signIn(anon, "new-" + randomUUID() + "@example.test", pw(), flow, { code: "123456", newPassword: pw() })));
log("anon publicKey", await outcome(anon.query(api.pushSubscriptions.publicKey, {})));
log("anon providers", await outcome(anon.query(api.identities.providers, {})));
log("anon snapshot", await outcome(anon.query(api.operations.snapshot, {})));

// B. user + lockout + refresh + disable
const email = "probe-" + randomBytes(4).toString("hex") + "@example.test";
const password = pw();
const id = await admin.action(api.admin.createUser, { email, name: "Probe user", password });
const program = snap.activeProgramUuid ?? snap.programs?.[0]?.uuid;
const aircraft = snap.aircraft.find((a) => a.programUuid === program) ?? snap.aircraft[0];
const groupId = await admin.mutation(api.admin.saveGroup, { programUuid: aircraft.programUuid, name: "Probe pilots " + randomBytes(2).toString("hex"), aircraftIds: [aircraft.uuid], permissions: ["read", "flight", "discrepancy"] });
await admin.mutation(api.admin.updateUser, { id, active: true, isAdmin: false, groupIds: [groupId] });
const user = new ConvexHttpClient(url);
const login = await signIn(user, email, password);
user.setAuth(login.tokens.token);
log("user signed in", { hasRefresh: !!login.tokens.refreshToken });
const refreshed = await outcome(anon.action(api.auth.signIn, { refreshToken: login.tokens.refreshToken }));
log("refresh works", { ok: !!refreshed.ok?.tokens?.token, err: refreshed.err });
// old refresh token reuse after rotation
const reuse = await outcome(anon.action(api.auth.signIn, { refreshToken: login.tokens.refreshToken }));
log("old refresh token reused", { tokens: !!reuse.ok?.tokens?.token, err: reuse.err });
await admin.mutation(api.admin.updateUser, { id, active: false, isAdmin: false, groupIds: [groupId] });
log("disabled: old jwt snapshot", await outcome(user.query(api.operations.snapshot, {})).then((r) => (r.ok === null ? "null (refused)" : r.err ?? "DATA RETURNED")));
log("disabled: sign-in", await outcome(signIn(anon, email, password)).then((r) => r.err ?? "TOKENS " + !!r.ok?.tokens));
if (refreshed.ok?.tokens?.refreshToken)
  log("disabled: refresh", await outcome(anon.action(api.auth.signIn, { refreshToken: refreshed.ok.tokens.refreshToken })).then((r) => r.err ?? "tokens " + JSON.stringify(r.ok?.tokens ?? null)));
await admin.mutation(api.admin.updateUser, { id, active: true, isAdmin: false, groupIds: [groupId] });
log("re-enabled: old jwt snapshot", await outcome(user.query(api.operations.snapshot, {})).then((r) => (r.ok === null ? "null (refused)" : r.err ?? "DATA RETURNED")));

// lockout
let failures = 0;
for (let i = 0; i < 12; i++) if ((await outcome(signIn(anon, email, "wrong-password-" + i))).err) failures++;
log("after 12 wrong: right password", await outcome(signIn(anon, email, password)).then((r) => r.err ?? "TOKENS ISSUED"));

// C. HTTP routes
for (const path of ["/.well-known/openid-configuration", "/.well-known/jwks.json", "/api/auth/signin/google", "/api/auth/callback/google?code=x&state=y", "/api/auth/signin/nope?redirectTo=https://evil.example", "/nope"]) {
  const r = await fetch(site + path, { redirect: "manual" });
  log("GET " + path.slice(0, 40), { status: r.status, location: r.headers.get("location"), type: r.headers.get("content-type"), acao: r.headers.get("access-control-allow-origin"), body: (await r.text()).slice(0, 90) });
}
console.log(JSON.stringify({ probeUser: { id, email, groupId, aircraft: aircraft.uuid, program: aircraft.programUuid } }));
