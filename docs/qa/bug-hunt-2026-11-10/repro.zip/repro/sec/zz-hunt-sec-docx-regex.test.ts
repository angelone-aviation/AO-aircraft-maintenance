// @vitest-environment node
/**
 * Responsibility: Bug-hunt 2026-11-10 repro SE-14: the AD Word import's
 *   section reader is quadratic in the number of "Make:" labels.
 * Layer: Test. vitest, node; asserts a time budget, so it fails today.
 * Dependencies: src/data/adImport.ts.
 *
 * Run: cp to src/data/ then `npx vitest run src/data/zz-hunt-sec-docx-regex.test.ts`.
 */
import { expect, it } from "vitest";
import { parseADTables } from "./adImport";

it("SE-14: a section table with many 'Make:' labels is read in linear time", () => {
  const times: Record<number, number> = {};
  for (const k of [10_000, 20_000, 40_000]) {
    const tables = [
      [["Airframe", "Make: ".repeat(k)]],
      [["2020-01-01", "Subject: x", "Eff: 2020-01-01"]],
    ];
    const t = performance.now();
    parseADTables(tables);
    times[k] = Math.round(performance.now() - t);
  }
  // 40,000 labels are 240 KB of cell text; the importer accepts 20 MiB.
  expect(times).toEqual({ 10_000: expect.any(Number), 20_000: expect.any(Number), 40_000: expect.any(Number) });
  expect(`${times[40_000]} ms for 40,000 labels (10k: ${times[10_000]} ms, 20k: ${times[20_000]} ms)`).toBe("under 1000 ms");
}, 300_000);
