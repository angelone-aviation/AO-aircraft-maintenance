// @vitest-environment node
/**
 * Responsibility: Bug-hunt 2026-11-10: hostile files through the pure import
 *   parsers (prototype pollution through headers, crashes that are not
 *   Rejections, time blow-ups at the size each importer accepts).
 * Layer: Test. vitest, node environment; prints a table, asserts no pollution
 *   and a time budget.
 * Dependencies: src/domain parsers.
 *
 * Run: cp to src/domain/ then
 *   `npx vitest run src/domain/zz-hunt-sec-import-fuzz.test.ts`.
 */
import { expect, it } from "vitest";
import { Rejection } from "./rejection";
import { parseTaskCsv } from "./taskCsv";
import { parseComponentTemplateCsv } from "./componentTemplates";
import { parseInspectionSetupCsv, parseAdSetupCsv } from "./aircraftSetup";
import { parseTemplateCsv, templateCsvHeaders } from "./inspectionTemplates";
import { parseLogbook } from "./flightLogImport";
import { parseEngineLog } from "./engineTrends";
import { readCsvRows } from "./maintenanceCsv";
import { parseIcao } from "./pdf/icao";

const POLLUTERS = ["__proto__", "constructor", "prototype", "toString", "hasOwnProperty", "valueOf"];
const evil = '=HYPERLINK("http://x","y")';
const html = '<img src=x onerror=alert(1)>';

type Outcome = { name: string; ms: number; result: string };
const outcomes: Outcome[] = [];
function run(name: string, f: () => unknown) {
  const t = performance.now();
  let result: string;
  try {
    const value = f();
    result = "ok " + JSON.stringify(value)?.slice(0, 60);
  } catch (e) {
    result =
      e instanceof Rejection
        ? "Rejection: " + e.message.slice(0, 70)
        : `CRASH ${(e as Error)?.constructor?.name}: ${String((e as Error)?.message).slice(0, 90)}`;
  }
  const ms = Math.round(performance.now() - t);
  if (ms > 500 || result.startsWith("CRASH")) console.log(`  ${ms} ms  ${name}  ${result.slice(0, 80)}`);
  outcomes.push({ name, ms, result });
}

const parsers: [string, (text: string) => unknown][] = [
  ["taskCsv", (t) => parseTaskCsv(t)],
  ["componentTemplateCsv", (t) => parseComponentTemplateCsv(t)],
  ["inspectionSetupCsv", (t) => parseInspectionSetupCsv(t)],
  ["adSetupCsv", (t) => parseAdSetupCsv(t)],
  ["templateCsv", (t) => parseTemplateCsv(t, { make: "", model: "" } as never, "g")],
  ["logbook", (t) => parseLogbook(t)],
  ["engineLog", (t) => parseEngineLog(t, "x.csv")],
];

it("hostile CSV files neither pollute prototypes nor crash nor hang", () => {
  const polluterHeader = POLLUTERS.join(",");
  const cases: [string, string][] = [
    ["polluter headers", `${polluterHeader}\n${POLLUTERS.map(() => evil).join(",")}\n`],
    ["polluter + template headers", `${[...templateCsvHeaders, ...POLLUTERS].join(",")}\n${[...templateCsvHeaders, ...POLLUTERS].map(() => html).join(",")}\n`],
    ["logbook polluters", `Date,AircraftID,${polluterHeader}\n2026-01-01,N1,${POLLUTERS.map(() => "1").join(",")}\n`],
    ["engine polluters", `Date,Time,CHT1,${polluterHeader}\n2026-01-01,10:00:00,300,${POLLUTERS.map(() => "1").join(",")}\n`],
    ["empty", ""],
    ["only BOM", "﻿"],
    ["nul bytes", "a,b\n\u0000,\u0000\n"],
    ["1.9 MB one cell", "a".repeat(1_900_000)],
    ["1.9 MB commas", ",".repeat(1_900_000)],
    ["50k open parens header", "(".repeat(50_000) + ",Date\n1,2\n"],
    ["100k open parens header", "(".repeat(100_000) + ",Date\n1,2\n"],
    ["200k open parens header", "(".repeat(200_000) + ",Date\n1,2\n"],
    ["1.9 MB spaces", " ".repeat(1_900_000) + "x\n1\n"],
    ["2000 rows x 900 cells", ("x,".repeat(450) + "\n").repeat(2000)],
    ["1.9 MB newlines", "\n".repeat(1_900_000)],
    ["engine: 300k '(' cells in header", "Date,Time,CHT1," + "(,".repeat(300_000) + "\n2026-01-01,10:00:00,300\n"],
    ["engine: units comment 6 MB", "#" + "(,".repeat(3_000_000) + "\nDate,Time,CHT1\n2026-01-01,10:00:00,300\n"],
  ];
  for (const [label, text] of cases)
    for (const [name, parse] of parsers) run(`${name} <- ${label}`, () => parse(text));
  run("readCsvRows 2 MB quotes", () => readCsvRows('"' + '""'.repeat(900_000) + '"'));
  run("icao 200k items", () => parseIcao(Array.from({ length: 200_000 }, (_, i) => ({ str: "<<", x: i % 600, y: i % 800 })) as never));
  run("icao polluters", () => parseIcao(POLLUTERS.map((str, i) => ({ str, x: i, y: i })) as never));
  const slow = outcomes.filter((o) => o.ms > 2000);
  const crashes = outcomes.filter((o) => o.result.startsWith("CRASH"));
  console.log("SLOW (>2 s):\n" + slow.map((o) => `  ${o.ms} ms  ${o.name}`).join("\n"));
  console.log("CRASHES:\n" + crashes.map((o) => `  ${o.name}: ${o.result}`).join("\n"));
  console.log("OK samples:\n" + outcomes.filter((o) => o.result.startsWith("ok")).slice(0, 12).map((o) => `  ${o.name}: ${o.result}`).join("\n"));
  expect(({} as Record<string, unknown>).polluted).toBeUndefined();
  expect(Object.keys(Object.prototype)).toEqual([]);
  expect(slow).toEqual([]);
  expect(crashes).toEqual([]);
}, 600_000);
