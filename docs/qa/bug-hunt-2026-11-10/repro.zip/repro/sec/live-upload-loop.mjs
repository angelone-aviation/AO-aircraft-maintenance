// Bug-hunt 2026-11-10, sec SE-5: archived aircraft documents do not count
// toward the 200-document cap and uploads have no rate limit (LOCAL backend).
// Run: cd <checkout> && node --input-type=module < repro/sec/live-upload-loop.mjs
import { readFile } from "node:fs/promises";
import { ConvexHttpClient } from "convex/browser";
import { anyApi as api } from "convex/server";
const env = await readFile(".env.local", "utf8");
const url = env.match(/^VITE_CONVEX_URL=(.*)$/m)[1].trim();
if (!/^http:\/\/127\.0\.0\.1:/.test(url)) throw new Error("local only");
const a = JSON.parse(await readFile(".env.local-admin.json", "utf8"));
const c = new ConvexHttpClient(url);
const login = await c.action(api.auth.signIn, { provider: "password", params: { flow: "signIn", email: a.email, password: a.password } });
c.setAuth(login.tokens.token);
let snap = await c.query(api.operations.snapshot, {});
const aircraft = snap.aircraft[0];
const scope = { aircraftUuid: aircraft.uuid, programUuid: aircraft.programUuid };
const bytes = new Uint8Array(1024 * 1024).fill(37).buffer; // 1 MiB each
const ROUNDS = 6;
const started = Date.now();
for (let n = 0; n < ROUNDS; n++) {
  await c.action(api.aircraftFiles.upload, { ...scope, category: "form-337", name: `loop-${n}.pdf`, type: "application/pdf", bytes });
  snap = await c.query(api.operations.snapshot, {});
  const file = snap.aircraftFiles.find((f) => f.aircraftUuid === aircraft.uuid && f.name === `loop-${n}.pdf` && f.archivedAt === undefined);
  await c.mutation(api.aircraftFiles.archive, { programUuid: aircraft.programUuid, id: file.uuid, reason: "loop" });
}
snap = await c.query(api.operations.snapshot, {});
const mine = snap.aircraftFiles.filter((f) => f.aircraftUuid === aircraft.uuid && /^loop-/.test(f.name));
const alive = (await Promise.all(mine.map((f) => fetch(f.url).then((r) => r.ok)))).filter(Boolean).length;
const current = snap.aircraftFiles.filter((f) => f.aircraftUuid === aircraft.uuid && f.archivedAt === undefined).length;
console.log(JSON.stringify({ rounds: ROUNDS, seconds: (Date.now() - started) / 1000, archivedKept: mine.filter((f) => f.archivedAt).length, blobsStillServed: alive, currentCountTowardCap: current, storedMiB: mine.reduce((s, f) => s + f.size, 0) / 1048576 }));
