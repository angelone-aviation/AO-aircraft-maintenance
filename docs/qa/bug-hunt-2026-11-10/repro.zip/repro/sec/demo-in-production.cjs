// Bug-hunt 2026-11-10, sec: a production build made without VITE_ALLOW_DEMO or
// VITE_DEMO_MODE cannot be switched into demo mode from the browser.
// Run against such a build: ANGELONE_PROD_URL=http://127.0.0.1:4520 node demo-in-production.cjs
// Prints NOT REPRODUCED (exit 0) while the demo stays unreachable.
const { chromium } = require("playwright");
(async () => {
  const base = process.env.ANGELONE_PROD_URL || "http://127.0.0.1:4520";
  let browser;
  try { browser = await chromium.launch(); } catch { browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" }); }
  const results = [];
  for (const [label, path, storage] of [
    ["sessionStorage flag", "/", { "angel-one-demo": "true" }],
    ["query string", "/?demo=true&angel-one-demo=true#demo", {}],
    ["localStorage flag", "/", {}],
    ["deep link with flag", "/work-orders", { "angel-one-demo": "true" }],
  ]) {
    const context = await browser.newContext();
    await context.addInitScript((s) => {
      for (const [k, v] of Object.entries(s)) sessionStorage.setItem(k, v);
      localStorage.setItem("angel-one-demo", "true");
    }, storage);
    const page = await context.newPage();
    await page.goto(base + path, { waitUntil: "networkidle" }).catch(() => {});
    await page.waitForTimeout(1500);
    const text = (await page.locator("body").innerText()).replace(/\s+/g, " ");
    results.push({
      label,
      demoButton: /Explore the local demo/i.test(text),
      demoWorkspace: /N206MA|Mission operations|Demo/i.test(text) && !/Sign in/i.test(text),
      signIn: /Sign in|password/i.test(text),
      sample: text.slice(0, 90),
    });
    await context.close();
  }
  await browser.close();
  console.log(JSON.stringify(results, null, 1));
  const bad = results.filter((r) => r.demoButton || r.demoWorkspace);
  if (bad.length) { console.log("REPRODUCED: demo mode reachable in a production build: " + bad.map((b) => b.label).join(", ")); process.exit(1); }
  console.log("NOT REPRODUCED");
})();
