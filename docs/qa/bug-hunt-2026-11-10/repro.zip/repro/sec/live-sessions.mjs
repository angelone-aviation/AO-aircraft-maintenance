// Bug-hunt 2026-11-10, sec round 2: sessions, tokens, the live subscription and
// storage URLs after access is removed. LOCAL Convex backend only.
// Run: cd <checkout> && node --input-type=module < repro/sec/live-sessions.mjs
import { readFile } from "node:fs/promises";
import { randomBytes } from "node:crypto";
import { ConvexHttpClient, ConvexClient } from "convex/browser";
import { anyApi as api } from "convex/server";
const env = await readFile(".env.local", "utf8");
const url = env.match(/^VITE_CONVEX_URL=(.*)$/m)[1].trim();
if (!/^http:\/\/127\.0\.0\.1:/.test(url)) throw new Error("local only");
const adminAccount = JSON.parse(await readFile(".env.local-admin.json", "utf8"));
const pw = () => randomBytes(18).toString("base64url") + "aA1!";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (k, v) => console.log(k.padEnd(46), typeof v === "string" ? v : JSON.stringify(v));
const signIn = (c, email, password) => c.action(api.auth.signIn, { provider: "password", params: { flow: "signIn", email, password } });
const tryIt = async (p) => { try { return await p; } catch (e) { return { error: String(e.message).split("\n").slice(0, 2).join(" ").slice(0, 120) }; } };
const brief = (s) => s === null ? "null (refused)" : s?.error ? "ERROR " + s.error : `aircraft=${s.aircraft.length} files=${(s.aircraftFiles ?? []).length} members=${s.members.length} programs=${(s.programs ?? []).length} groups=${s.groups.length} audit=${s.audit.length}`;

const admin = new ConvexHttpClient(url);
admin.setAuth((await signIn(admin, adminAccount.email, adminAccount.password)).tokens.token);
const snap = await admin.query(api.operations.snapshot, {});
const aircraft = snap.aircraft[0];
const program = aircraft.programUuid;
const email = "sess-" + randomBytes(4).toString("hex") + "@example.test";
const password = pw();
const id = await admin.action(api.admin.createUser, { email, name: "Session probe", password });
const groupId = await admin.mutation(api.admin.saveGroup, { programUuid: program, name: "Session probe " + randomBytes(2).toString("hex"), aircraftIds: [aircraft.uuid], permissions: ["read", "flight"] });
const setGroups = (groupIds, active = true) => admin.mutation(api.admin.updateUser, { id, active, isAdmin: false, groupIds });
await setGroups([groupId]);
await admin.action(api.aircraftFiles.upload, { aircraftUuid: aircraft.uuid, programUuid: program, category: "form-337", name: "session-probe.pdf", type: "application/pdf", bytes: new TextEncoder().encode("%PDF-1.4 probe").buffer });

// two concurrent sessions
const s1 = new ConvexHttpClient(url), s2 = new ConvexHttpClient(url), anon = new ConvexHttpClient(url);
const l1 = await signIn(s1, email, password); s1.setAuth(l1.tokens.token);
const l2 = await signIn(s2, email, password); s2.setAuth(l2.tokens.token);
log("two sessions", { s1: brief(await s1.query(api.operations.snapshot, {})), s2: brief(await s2.query(api.operations.snapshot, {})) });
const mine = (await s1.query(api.operations.snapshot, {})).aircraftFiles.find((f) => f.name === "session-probe.pdf");
const fileUrl = mine.url;
const fetchStatus = async () => (await fetch(fileUrl)).status;
log("file URL, no session, no cookies", await fetchStatus());
log("same URL on a second getUrl call", (await admin.query(api.operations.snapshot, {})).aircraftFiles.find((f) => f.uuid === mine.uuid).url === fileUrl);

// live subscription
const ws = new ConvexClient(url);
ws.setAuth(async () => l1.tokens.token);
const updates = [];
ws.onUpdate(api.operations.snapshot, {}, (s) => updates.push({ at: Date.now(), s: brief(s) }), (e) => updates.push({ at: Date.now(), s: "ERROR " + String(e.message).slice(0, 80) }));
await sleep(1500);
const mark = async (label, act, wait = 2500) => {
  const before = updates.length; const t0 = Date.now();
  await act(); await sleep(wait);
  const next = updates.slice(before);
  log("WS after " + label, next.length ? next.map((u) => `+${u.at - t0} ms: ${u.s}`).join(" | ") : "NO UPDATE in " + wait + " ms (last: " + updates.at(-1)?.s + ")");
};
log("WS initial", updates.at(-1)?.s);
await mark("removal from every group", () => setGroups([]));
log("HTTP s1 after removal", brief(await tryIt(s1.query(api.operations.snapshot, {}))));
log("file URL after removal from every group", await fetchStatus());
const after = await tryIt(s1.query(api.operations.snapshot, {}));
if (after && !after.error) log("what a member of no group still gets", { programs: (after.programs ?? []).map((p) => p.name), members: after.members.map((m) => m.email || m.name), groups: after.groups.length, user: Object.keys(after.user) });
await mark("re-adding", () => setGroups([groupId]));

// sign-out of one session
await s2.action(api.auth.signOut, {});
log("s2 JWT after its sign-out", brief(await tryIt(s2.query(api.operations.snapshot, {}))));
log("s2 refresh token after its sign-out", await tryIt(anon.action(api.auth.signIn, { refreshToken: l2.tokens.refreshToken })).then((r) => r?.error ?? "tokens: " + !!r?.tokens));
log("s1 after s2 signed out", brief(await tryIt(s1.query(api.operations.snapshot, {}))));

// refresh rotation, then reuse of the old refresh token after the reuse window
const r1 = await anon.action(api.auth.signIn, { refreshToken: l1.tokens.refreshToken });
log("s1 refresh", { tokens: !!r1.tokens });
await sleep(12000);
const reuse = await tryIt(anon.action(api.auth.signIn, { refreshToken: l1.tokens.refreshToken }));
log("old refresh token 12 s after rotation", reuse?.error ?? "tokens: " + !!reuse?.tokens);
log("s1 session after that reuse", brief(await tryIt(s1.query(api.operations.snapshot, {}))));
const r2 = await tryIt(anon.action(api.auth.signIn, { refreshToken: r1.tokens.refreshToken }));
log("newest refresh token after that reuse", r2?.error ?? "tokens: " + !!r2?.tokens);

// password reset
const l3 = await signIn(s2, email, password); s2.setAuth(l3.tokens.token);
const ws2 = new ConvexClient(url); ws2.setAuth(async () => l3.tokens.token);
const u2 = []; ws2.onUpdate(api.operations.snapshot, {}, (s) => u2.push({ at: Date.now(), s: brief(s) }));
await sleep(1500);
let t0 = Date.now();
await admin.action(api.admin.resetPassword, { id, password: pw() });
await sleep(2500);
log("WS after password reset", u2.filter((u) => u.at >= t0).map((u) => `+${u.at - t0} ms: ${u.s}`).join(" | ") || "NO UPDATE (last: " + u2.at(-1)?.s + ")");
log("JWT after password reset", brief(await tryIt(s2.query(api.operations.snapshot, {}))));
log("refresh after password reset", await tryIt(anon.action(api.auth.signIn, { refreshToken: l3.tokens.refreshToken })).then((r) => r?.error ?? "tokens: " + !!r?.tokens));
log("old password after reset", await tryIt(signIn(anon, email, password)).then((r) => r?.error ? "refused" : "TOKENS"));
log("file URL after reset", await fetchStatus());

// archive the file, then disable the account
await admin.mutation(api.aircraftFiles.archive, { programUuid: program, id: mine.uuid, reason: "probe" });
log("file URL after the copy is archived", await fetchStatus());
await setGroups([groupId], false);
log("file URL after the account is disabled", await fetchStatus());
const headers = Object.fromEntries([...(await fetch(fileUrl)).headers]);
log("file response cache-control", headers["cache-control"]);
await ws.close(); await ws2.close();
process.exit(0);
