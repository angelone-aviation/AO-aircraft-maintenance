/**
 * Responsibility: Bug-hunt 2026-11-10 repro SE-4: an aircraft grounded by a
 *   pilot's open grounding report raises the in-app "is grounded" alert but
 *   no urgent email, push message or digest line, because the server's alert
 *   sources load no discrepancies.
 * Layer: Test. convex-test; asserts the CORRECT behaviour, so it fails today.
 * Dependencies: convex/urgentAlerts.ts, convex/alerts.ts, src/domain/alerts.ts,
 *   tests/fixtures/alertProgram.ts.
 *
 * Run: cp to convex/ then
 *   `npx vitest run convex/zz-hunt-sec-grounding-alert.test.ts`.
 */
import { afterEach, expect, it, vi } from "vitest";
import { api, internal } from "./_generated/api";
import { computeAlerts } from "../src/domain/alerts";
import { localDate } from "../src/domain/model";
import {
  DEMO_PROGRAM,
  seedAlertProgram,
  sentEmails,
  stubResend,
} from "../tests/fixtures/alertProgram";

afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
});

it("SE-4: a grounding problem report sends the urgent 'is grounded' alert", async () => {
  const { t, a, ids } = await seedAlertProgram();
  // Only the pilot's report grounds the aircraft: no overdue inspection.
  await t.run(async (ctx) => {
    for (const i of await ctx.db.query("inspections").collect())
      await ctx.db.delete(i._id);
    await ctx.db.insert("discrepancies", {
      uuid: "hunt-grounding-report",
      aircraftUuid: ids.aircraftUuid,
      description: "Nose gear strut flat. Do not fly.",
      status: "open",
      grounding: true,
      authorId: ids.a.userId,
      createdAt: Date.now(),
    });
  });
  // What the bell shows the program administrator (the client computes it
  // from the snapshot): the aircraft is grounded.
  const snapshot = (await a.query(api.operations.snapshot, {}))!;
  const inApp = computeAlerts(snapshot, localDate()).filter(
    (x) => x.kind === "aircraft-grounded",
  );
  expect(inApp.map((x) => x.detail)).toEqual([
    "Open discrepancy: Nose gear strut flat. Do not fly.",
  ]);
  // What the server sends at once, and in the daily digest.
  const request = stubResend();
  const urgent = await t.action(internal.urgentAlerts.sendImmediate, {
    programUuid: DEMO_PROGRAM,
  });
  const digest = await t.action(internal.alerts.sendDigests, {});
  const texts = sentEmails(request).map((e) => e.text);
  console.log("SE-4:", { inApp: inApp.map((x) => x.title), urgent, digest, emails: texts.length });
  expect(urgent.sent).toBe(1);
  expect(texts.join("\n")).toContain("is grounded");
});
