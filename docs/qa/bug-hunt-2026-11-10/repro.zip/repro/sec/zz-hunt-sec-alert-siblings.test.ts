/**
 * Responsibility: Bug-hunt 2026-11-10 repros SE-8 to SE-10: urgent states the
 *   bell shows that the email and push paths do not send, or send differently.
 * Layer: Test. convex-test; asserts the CORRECT behaviour, so it fails today.
 * Dependencies: convex/urgentAlerts.ts, convex/alerts.ts, src/domain/alerts.ts,
 *   tests/fixtures/alertProgram.ts.
 *
 * Run: cp to convex/ then
 *   `npx vitest run convex/zz-hunt-sec-alert-siblings.test.ts`.
 */
import { afterEach, expect, it, vi } from "vitest";
import { api, internal } from "./_generated/api";
import { computeAlerts, urgentAlerts } from "../src/domain/alerts";
import {
  DEMO_PROGRAM,
  OTHER_PROGRAM,
  seedAlertProgram,
  sentEmails,
  stubResend,
} from "../tests/fixtures/alertProgram";

const DAY_MS = 86_400_000;

afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
  vi.useRealTimers();
});

async function addSystemAdmin(t: Awaited<ReturnType<typeof seedAlertProgram>>["t"]) {
  return t.run(async (ctx) => {
    const userId = await ctx.db.insert("users", {
      active: true,
      isAdmin: true,
      name: "System administrator",
      email: "sysadmin@example.test",
      groupIds: [],
      activeProgramUuid: DEMO_PROGRAM,
    });
    const session = await ctx.db.insert("authSessions", {
      userId,
      expirationTime: Date.now() + DAY_MS,
    });
    return { userId, identity: { subject: `${userId}|${session}` } };
  });
}

// SE-8. A system administrator who holds no permission group sees every
// program's alerts in the bell, and the deployment's own expiring dates
// "alert system administrators", but only group holders are ever emailed.
it("SE-8: a system administrator without a permission group gets the urgent alerts the bell shows them", async () => {
  const world = await seedAlertProgram();
  const sys = await addSystemAdmin(world.t);
  const asSys = world.t.withIdentity(sys.identity);
  await world.t.run((ctx) =>
    ctx.db.patch(sys.userId, { emailAlerts: true, urgentAlertEmails: true }),
  );
  // A deployment-wide date (say the VAPID key pair review) that has expired.
  await asSys.mutation(api.expiringItems.save, {
    programUuid: DEMO_PROGRAM,
    payload: JSON.stringify({
      action: "save",
      item: {
        uuid: "33333333-3333-4333-8333-333333333333",
        kind: "secret",
        label: "VAPID key pair",
        expiresOn: "2020-01-01",
        version: 0,
      },
    }),
  });
  const snapshot = (await asSys.query(api.operations.snapshot, {}))!;
  const bell = urgentAlerts(
    computeAlerts(snapshot, new Date().toISOString().slice(0, 10)),
  ).map((a) => a.title);
  const request = stubResend();
  await world.t.action(internal.urgentAlerts.sendImmediate, {
    programUuid: DEMO_PROGRAM,
  });
  await world.t.action(internal.urgentAlerts.sendImmediate, {
    programUuid: OTHER_PROGRAM,
  });
  await world.t.action(internal.alerts.sendDigests, {});
  const mine = sentEmails(request).filter((e) =>
    e.to.includes("sysadmin@example.test"),
  );
  const all = sentEmails(request).map((e) => e.text).join("\n");
  console.log("SE-8:", {
    bell,
    emailsToSystemAdmin: mine.map((e) => e.subject),
    vapidLineInAnyEmail: all.includes("VAPID key pair"),
  });
  expect(bell).toContain("VAPID key pair expired on 2020-01-01");
  expect(mine.some((e) => e.text.includes("is grounded"))).toBe(true);
  expect(all).toContain("VAPID key pair expired on 2020-01-01");
});

// SE-9. The server computes alerts for its own (UTC) date; the app for the
// device's. From 19:00 Eastern (16:00 Pacific) the server is a day ahead, so
// an inspection due TODAY is emailed and pushed as overdue and grounding.
it("SE-9: an inspection due today in the member's time zone is not sent as overdue and grounding", async () => {
  const world = await seedAlertProgram();
  // 20:30 on 10 Nov in New York is 01:30 UTC on 11 Nov.
  vi.useFakeTimers({ now: Date.parse("2026-11-11T01:30:00Z") });
  await world.t.run(async (ctx) => {
    for (const i of await ctx.db.query("inspections").collect())
      await ctx.db.patch(i._id, { dueDate: "2026-11-10" });
  });
  const snapshot = (await world.a.query(api.operations.snapshot, {}))!;
  const onDevice = computeAlerts(snapshot, "2026-11-10").map(
    (a) => `${a.kind}: ${a.title}`,
  );
  const request = stubResend();
  const result = await world.t.action(internal.urgentAlerts.sendImmediate, {
    programUuid: DEMO_PROGRAM,
  });
  const texts = sentEmails(request).map((e) => e.text);
  console.log("SE-9:", { onDevice, result, emailed: texts });
  expect(onDevice.some((a) => a.startsWith("aircraft-grounded"))).toBe(false);
  expect(result.sent).toBe(0);
});

// SE-10. The deployment's own expiring dates are loaded into every program's
// sources, so a system administrator in two programs is emailed the same
// expired date once per program, each spending one of the day's 60.
it("SE-10: one expired deployment-wide date is emailed to an administrator once, not once per program", async () => {
  const world = await seedAlertProgram();
  await world.t.run(async (ctx) => {
    for (const i of await ctx.db.query("inspections").collect())
      await ctx.db.delete(i._id);
    // Make the demo administrator a system administrator who also holds the
    // other program's administrator group.
    const other = (await ctx.db.query("groups").collect()).find(
      (g) => g.programUuid === OTHER_PROGRAM,
    )!;
    const user = (await ctx.db.get(world.ids.a.userId))!;
    await ctx.db.patch(user._id, {
      isAdmin: true,
      groupIds: [...(user.groupIds ?? []), other._id],
    });
  });
  await world.t.mutation(internal.memberships.backfill, {});
  await world.a.mutation(api.expiringItems.save, {
    programUuid: DEMO_PROGRAM,
    payload: JSON.stringify({
      action: "save",
      item: {
        uuid: "44444444-4444-4444-8444-444444444444",
        kind: "service-key",
        label: "Resend API key",
        expiresOn: "2020-01-01",
        version: 0,
      },
    }),
  });
  const request = stubResend();
  await world.t.action(internal.urgentAlerts.sendImmediate, {
    programUuid: DEMO_PROGRAM,
  });
  await world.t.action(internal.urgentAlerts.sendImmediate, {
    programUuid: OTHER_PROGRAM,
  });
  const mine = sentEmails(request).filter(
    (e) => e.to.includes("admin@example.test") && e.text.includes("Resend API key"),
  );
  console.log("SE-10:", mine.map((e) => e.subject));
  expect(mine).toHaveLength(1);
});
