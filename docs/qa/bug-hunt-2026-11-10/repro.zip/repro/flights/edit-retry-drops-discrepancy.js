// FL-4: "Edit and retry" on a refused flight opens the form without the
// discrepancy the pilot wrote on it; saving queues the flight with an empty
// discrepancy, so the linked problem report is never created.
const L = require("./lib");
const PROBLEM = "Left brake pedal soft on rollout";
(async () => {
  const { browser, context, page } = await L.start();
  try {
    await L.swReady(page);
    await context.setOffline(true);
    // A grounding report queued first grounds the aircraft when it syncs, so
    // the flight behind it is refused at the dispatch gate (as in
    // tests/e2e/stale-save.spec.ts).
    await page.getByRole("link", { name: "Discrepancies", exact: true }).click();
    await page.getByRole("button", { name: "Report a problem" }).click();
    await page.getByLabel("What did you observe?").fill("Alternator inoperative after start");
    await page.getByRole("checkbox", { name: /Aircraft not airworthy/ }).check();
    await page.getByRole("button", { name: "Save report" }).click();
    await page.getByRole("dialog").waitFor({ state: "hidden" });
    await page.getByRole("link", { name: "Overview", exact: true }).click();
    await page.getByRole("button", { name: "Log a flight", exact: true }).click();
    let dialog = page.getByRole("dialog");
    await dialog.getByLabel("Ending Hobbs *", { exact: true }).fill("2342.2");
    await dialog.getByLabel("Flight date & time").fill("2026-01-01T10:00");
    await dialog.getByLabel("Remarks", { exact: true }).fill("Night leg, crosswind landing");
    await dialog.locator('textarea[name="discrepancy"]').fill(PROBLEM);
    await dialog.getByRole("button", { name: "Save flight", exact: true }).click();
    await dialog.waitFor({ state: "hidden" });
    const queued = await page.evaluate(async () => {
      const dbs = await indexedDB.databases();
      return dbs.map((d) => d.name);
    });
    console.log("databases:", queued.join(", "));
    await context.setOffline(false);
    await page.getByRole("link", { name: /Sync center/ }).click();
    await page.getByText("Needs attention", { exact: true }).first().waitFor();
    console.log("entry:", (await page.locator(".rec-entry").first().innerText()).replace(/\s+/g, " ").slice(0, 400));
    await page.getByRole("button", { name: "Edit and retry" }).click();
    const retry = page.getByRole("dialog", { name: "Edit and retry flight" });
    const shownRemarks = await retry.getByLabel("Remarks", { exact: true }).inputValue();
    const shownProblem = await retry.locator('textarea[name="discrepancy"]').inputValue();
    console.log("retry form: remarks =", JSON.stringify(shownRemarks), "discrepancy =", JSON.stringify(shownProblem));
    await page.screenshot({ path: L.SHOTS + "/flights-edit-retry-discrepancy.png", fullPage: true });
    await retry.getByLabel("Administrator dispatch override reason").fill("Maintenance ferry approved by the director.");
    await retry.getByRole("button", { name: "Save flight", exact: true }).click();
    await page.getByRole("heading", { name: "0 pending entries" }).waitFor();
    const all = await L.demoAll(page);
    const flight = all.flights.find((f) => f.remarks === "Night leg, crosswind landing");
    const reports = all.discrepancies.filter((d) => d.description.includes("brake"));
    console.log("synced flight discrepancy:", JSON.stringify(flight && flight.discrepancy), "status:", flight && flight.status, "reports about the brake:", reports.length);
    L.result(
      !!flight && flight.discrepancy !== PROBLEM && reports.length === 0,
      `the retried flight synced with discrepancy ${JSON.stringify(flight && flight.discrepancy)} and no problem report exists for "${PROBLEM}"`,
    );
  } catch (e) {
    console.error(e);
    process.exitCode = 2;
  } finally {
    await browser.close();
  }
})();
