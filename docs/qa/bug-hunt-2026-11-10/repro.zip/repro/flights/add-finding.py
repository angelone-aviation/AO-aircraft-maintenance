import json, sys
# usage: python3 -I add-finding.py <findings.jsonl> < finding.json
obj = json.load(sys.stdin)
required = ["id","area","title","severity","kind","steps","expected","actual","evidence","repro","suspect","confidence","regression_of","needs_owner_decision","notes"]
missing = [k for k in required if k not in obj]
assert not missing, missing
with open(sys.argv[1], "a") as f:
    f.write(json.dumps(obj, ensure_ascii=False) + "\n")
print("added", obj["id"])
