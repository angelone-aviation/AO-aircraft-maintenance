// Probe (not a pass/fail repro): service worker first load, offline deep
// links, and a simulated new build. Needs its own copy of the build:
//   ANGELONE_URL=http://127.0.0.1:4411 SW_DIST=<copied dist dir> node sw-probe.js
const fs = require("fs");
const path = require("path");
const { chromium } = require("playwright");
const BASE = process.env.ANGELONE_URL;
const DIST = process.env.SW_DIST;
(async () => {
  const browser = await chromium.launch({ executablePath: fs.existsSync("/opt/pw-browsers/chromium") ? "/opt/pw-browsers/chromium" : undefined });
  const context = await browser.newContext();
  await context.addInitScript(() => sessionStorage.setItem("angel-one-demo", "true"));
  const page = await context.newPage();
  page.setDefaultTimeout(15000);
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  page.on("console", (m) => m.type() === "error" && errors.push(m.text()));
  try {
    await page.goto(BASE + "/");
    await page.getByRole("heading", { name: "Your fleet, at a glance." }).waitFor();
    await page.evaluate(() => navigator.serviceWorker.ready);
    await page.waitForTimeout(1500);
    const caches1 = await page.evaluate(async () => {
      const out = {};
      for (const k of await caches.keys()) out[k] = (await (await caches.open(k)).keys()).length;
      return out;
    });
    console.log("caches after first load:", JSON.stringify(caches1), "| notice:", await page.locator('[role="status"]').allInnerTexts());
    console.log("controlled before reload:", await page.evaluate(() => !!navigator.serviceWorker.controller));
    await context.setOffline(true);
    for (const route of ["/", "/airworthiness", "/work-orders", "/flight-log", "/sync", "/no-such-route", "/index.html", "/.well-known/security.txt", "/assets/missing-chunk.js"]) {
      const res = await page.goto(BASE + route).catch((e) => ({ err: String(e).split("\n")[0] }));
      await page.waitForTimeout(500);
      const h = await page.locator("h1").first().innerText().catch(() => "(no h1)");
      console.log("offline", route, "->", res && res.err ? res.err : `${res.status()} ${(await res.headerValue("content-type")) || ""}`, "| h1:", h.replace(/\s+/g, " ").slice(0, 60));
    }
    await context.setOffline(false);
    // A new build: index.html and its precache revision change.
    const sw = path.join(DIST, "sw.js");
    const original = fs.readFileSync(sw, "utf8");
    const html = fs.readFileSync(path.join(DIST, "index.html"), "utf8");
    fs.writeFileSync(path.join(DIST, "index.html"), html.replace("</head>", '<meta name="hunt-build" content="v2"></head>'));
    fs.writeFileSync(sw, original.replace(/"revision":"[0-9a-f]+","url":"index.html"/, '"revision":"00000000000000000000000000000002","url":"index.html"'));
    await page.goto(BASE + "/flight-log");
    await page.waitForTimeout(4000);
    const state = () => page.evaluate(async () => {
      const r = await navigator.serviceWorker.getRegistration();
      return { waiting: !!r.waiting, installing: !!r.installing, active: !!r.active, build: document.querySelector('meta[name="hunt-build"]')?.content ?? "v1" };
    });
    console.log("after new build, same tab:", JSON.stringify(await state()), "| notices:", JSON.stringify(await page.locator('[role="status"], .notice, .banner').allInnerTexts()).slice(0, 300));
    await page.reload(); await page.waitForTimeout(1500);
    console.log("after reload:", JSON.stringify(await state()));
    await page.close();
    const page2 = await context.newPage();
    await page2.goto(BASE + "/flight-log"); await page2.waitForTimeout(2500);
    console.log("after closing the tab and reopening:", JSON.stringify(await page2.evaluate(async () => {
      const r = await navigator.serviceWorker.getRegistration();
      return { waiting: !!r.waiting, active: !!r.active, build: document.querySelector('meta[name="hunt-build"]')?.content ?? "v1" };
    })));
    await page2.reload(); await page2.waitForTimeout(1500);
    console.log("and after one more reload: build", await page2.evaluate(() => document.querySelector('meta[name="hunt-build"]')?.content ?? "v1"));
    fs.writeFileSync(sw, original); fs.writeFileSync(path.join(DIST, "index.html"), html);
    console.log("console/page errors:", JSON.stringify(errors.slice(0, 6)));
  } catch (e) { console.error(e); process.exitCode = 2; } finally { await browser.close(); }
})();
