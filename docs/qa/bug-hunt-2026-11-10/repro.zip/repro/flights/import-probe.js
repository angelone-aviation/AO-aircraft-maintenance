// Probe: logbook import with the ForeFlight and Garmin fixtures, a re-import,
// and the totals afterwards. Usage: node import-probe.js <fixtures dir> [timezoneId]
const L = require("./lib");
const path = require("path");
const DIR = process.argv[2];
async function importFile(page, file) {
  await page.getByRole("link", { name: "Flight log", exact: true }).click();
  await page.getByRole("button", { name: "Import logbook" }).click();
  const dialog = page.getByRole("dialog");
  await dialog.locator('input[type="file"]').setInputFiles(path.join(DIR, file));
  await dialog.getByRole("button", { name: "Preview flights", exact: true }).click();
  await page.waitForTimeout(800);
  const text = (await dialog.innerText()).replace(/[ \t]+/g, " ");
  console.log(`--- preview of ${file} ---\n` + text.split("\n").filter((l) => l.trim()).slice(0, 60).join("\n"));
  const go = dialog.getByRole("button", { name: /^Import \d+ selected flight/ });
  if (await go.count() && !(await go.isDisabled())) {
    console.log("pressing:", await go.innerText());
    await go.click();
    await page.waitForTimeout(2500);
    console.log("result:", (await dialog.innerText().catch(() => "(dialog closed)")).replace(/\s+/g, " ").slice(0, 400));
  } else console.log("nothing importable");
  const close = dialog.getByRole("button", { name: /Close|Done|Cancel/ }).first();
  if (await dialog.count()) await close.click().catch(() => {});
  const all = await L.demoAll(page);
  for (const reg of ["N206MA", "N182MA"]) {
    const a = all.aircraft.find((x) => x.registration === reg);
    const fl = all.flights.filter((f) => f.aircraftUuid === a.uuid);
    console.log(reg, "hobbs", a.currentHobbs / 3600, "tach", a.currentTach / 3600, "landings", a.landings, "| flights:", fl.map((f) => `${f.startTime} ${f.origin}->${f.destination} on=${f.hobbsOn / 3600} off=${(f.hobbsOff ?? 0) / 3600} ld=${f.landings} ${f.status}${f.reviewReason ? " (" + f.reviewReason + ")" : ""}`).join(" ; "));
  }
}
(async () => {
  const { browser, page } = await L.start(process.argv[3] ? { timezoneId: process.argv[3] } : {});
  try {
    const all = await L.demoAll(page);
    for (const reg of ["N206MA", "N182MA"]) { const a = all.aircraft.find((x) => x.registration === reg); console.log("start", reg, a.currentHobbs / 3600, a.currentTach / 3600, a.landings, a.meter); }
    await importFile(page, "foreflight-logbook.csv");
    await importFile(page, "foreflight-logbook.csv");
    await importFile(page, "garmin-pilot-logbook.csv");
  } catch (e) { console.error(e); process.exitCode = 2; } finally { await browser.close(); }
})();
