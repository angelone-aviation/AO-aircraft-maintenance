/**
 * Responsibility: Bug-hunt repros FL-6 and FL-7 against the server: a
 *   problem report filed from the flight form has no change-log row of its
 *   own, and a retry of a synced entry with different contents is answered
 *   "accepted" although nothing of it is stored.
 * Layer: Test. convex-test; copy to convex/ and run
 *   `npx vitest run convex/zz-hunt-flights-report-audit.test.ts`.
 * Dependencies: convex/operations.ts, convex/schema.ts, src/data/demo.ts.
 */
import { convexTest } from "convex-test";
import { it, expect } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { demoSnapshot } from "../src/data/demo";
import type { FlightInput } from "../src/domain/model";

const modules = import.meta.glob([
  "./**/*.ts",
  "./_generated/*.js",
  "!./**/*.test.ts",
  "!./**/*.d.ts",
]);

async function fixture() {
  const t = convexTest(schema, modules);
  const a = demoSnapshot().aircraft[0];
  const ids = await t.run(async (ctx) => {
    await ctx.db.insert("programs", demoSnapshot().programs![0]);
    const group = await ctx.db.insert("groups", {
      programUuid: "demo-program",
      name: "Pilots",
      aircraftIds: [a.uuid],
      permissions: ["read", "flight", "discrepancy"],
    });
    const user = await ctx.db.insert("users", {
      name: "Pilot",
      active: true,
      isAdmin: false,
      activeProgramUuid: "demo-program",
      groupIds: [group],
    });
    const session = await ctx.db.insert("authSessions", {
      userId: user,
      expirationTime: Date.now() + 86400000,
    });
    await ctx.db.insert("aircraft", a);
    return { user, session };
  });
  const pilot = t.withIdentity({ subject: ids.user + "|" + ids.session });
  const input: FlightInput = {
    aircraftUuid: a.uuid,
    pilotId: ids.user,
    startTime: "2026-01-01T10:00:00Z",
    hobbsOn: a.currentHobbs + 3600,
    landings: 1,
    cycles: 1,
    origin: "AAA",
    destination: "BBB",
    operation: "Mission",
    flightRules: "VFR",
    remarks: "",
    discrepancy: "",
  };
  const op = (change: Partial<FlightInput> = {}) => ({
    programUuid: "demo-program",
    kind: "flight" as const,
    uuid: crypto.randomUUID(),
    authorId: ids.user,
    baseVersion: a.version,
    input: { ...input, ...change },
  });
  return { t, pilot, a, op };
}

it("FL-6: a problem report filed with a flight has its own change-log row", async () => {
  const { t, pilot, op } = await fixture();
  const operation = op({ discrepancy: "Left brake pedal soft on rollout" });
  await pilot.mutation(api.operations.submit, { operation });
  const { report, rows } = await t.run(async (ctx) => ({
    report: await ctx.db
      .query("discrepancies")
      .withIndex("uuid", (q) => q.eq("uuid", operation.uuid + "-discrepancy"))
      .unique(),
    rows: await ctx.db
      .query("audit")
      .withIndex("entity", (q) =>
        q.eq("entityUuid", operation.uuid + "-discrepancy"),
      )
      .collect(),
  }));
  expect(report).toMatchObject({ status: "open" });
  // A standalone report writes "discrepancy.created"; this one writes none.
  expect(rows.map((r) => r.action)).toContain("discrepancy.created");
});

it("FL-7: resending a synced entry's id with different readings is not answered as accepted", async () => {
  const { t, pilot, a, op } = await fixture();
  const first = op();
  await pilot.mutation(api.operations.submit, { operation: first });
  const corrected = {
    ...first,
    input: { ...first.input, hobbsOn: a.currentHobbs + 7200, landings: 3 },
  };
  const answer = await pilot
    .mutation(api.operations.submit, { operation: corrected })
    .then(
      (result) => result,
      (error: unknown) => ({ refused: String(error) }),
    );
  const stored = await t.run((ctx) =>
    ctx.db
      .query("flights")
      .withIndex("uuid", (q) => q.eq("uuid", first.uuid))
      .unique(),
  );
  // The device deletes its outbox entry on { status: "accepted" }, so either
  // the correction is stored or the answer must not say accepted.
  const kept = stored?.hobbsOn === corrected.input.hobbsOn;
  expect(kept || "refused" in answer).toBe(true);
});
