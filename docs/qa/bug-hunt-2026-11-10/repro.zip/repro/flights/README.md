# flights area repros (bug hunt 2026-11-10)

Browser scripts (Node + Playwright, CommonJS; `package.json` here sets the type):

    cd repro/flights && node <script>.js     # ANGELONE_URL defaults to http://127.0.0.1:4400

Exit 1 and `REPRODUCED: ...` while the bug exists, exit 0 and `NOT REPRODUCED` once fixed.
`lib.js` uses /opt/pw-browsers/chromium when present (or CHROMIUM_PATH).

| Finding | Script |
|---|---|
| FL-1 | offline-two-legs.js |
| FL-3 | stale-ad-keep-mine.js |
| FL-4 | edit-retry-drops-discrepancy.js |
| FL-5 | session-grounded-midflight.js |
| FL-8 | stale-workorder-keep-mine.js (add `theirs` or `cancel` to drive the other choices) |
| FL-9 | access-window-probe.js skew (`all` prints day 6/7/8 and pending entries across expiry) |
| FL-10 | stale-inspection-probe.js (prints the review rows and the stored record; no pass/fail) |

Server tests (assert the correct behaviour, so they fail today). From a checkout:

    cp repro/flights/zz-hunt-flights-refusal-text.test.ts convex/ && npx vitest run convex/zz-hunt-flights-refusal-text.test.ts   # FL-2
    cp repro/flights/zz-hunt-flights-report-audit.test.ts convex/ && npx vitest run convex/zz-hunt-flights-report-audit.test.ts   # FL-6, FL-7

    cp repro/flights/zz-hunt-flights-keep-mine-ad.test.ts convex/ && npx vitest run convex/zz-hunt-flights-keep-mine-ad.test.ts     # FL-3 on the server (FL-11)

The refusal-text file also holds the FL-12 case. Remove the copied files afterwards.

Probes that pass today (kept as evidence of what held):

- `probe-review-invariants.test.ts`: copy to convex/ and run with vitest. Six accepted flights, a held one accepted
  early, accepted again, a middle one rejected and re-accepted, the last rejected, the held one rejected, then a new
  flight: after every step totals equal the baseline plus the accepted flights and every starting reading chains.
- `sw-probe.js`: `ANGELONE_URL=http://127.0.0.1:<port> SW_DIST=<a private copy of dist served on that port> node sw-probe.js`.
  It edits index.html and sw.js in that copy to simulate a new build and restores them.
- `import-probe.js <tests/fixtures dir> [timezoneId]`: both logbook fixtures, a re-import, totals. `add-finding.py` only appends a checked JSON line to the findings file.
