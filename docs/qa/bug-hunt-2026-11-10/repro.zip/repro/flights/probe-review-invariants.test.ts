import { convexTest } from "convex-test";
import { it, expect } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { demoSnapshot } from "../src/data/demo";
import type { FlightInput } from "../src/domain/model";
const modules = import.meta.glob(["./**/*.ts", "./_generated/*.js", "!./**/*.test.ts", "!./**/*.d.ts"]);
const H = 3600;
async function fixture() {
  const t = convexTest(schema, modules);
  const a = demoSnapshot().aircraft[0];
  const ids = await t.run(async (ctx) => {
    await ctx.db.insert("programs", demoSnapshot().programs![0]);
    const group = await ctx.db.insert("groups", { programUuid: "demo-program", name: "Pilots", aircraftIds: [a.uuid], permissions: ["read", "flight", "discrepancy"] });
    const user = await ctx.db.insert("users", { name: "Pilot", active: true, isAdmin: false, groupIds: [group], activeProgramUuid: "demo-program" });
    const admin = await ctx.db.insert("users", { name: "Admin", active: true, isAdmin: true, groupIds: [], activeProgramUuid: "demo-program" });
    const session = await ctx.db.insert("authSessions", { userId: user, expirationTime: Date.now() + 86400000 });
    const adminSession = await ctx.db.insert("authSessions", { userId: admin, expirationTime: Date.now() + 86400000 });
    await ctx.db.insert("aircraft", a);
    return { user, admin, session, adminSession };
  });
  const pilot = t.withIdentity({ subject: ids.user + "|" + ids.session });
  const admin = t.withIdentity({ subject: ids.admin + "|" + ids.adminSession });
  const input = (day: number, hobbsHours: number, extra: Partial<FlightInput> = {}): FlightInput => ({
    aircraftUuid: a.uuid, pilotId: ids.user, startTime: `2026-01-${String(day).padStart(2, "0")}T10:00:00Z`,
    hobbsOn: a.currentHobbs + hobbsHours * H, tachOn: a.currentTach + hobbsHours * H, landings: 2, cycles: 1, origin: "D" + day, destination: "X",
    operation: "Mission", flightRules: "VFR", remarks: "", discrepancy: "", ...extra,
  });
  let version = a.version;
  const submit = async (i: FlightInput, baseVersion = version) => {
    const operation = { programUuid: "demo-program", kind: "flight" as const, uuid: crypto.randomUUID(), authorId: ids.user, baseVersion, input: i };
    const r = await pilot.mutation(api.operations.submit, { operation });
    if (r.status === "accepted") version++;
    return { uuid: operation.uuid, status: r.status, input: i };
  };
  const review = (uuid: string, decision: "accept" | "reject", i: FlightInput, requestUuid?: string) =>
    admin.mutation(api.operations.reviewFlight, { programUuid: "demo-program", uuid, decision, reason: "Checked against the paper log", input: i, requestUuid });
  const state = async () => {
    const s = (await admin.query(api.operations.snapshot, {}))!;
    const ac = s.aircraft.find((x) => x.uuid === a.uuid)!;
    const flights = s.flights.filter((f) => f.status === "accepted").sort((x, y) => x.startTime.localeCompare(y.startTime));
    return { s, ac, flights };
  };
  const check = async (label: string) => {
    const { s, ac, flights } = await state();
    let hobbs = a.baselineHobbs!, tach = a.baselineTach!, landings = a.baselineLandings!, cycles = a.baselineCycles!;
    for (const f of flights) {
      expect(f.hobbsOff, `${label}: ${f.origin} hobbsOff`).toBe(hobbs);
      expect(f.tachOff, `${label}: ${f.origin} tachOff`).toBe(tach);
      hobbs = f.hobbsOn ?? hobbs; tach = f.tachOn ?? tach; landings += f.landings; cycles += f.cycles;
    }
    expect(ac.currentHobbs, label + " hobbs").toBe(hobbs);
    expect(ac.currentTach, label + " tach").toBe(tach);
    expect(ac.landings, label + " landings").toBe(landings);
    expect(ac.cycles, label + " cycles").toBe(cycles);
    expect(ac.latestFlightAt, label + " latest").toBe(flights.at(-1)?.startTime);
    return { s, ac, flights };
  };
  return { t, a, input, submit, review, check, state, ids };
}
it("accept early among many later flights, twice, reject middle, re-accept", async () => {
  const { a, input, submit, review, check, state } = await fixture();
  expect(a.baselineHobbs).toBe(a.currentHobbs);
  const later = [];
  for (let d = 10; d <= 15; d++) later.push(await submit(input(d, d - 7)));  // +3h .. +8h
  expect(later.every((f) => f.status === "accepted")).toBe(true);
  await check("six flights");
  const held = await submit(input(5, 1, { tachOn: undefined, landings: 4, cycles: 3 }));
  expect(held.status).toBe("review");
  await check("held changes nothing");
  await review(held.uuid, "accept", held.input);
  let r = await check("accepted early");
  expect(r.flights).toHaveLength(7);
  const audit1 = r.s.audit.filter((e) => e.action.startsWith("flight.re"));
  console.log("after accept:", audit1.map((e) => [e.action, e.entityUuid === held.uuid ? "held" : "other"]));
  const v1 = r.ac.version;
  await review(held.uuid, "accept", held.input);
  r = await check("accepted twice");
  console.log("version after 1st accept", v1, "after 2nd", r.ac.version, "reviewed rows", r.s.audit.filter((e) => e.action === "flight.reviewed").length);
  await review(later[2].uuid, "reject", later[2].input);
  r = await check("middle rejected");
  expect(r.flights).toHaveLength(6);
  await review(later[2].uuid, "accept", later[2].input);
  r = await check("middle re-accepted");
  expect(r.flights).toHaveLength(7);
  await review(later[5].uuid, "reject", later[5].input);
  r = await check("last rejected");
  await review(held.uuid, "reject", held.input);
  r = await check("held rejected after acceptance");
  const st = await state();
  console.log("statuses:", st.s.flights.map((f) => f.origin + ":" + f.status).join(" "));
  // a pilot's new flight after all reviews, against the current version
  const next = await submit(input(20, 9), st.ac.version);
  expect(next.status).toBe("accepted");
  await check("new flight after reviews");
});
