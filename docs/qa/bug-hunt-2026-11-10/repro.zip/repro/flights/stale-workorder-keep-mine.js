// FL-8: stale-save review on the work order form. While I edit the
// supervisor, a mechanic marks Task 1 "parts delay" with its reason. The
// review shows "Requested work" with the same text on both sides, and Keep
// mine puts the task back to open and erases the delay reason.
const L = require("./lib");
const NUMBER = "WO-STALE-1";
async function openOrders(page) {
  await page.goto(L.BASE + "/work-orders");
  await page.getByRole("heading", { name: "Work orders", exact: true }).waitFor();
}
async function stored(page) {
  const all = await L.demoAll(page);
  const w = all.workOrders.find((x) => x.number === NUMBER);
  return { version: w.version, supervisor: w.supervisor, task: w.tasks[0] };
}
async function expand(dialog, n) {
  const task = dialog.locator("details.work-order-task-details").nth(n - 1);
  if ((await task.getAttribute("open")) === null) await task.locator("> summary").click();
}
(async () => {
  const { browser, context, page: mine } = await L.start();
  const choice = process.argv[2] || "keep";
  try {
    await context.addInitScript(() => sessionStorage.setItem("angel-one-demo", "true"));
    await openOrders(mine);
    await mine.getByRole("button", { name: "Open work order", exact: true }).click();
    let dialog = mine.getByRole("dialog");
    await dialog.getByLabel("Work order number").fill(NUMBER);
    await dialog.getByLabel("Assigned supervisor").fill("First supervisor");
    await dialog.getByLabel("Additional requested work").fill("Inspect cabin fittings");
    await dialog.getByRole("button", { name: "Add requested work", exact: true }).click();
    await dialog.getByRole("button", { name: "Open work order", exact: true }).click();
    await dialog.waitFor({ state: "hidden" });

    // I open the order to change the supervisor and leave the form open.
    const row = mine.getByRole("row").filter({ hasText: NUMBER });
    await row.getByRole("button", { name: "Details", exact: true }).click();
    dialog = mine.getByRole("dialog");
    await dialog.getByLabel("Assigned supervisor").fill("Second supervisor");

    // Meanwhile the mechanic records a parts delay on Task 1 in another tab.
    const theirs = await context.newPage();
    theirs.setDefaultTimeout(15000);
    await openOrders(theirs);
    await theirs.getByRole("row").filter({ hasText: NUMBER }).getByRole("button", { name: "Details", exact: true }).click();
    const td = theirs.getByRole("dialog");
    await expand(td, 1);
    await td.getByLabel("Task 1 status").selectOption("parts-delay");
    await td.getByLabel("Task 1 parts delay").fill("Awaiting replacement fitting");
    await td.getByRole("button", { name: "Save work order", exact: true }).click();
    await td.waitFor({ state: "hidden" });
    const afterTheirs = await stored(theirs);
    console.log("after their save:", JSON.stringify(afterTheirs));
    await theirs.close();

    await dialog.getByRole("button", { name: "Save work order", exact: true }).click();
    const review = mine.getByRole("dialog", { name: "Someone else changed this work order" });
    await review.waitFor();
    const rows = await review.locator("tbody tr").evaluateAll((trs) => trs.map((tr) => [...tr.children].map((c) => c.innerText.trim())));
    console.log("review:", (await review.locator("p").first().innerText()));
    console.log("rows:", JSON.stringify(rows));
    await mine.screenshot({ path: L.SHOTS + "/flights-stale-workorder-review.png" });
    if (choice === "cancel") {
      await review.getByRole("button", { name: "Cancel", exact: true }).click();
      await review.waitFor({ state: "hidden" });
      console.log("after Cancel: supervisor field =", await dialog.getByLabel("Assigned supervisor").inputValue(), "| stored:", JSON.stringify(await stored(mine)));
      return;
    }
    if (choice === "theirs") {
      mine.once("dialog", (d) => d.accept());
      await review.getByRole("button", { name: "Use theirs", exact: true }).click();
      await review.waitFor({ state: "hidden" });
      await mine.waitForTimeout(400);
      const d2 = mine.getByRole("dialog");
      console.log("after Use theirs: supervisor field =", await d2.getByLabel("Assigned supervisor").inputValue());
      await expand(d2, 1);
      console.log("task 1 status field =", await d2.getByLabel("Task 1 status").inputValue(), "| stored:", JSON.stringify(await stored(mine)));
      return;
    }
    await review.getByRole("button", { name: "Keep mine", exact: true }).click();
    await review.waitFor({ state: "hidden" });
    await mine.waitForTimeout(500);
    const after = await stored(mine);
    console.log("after Keep mine:", JSON.stringify(after));
    const work = rows.find((r) => /Requested work/i.test(r[0]));
    L.result(
      afterTheirs.task.status === "parts-delay" && after.task.status !== "parts-delay",
      `Keep mine set Task 1 from "${afterTheirs.task.status}" back to "${after.task.status}" and its parts-delay note to ${JSON.stringify(after.task.partsDelay ?? after.task.delay ?? "")}; the review's Requested work row read ${JSON.stringify(work)}`,
    );
  } catch (e) {
    console.error(e);
    process.exitCode = 2;
  } finally {
    await browser.close();
  }
})();
