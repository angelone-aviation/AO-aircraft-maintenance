// FL-5: a flight started while the aircraft was airworthy cannot be ended
// (logged) by its pilot once a grounding problem is reported after landing.
const L = require("./lib");
(async () => {
  const { browser, context, page } = await L.start();
  try {
    // A line pilot, not an administrator: the demo user moved to the demo's
    // Pilots group (read, flight, discrepancy).
    await L.patchSnapshot(
      page,
      `s.user.isAdmin = false; s.user.groupIds = ["demo-pilots"];
       for (const m of s.members) if (m.id === s.user.id) { m.isAdmin = false; m.groupIds = ["demo-pilots"]; }`,
    );
    await page.getByRole("heading", { name: "Your fleet, at a glance." }).waitFor();
    await page.getByRole("link", { name: "Flight log", exact: true }).click();
    await page.getByRole("button", { name: /^Start flight/ }).first().click();
    const verify = page.getByRole("dialog", { name: "Start flight · Verify aircraft", exact: true });
    await verify.getByLabel(/I reviewed the aircraft maintenance status/).check();
    await verify.getByLabel(/I verified these starting readings/).check();
    await verify.getByRole("button", { name: "Verified — continue to flight information", exact: true }).click();
    const preflight = page.getByRole("dialog", { name: "Start flight · Flight information and preflight", exact: true });
    await preflight.getByLabel("Flight date & time").fill(await L.pageLocal(page, Date.now() - 3600000));
    await preflight.getByLabel("Origin", { exact: true }).fill("MIDFLT");
    for (const [label, v] of [["Fuel starting level (US gal)", "80"], ["Fuel quantity added (US gal)", "0"], ["Engine oil starting level (US qt)", "8"], ["Engine oil quantity added (US qt)", "0"]]) {
      const f = preflight.getByLabel(label);
      if (await f.count()) await f.fill(v);
    }
    await preflight.getByRole("button", { name: "Save preflight & start flight", exact: true }).click();
    await preflight.waitFor({ state: "hidden" });
    console.log("session started");
    // After landing the pilot first reports the problem found in flight.
    await page.getByRole("link", { name: "Discrepancies", exact: true }).click();
    await page.getByRole("button", { name: "Report a problem" }).click();
    await page.getByLabel("What did you observe?").fill("Nose gear shimmy on landing roll");
    await page.getByRole("checkbox", { name: /Aircraft not airworthy/ }).check();
    await page.getByRole("button", { name: "Save report" }).click();
    await page.getByRole("dialog").waitFor({ state: "hidden" });
    await page.getByRole("link", { name: "Flight log", exact: true }).click();
    await page.getByRole("button", { name: "End flight", exact: true }).first().click();
    const ending = page.getByRole("dialog", { name: "End flight", exact: true });
    const start = Number(await ending.getByLabel("Starting Hobbs (hours)").inputValue());
    const endField = ending.getByLabel("Ending Hobbs", { exact: false });
    console.log("Ending Hobbs field disabled:", await endField.isDisabled());
    if (!(await endField.isDisabled())) await endField.fill((start + 1).toFixed(1));
    const text = (await ending.innerText()).replace(/\s+/g, " ");
    const grounded = /grounded[^.]*\./i.exec(text);
    console.log("end dialog says:", grounded && grounded[0]);
    const save = ending.getByRole("button", { name: "End flight & save", exact: true });
    const disabled = await save.isDisabled();
    console.log("End flight & save disabled:", disabled);
    await page.screenshot({ path: L.SHOTS + "/flights-session-grounded.png", fullPage: true });
    let queued = false;
    if (!disabled) {
      await save.click();
      await page.waitForTimeout(1500);
      const all = await L.demoAll(page);
      queued = all.flights.some((f) => f.origin === "MIDFLT");
      console.log("flight stored:", queued, "| dialog error:", ((await ending.getByRole("alert").allInnerTexts()).join(" ")));
    }
    L.result(!queued, `the pilot cannot end (log) a flight already flown once the aircraft is grounded: ${grounded ? grounded[0] : "save refused"}`);
  } catch (e) {
    console.error(e);
    process.exitCode = 2;
  } finally {
    await browser.close();
  }
})();
