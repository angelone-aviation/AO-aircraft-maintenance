// Probe (not a bug repro): inspection form stale-save with a completion
// recorded meanwhile (patched into the stored snapshot).
const L = require("./lib");
(async () => {
  const { browser, page } = await L.start();
  try {
    await page.getByRole("link", { name: "Inspections", exact: true }).click();
    await page.getByRole("button", { name: "New inspection" }).click();
    await page.getByLabel("Reference", { exact: true }).fill("TEST-STALE");
    await page.getByLabel("Description", { exact: true }).fill("Workshop check");
    await page.getByRole("checkbox", { name: "Hours", exact: true }).check();
    await page.getByLabel("Repeat every (hours)", { exact: true }).fill("100");
    await page.getByLabel("Last complied at (tracked hours)").fill("2300");
    await page.getByRole("button", { name: "Save inspection", exact: true }).click();
    await page.getByRole("dialog").waitFor({ state: "hidden" });
    await page.getByRole("row").filter({ hasText: "TEST-STALE" }).getByRole("button", { name: "Details", exact: true }).click();
    const form = page.getByRole("dialog", { name: "Inspection details" });
    await form.getByLabel("Description", { exact: true }).fill("Workshop check (reworded)");
    const before = await L.patchStored(page, `
      const i = s.inspections.find((x) => x.reference === "TEST-STALE");
      const before = JSON.parse(JSON.stringify(i));
      i.version += 1; i.lastSeconds = 2340 * 3600; i.dueSeconds = 2440 * 3600; i.lastDate = "2026-11-09";
      i.materials = "2 qt MIL-PRF-23699"; i.calendarExempt = true; i.calendarExemptReason = "Hours only per MM";
      i.requiredParts = [{ uuid: "11111111-1111-4111-8111-111111111111", partNumber: "MS-1", description: "Seal", quantity: 2 }];
      return before;`);
    console.log("before:", JSON.stringify(before));
    await form.getByRole("button", { name: "Save inspection", exact: true }).click();
    const review = page.getByRole("dialog", { name: "Someone else changed this inspection" });
    await review.waitFor();
    console.log("rows:", JSON.stringify(await L.reviewRows(review), null, 1));
    await review.getByRole("button", { name: "Keep mine", exact: true }).click();
    await page.waitForTimeout(800);
    console.log("error in review:", await review.getByRole("alert").allInnerTexts().catch(() => []));
    const all = await L.demoAll(page);
    console.log("after Keep mine:", JSON.stringify(all.inspections.find((x) => x.reference === "TEST-STALE")));
  } catch (e) { console.error(e); process.exitCode = 2; } finally { await browser.close(); }
})();
