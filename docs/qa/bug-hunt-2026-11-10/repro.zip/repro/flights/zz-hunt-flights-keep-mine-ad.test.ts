/**
 * Responsibility: Bug-hunt repro FL-3 on the server: what "Keep mine" writes
 *   when an AD draft loaded before a compliance is re-saved against the
 *   current version, and what the change log keeps.
 * Layer: Test. convex-test; copy to convex/ and run
 *   `npx vitest run convex/zz-hunt-flights-keep-mine-ad.test.ts`.
 * Dependencies: convex/airworthiness.ts, convex/schema.ts, src/data/demo.ts,
 *   src/domain/airworthiness.ts.
 */
import { convexTest } from "convex-test";
import { it, expect } from "vitest";
import schema from "./schema";
import { api } from "./_generated/api";
import { demoSnapshot } from "../src/data/demo";
import { blankAD, blankADTask, type AD } from "../src/domain/airworthiness";

const modules = import.meta.glob([
  "./**/*.ts",
  "./_generated/*.js",
  "!./**/*.test.ts",
  "!./**/*.d.ts",
]);
const PROGRAM = "demo-program";

it("FL-3: re-saving a draft loaded before a compliance keeps the due limit the compliance set", async () => {
  const t = convexTest(schema, modules);
  const s = demoSnapshot();
  const subject = await t.run(async (ctx) => {
    for (const a of s.aircraft) await ctx.db.insert("aircraft", a);
    await ctx.db.insert("programs", s.programs![0]);
    const id = await ctx.db.insert("users", {
      active: true,
      isAdmin: true,
      name: "Admin",
      groupIds: [],
      activeProgramUuid: PROGRAM,
    });
    const session = await ctx.db.insert("authSessions", {
      userId: id,
      expirationTime: Date.now() + 86400000,
    });
    return `${id}|${session}`;
  });
  const admin = t.withIdentity({ subject });
  const send = (command: object) =>
    admin.mutation(api.airworthiness.save, {
      programUuid: PROGRAM,
      payload: JSON.stringify(command),
    });
  const stored = async (): Promise<AD> =>
    JSON.parse(
      (await t.run((ctx) => ctx.db.query("airworthiness").first()))!.payload,
    );

  const record = blankAD(s.aircraft[0].uuid);
  record.source.number = "2026-01-01";
  record.source.subject = "Inspect attachment fittings";
  record.applicability = "Applicable";
  record.reviewRequired = false;
  record.tasks = [
    {
      ...blankADTask(),
      description: "Inspect fittings per paragraph (g)",
      recurrence: "Recurring",
      dueHours: 2300,
      intervalHours: 100,
    },
  ];
  await send({ kind: "save", record });
  // The form I leave open holds this copy (version 1, next due 2300 h).
  const loaded = await stored();

  await send({
    kind: "comply",
    uuid: loaded.uuid,
    version: loaded.version,
    entry: {
      uuid: crypto.randomUUID(),
      taskUuid: loaded.tasks[0].uuid,
      date: "2026-01-02",
      hours: 2340,
      cycles: null,
      method: "Inspected fittings; no defects",
      serviceBulletin: "",
      terminatedBy: "",
      workOrderUuid: "",
      mechanic: "A. Mechanic",
      certificate: "",
      evidence: "",
      recordedAt: 0,
      recordedBy: "",
    },
  });
  const complied = await stored();
  expect(complied.tasks[0].dueHours).toBe(2440);

  // "Keep mine": my copy, subject reworded, sent against the current version.
  const mine: AD = structuredClone(loaded);
  mine.source.subject = "Inspect wing attachment fittings";
  await send({
    kind: "save",
    record: { ...mine, version: complied.version },
    reason: "Subject wording corrected.",
  });
  const kept = await stored();
  const audit = (await t.run((ctx) => ctx.db.query("audit").collect())).filter(
    (row) => row.entityUuid === loaded.uuid,
  );
  console.log(
    "audit rows:",
    audit.map((row) => ({
      action: row.action,
      reason: row.reason,
      beforeDue: row.before && JSON.parse(row.before).tasks?.[0]?.dueHours,
      afterDue: row.after && JSON.parse(row.after).tasks?.[0]?.dueHours,
    })),
  );
  expect(kept.history).toHaveLength(1);
  expect(kept.source.subject).toBe("Inspect wing attachment fittings");
  // The reworded subject must not undo the limit the compliance advanced.
  expect(kept.tasks[0].dueHours).toBe(2440);
});
