// FL-3: an AD form left open while someone records compliance; Save -> the
// stale-save review; "Keep mine" puts the action's next-due limit back to the
// value from before the compliance, and the review never shows that value.
const L = require("./lib");
const NUMBER = "2026-01-01";
async function openAD(page) {
  await page.goto(L.BASE + "/airworthiness");
  await page.getByRole("heading", { name: "Airworthiness directives", exact: true }).waitFor();
}
async function due(page) {
  const all = await L.demoAll(page);
  const ad = all.airworthiness.find((r) => r.source.number === NUMBER);
  return { dueHours: ad.tasks[0].dueHours, history: ad.history.length, subject: ad.source.subject, version: ad.version };
}
(async () => {
  const { browser, context, page: mine } = await L.start();
  try {
    await context.addInitScript(() => sessionStorage.setItem("angel-one-demo", "true"));
    await openAD(mine);
    await mine.getByRole("button", { name: "Add AD", exact: true }).click();
    let dialog = mine.getByRole("dialog");
    await dialog.getByLabel("AD number", { exact: true }).fill(NUMBER);
    await dialog.getByLabel("Subject", { exact: true }).fill("Inspect attachment fittings");
    await dialog.getByLabel("Applicability", { exact: true }).selectOption("Applicable");
    await dialog.getByLabel("Applicability and source changes reviewed").check();
    await dialog.getByRole("button", { name: "Add required action" }).click();
    await dialog.getByLabel("Required action", { exact: true }).fill("Inspect fittings per paragraph (g)");
    await dialog.getByLabel("Action recurrence").selectOption("Recurring");
    await dialog.getByRole("checkbox", { name: "Hours", exact: true }).check();
    await dialog.getByLabel("Next due hours").fill("2300");
    await dialog.getByLabel("Repeat every hours").fill("100");
    await dialog.getByRole("button", { name: "Save AD", exact: true }).click();
    await dialog.waitFor({ state: "hidden" });
    console.log("created:", JSON.stringify(await due(mine)));

    // I open the AD form to fix the subject wording and leave it open.
    await mine.locator(".ad-register-group > summary").first().click();
    await mine.getByRole("button", { name: "Details for AD " + NUMBER }).click();
    await mine.getByRole("dialog").getByRole("button", { name: "Review / edit AD" }).first().click();
    dialog = mine.getByRole("dialog");
    await dialog.getByLabel("Subject", { exact: true }).fill("Inspect wing attachment fittings");
    const reason = dialog.getByLabel("Reason for change");
    if (await reason.count()) await reason.fill("Subject wording corrected.");

    // Meanwhile a mechanic records compliance at 2340 h in another tab.
    const theirs = await context.newPage();
    theirs.setDefaultTimeout(15000);
    await openAD(theirs);
    await theirs.locator(".ad-register-group > summary").first().click();
    await theirs.getByRole("button", { name: "Details for AD " + NUMBER }).click();
    await theirs.getByRole("button", { name: "Record compliance", exact: true }).click();
    const comply = theirs.getByRole("dialog");
    await comply.getByLabel("Hours at completion").fill("2340");
    await comply.getByLabel("Method of compliance").fill("Inspected fittings; no defects");
    await comply.getByRole("button", { name: "Save compliance" }).click();
    await theirs.waitForTimeout(800);
    const afterComply = await due(theirs);
    console.log("after their compliance:", JSON.stringify(afterComply));
    await theirs.close();

    await dialog.getByRole("button", { name: "Save AD", exact: true }).click();
    const review = mine.getByRole("dialog", { name: "Someone else changed this AD" });
    await review.waitFor();
    const text = await review.innerText();
    console.log("--- review dialog ---\n" + text + "\n---");
    await mine.screenshot({ path: L.SHOTS + "/flights-stale-ad-review.png" });
    const rows = await review.locator("tbody tr").evaluateAll((trs) =>
      trs.map((tr) => [...tr.children].map((c) => c.innerText.trim())));
    console.log("rows:", JSON.stringify(rows).slice(0, 1500));
    await review.getByRole("button", { name: "Keep mine", exact: true }).click();
    await review.waitFor({ state: "hidden" });
    await mine.waitForTimeout(500);
    const after = await due(mine);
    console.log("after Keep mine:", JSON.stringify(after));
    const actions = rows.find((r) => /Required actions/i.test(r[0]));
    const identical = actions && actions[1] === actions[2];
    const showsDue = /2440|2300/.test(rows.filter((r) => !/History/i.test(r[0])).flat().join(" "));
    L.result(
      after.dueHours !== afterComply.dueHours && after.history === afterComply.history,
      `Keep mine set next due back to ${after.dueHours} h (compliance at 2340 h had advanced it to ${afterComply.dueHours} h; the compliance entry is still there); ` +
        `review row "Required actions" showed identical text on both sides: ${identical}; a due value was shown outside raw JSON: ${showsDue}`,
    );
  } catch (e) {
    console.error(e);
    process.exitCode = 2;
  } finally {
    await browser.close();
  }
})();
