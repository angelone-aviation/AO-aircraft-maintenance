// Probe + FL repro: the seven-day window at day 6 / 7 / 8, pending entries
// across expiry, and a sign-in stamped slightly ahead of the device clock
// (a device clock that runs behind the server).
const L = require("./lib");
const DAY = 86400000;
async function setAuth(page, offsetMs) {
  await L.patchSnapshot(page, `s.authenticatedAt = Date.now() + arg;`, offsetMs);
  await page.waitForLoadState("domcontentloaded");
  await page.waitForTimeout(1200);
  return (await page.locator("h1").first().innerText()).trim();
}
(async () => {
  const { browser, context, page } = await L.start();
  const mode = process.argv[2] || "all";
  try {
    if (mode === "all") {
      console.log("day 6:", await setAuth(page, -6 * DAY));
      console.log("7 days minus 1 minute:", await setAuth(page, -7 * DAY + 60000));
      console.log("day 7:", await setAuth(page, -7 * DAY));
      console.log("day 8:", await setAuth(page, -8 * DAY));
      console.log("renew:"); await page.getByRole("button", { name: "Renew demo access" }).click();
      await page.getByRole("heading", { name: "Your fleet, at a glance." }).waitFor();
      // Pending entry kept across expiry, synced after renewal.
      await L.swReady(page);
      await context.setOffline(true);
      const dialog = await L.openLogFlight(page, "N206MA");
      await dialog.getByLabel("Flight date & time").fill(await L.pageLocal(page, Date.now() - 3600000));
      await dialog.getByLabel("Ending Hobbs *", { exact: true }).fill("2342.0");
      await dialog.getByLabel("Origin", { exact: true }).fill("EXPIRY");
      await dialog.getByRole("button", { name: "Save flight", exact: true }).click();
      await dialog.waitFor({ state: "hidden" });
      console.log("offline, expired (day 8):", await setAuth(page, -8 * DAY));
      const expiredText = (await page.locator("main, body").first().innerText()).replace(/\s+/g, " ").slice(0, 300);
      console.log("expired screen:", expiredText);
      await context.setOffline(false);
      await page.waitForTimeout(1500);
      let all = await L.demoAll(page);
      console.log("online but still expired: flight synced?", all.flights.some((f) => f.origin === "EXPIRY"));
      await page.getByRole("button", { name: "Renew demo access" }).click();
      await page.getByRole("link", { name: "Flight log", exact: true }).waitFor();
      await page.waitForTimeout(2500);
      all = await L.demoAll(page);
      console.log("after renewal: flight synced?", all.flights.some((f) => f.origin === "EXPIRY"));
      return;
    }
    // A sign-in the server stamped 3 minutes after the device's clock time.
    const heading = await setAuth(page, 3 * 60000);
    const text = (await page.locator("body").innerText()).replace(/\s+/g, " ");
    await page.screenshot({ path: L.SHOTS + "/flights-clock-behind-lockout.png" });
    console.log("heading:", heading);
    L.result(/Time to reconnect/.test(heading), `a session stamped 3 minutes ahead of the device clock opens on "${heading}": ${/seven-day offline access has expired/.exec(text)?.[0]}`);
  } catch (e) { console.error(e); process.exitCode = 2; } finally { await browser.close(); }
})();
