// FL-1: two legs logged offline on the same aircraft: the second is held for
// review after sync ("Aircraft totals changed after this entry was started")
// although nobody else touched the aircraft, and totals omit it.
const L = require("./lib");
async function log(page, ending, minsAgo, origin) {
  const dialog = await L.openLogFlight(page, "N206MA");
  await dialog.getByLabel("Flight date & time").fill(await L.pageLocal(page, Date.now() - minsAgo * 60000));
  await dialog.getByLabel("Ending Hobbs *", { exact: true }).fill(ending);
  await dialog.getByLabel("Origin", { exact: true }).fill(origin);
  const start = await dialog.locator(".flight-meter, .flight-strip, form").first().innerText().catch(() => "");
  await dialog.getByRole("button", { name: "Save flight", exact: true }).click();
  await dialog.waitFor({ state: "hidden" });
  return start;
}
(async () => {
  const { browser, context, page } = await L.start();
  try {
    await L.swReady(page);
    await context.setOffline(true);
    await page.waitForTimeout(500);
    await log(page, "2342.2", 120, "LEGONE");
    const second = await log(page, "2343.0", 30, "LEGTWO");
    console.log("second form text (starting readings):", second.replace(/\s+/g, " ").slice(0, 400));
    await context.setOffline(false);
    await page.waitForTimeout(2500);
    await page.getByRole("link", { name: "Flight log", exact: true }).click();
    const one = (await page.getByRole("row").filter({ hasText: "LEGONE" }).innerText()).replace(/\s+/g, " ");
    const two = (await page.getByRole("row").filter({ hasText: "LEGTWO" }).innerText()).replace(/\s+/g, " ");
    console.log("LEGONE:", one);
    console.log("LEGTWO:", two);
    const all = await L.demoAll(page);
    const a = all.aircraft.find((x) => x.registration === "N206MA");
    const f2 = all.flights.find((f) => f.origin === "LEGTWO");
    console.log("aircraft hobbs:", a.currentHobbs / 3600, "flight2:", f2.status, f2.reviewReason);
    await page.screenshot({ path: L.SHOTS + "/flights-offline-two-legs.png", fullPage: true });
    L.result(f2.status === "review", `second offline leg is held: "${f2.reviewReason}"; aircraft Hobbs stays ${a.currentHobbs / 3600}`);
  } catch (e) {
    console.error(e);
    process.exitCode = 2;
  } finally {
    await browser.close();
  }
})();
