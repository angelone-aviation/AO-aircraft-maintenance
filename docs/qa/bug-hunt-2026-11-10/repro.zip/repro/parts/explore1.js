const { start, snapshot, seed, loc, stock, pdfText, H, BASE } = require("./lib");
(async () => {
  const { browser, page, errors } = await start();
  try {
    await seed(page, [loc("store", "Main store", { address: "1 Hangar Rd" }), stock("lot1", "store", "FILTER-1", { cost: 19.99 })]);
    await page.goto(BASE + "/purchase-orders");
    await page.getByRole("button", { name: "New PO" }).click();
    const d = page.getByRole("dialog").last();
    await page.waitForTimeout(500);
    console.log(await d.innerText());
    await page.screenshot({ path: H + "/shots/parts-po-new.png", fullPage: true });
  } catch (e) { console.log("FAIL", e.message.slice(0, 600)); await page.screenshot({ path: H + "/shots/parts-fail.png" }); }
  console.log("errors", errors);
  await browser.close();
})();
