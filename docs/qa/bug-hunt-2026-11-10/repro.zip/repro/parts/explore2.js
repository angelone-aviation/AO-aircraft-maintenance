const { start, snapshot, seed, loc, stock, pdfText, H, BASE } = require("./lib");
const step = async (name, f) => { try { await f(); console.log("ok:", name); } catch (e) { console.log("FAIL:", name, "::", e.message.split("\n").slice(0, 4).join(" | ")); throw e; } };
(async () => {
  const { browser, page, errors } = await start();
  const d = page.getByRole("dialog").last();
  const detail = page.getByRole("dialog").first();
  try {
    await seed(page, [loc("store", "Main store", { address: "1 Hangar Rd" }), stock("lot1", "store", "FILTER-1", { cost: 19.99 })]);
    await page.goto(BASE + "/purchase-orders");
    await page.getByRole("button", { name: "New PO" }).click();
    await step("vendor", async () => {
      await d.getByLabel("Vendor", { exact: true }).fill("Aéro Łódź Sp. z o.o.");
      await d.getByRole("button", { name: "Quick add", exact: true }).click();
    });
    await step("address", async () => {
      await d.getByLabel("Shipping address — Saved address", { exact: true }).selectOption("__new");
      const a = page.getByRole("dialog", { name: "Add new shipping address", exact: true });
      await a.getByLabel("Address name", { exact: true }).fill("Hangar Ünïcode");
      for (const [f, v] of Object.entries({ "Street address": "Żwirki i Wigury 1 №5 — 東京 " + "Longstreetname".repeat(12), City: "Łódź", "State / province": "ŁD", "ZIP / postal code": "90-001", Country: "Poland", "Contact name": "Zoë Ångström", Email: "recv@example.com", Phone: "+48 42 555 0100" }))
        await a.getByLabel(`Shipping address — ${f}`, { exact: true }).fill(v);
      await a.getByRole("button", { name: "Save address", exact: true }).click();
      await page.waitForTimeout(800);
      if (await a.isVisible()) { console.log("ADDRESS DIALOG STILL OPEN:\n" + (await a.innerText()).slice(0, 1500)); }
    });
    await page.screenshot({ path: H + "/shots/parts-po-addr.png", fullPage: true });
    await step("lines", async () => {
      await d.getByLabel("Shipping cost").fill("7.35");
      await d.getByLabel("Part 1 inventory location").selectOption("store");
      await d.getByLabel("Part 1 stock item").selectOption("lot1");
      console.log("unit autopop:", await d.getByLabel("Part 1 unit cost").inputValue(), await d.getByLabel("Part 1 number").inputValue());
      await d.getByLabel("Part 1 quantity", { exact: true }).fill("3");
      await d.getByRole("button", { name: "Add part", exact: true }).click();
      await d.getByLabel("Part 2 inventory location").selectOption("store");
      await d.getByLabel("Part 2 number").fill("SEAL-9");
      await d.getByLabel("Part 2 description").fill("O-ring Ø12 µm ≥ 10 kΩ “quoted” – dash");
      await d.getByLabel("Part 2 category").selectOption({ label: "Supply" });
      await d.getByLabel("Part 2 quantity", { exact: true }).fill("7");
      await d.getByLabel("Part 2 unit cost").fill("0.07");
      await d.getByRole("button", { name: "Add part", exact: true }).click();
      await d.getByLabel("Part 3 inventory location").selectOption("store");
      await d.getByLabel("Part 3 number").fill("STARTER-X");
      await d.getByLabel("Part 3 description").fill("Starter exchange");
      await d.getByLabel("Part 3 quantity", { exact: true }).fill("1");
      await d.getByLabel("Part 3 unit cost").fill("1005.01");
      await d.getByLabel("Part 3 is an exchange (core return due)").check();
      await d.getByLabel("Part 3 core due (days after receipt)").fill("10");
    });
    console.log("editor total:", (await d.getByText(/^Total:/).innerText()));
    await step("save", async () => {
      await d.getByRole("button", { name: "Save draft PO", exact: true }).click();
      await page.waitForTimeout(1000);
      if (await d.isVisible()) console.log("DIALOG STILL OPEN:", (await d.innerText()).slice(-800));
    });
    console.log("list row:", (await page.getByRole("row").filter({ hasText: "Aéro" }).innerText()).replace(/\n/g, " | "));
    let s = await snapshot(page); let po = s.purchaseOrders[0];
    console.log("stored:", JSON.stringify({ number: po.number, shippingCents: po.shippingCents, lines: po.lines.map((l) => [l.partNumber, l.quantity, l.unitCents, l.kind, l.exchange, l.coreDueDays]), shipTo: po.shipTo, vendorContact: po.vendorContact }));
    await page.getByRole("row").filter({ hasText: "Aéro" }).getByRole("button").click();
    await page.waitForTimeout(500);
    console.log("DETAIL:\n" + (await detail.innerText()));
    await page.screenshot({ path: H + "/shots/parts-po-detail.png", fullPage: true });
    await step("pdf", async () => {
      const dl = page.waitForEvent("download");
      await detail.getByRole("button", { name: "Save PO PDF", exact: true }).click();
      const f = H + "/shots/parts-po-draft.pdf"; await (await dl).saveAs(f);
      console.log("PDF:\n" + (await pdfText(f)).join("\n--page--\n"));
    });
  } catch (e) { await page.screenshot({ path: H + "/shots/parts-fail.png", fullPage: true }); }
  console.log("errors", errors);
  await browser.close();
})();
