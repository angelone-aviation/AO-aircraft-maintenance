// PT-10 (browser): the purchase-order PDF replaces characters outside
// Latin-1 (Ł, Ż, ≥, Ω, ⅜, №, CJK) with other characters, so the vendor name,
// delivery address and part descriptions sent to the vendor are wrong.
// Usage: node pt10-po-pdf-unicode.js
const { start, seed, loc, pdfText, result, H } = require("./lib");
const F = require("./flows");
(async () => {
  const { browser, page } = await start();
  try {
    await seed(page, [loc("store", "Main store")]);
    await F.newPO(page, {
      vendor: "Łódź Aero",
      lines: [{ number: "AN3-5A", description: "Bolt ⅜ in ≥ 10 kΩ", quantity: 4, unit: "1.25" }],
    });
    await F.openPO(page, "Łódź");
    const onScreen = await F.detail(page).innerText();
    const dl = page.waitForEvent("download");
    await F.detail(page).getByRole("button", { name: "Save PO PDF", exact: true }).click();
    const file = H + "/shots/parts-pt10-po.pdf";
    await (await dl).saveAs(file);
    const text = (await pdfText(file)).join("\n");
    // jsPDF letter-spaces a line it had to encode as UTF-16; ignore spacing.
    const squeezed = text.replace(/ /g, "");
    const lines = text.split("\n").filter((l) => /V\s*e\s*n\s*d\s*o\s*r|A\s*N\s*3/.test(l));
    console.log("Screen shows vendor 'Łódź Aero':", onScreen.includes("Łódź Aero"), "| description:", onScreen.includes("Bolt ⅜ in ≥ 10 kΩ"));
    console.log("PDF lines:", JSON.stringify(lines));
    const ok = squeezed.includes("ŁódźAero") && squeezed.includes("Bolt⅜in≥10kΩ");
    result(!ok, "PO PDF prints " + JSON.stringify(lines.map((l) => l.replace(/(\S) (?=\S)/g, "$1"))) + " for vendor 'Łódź Aero' and 'Bolt ⅜ in ≥ 10 kΩ'");
  } catch (e) {
    console.log("ERROR", e.message.split("\n").slice(0, 4).join(" | "));
    await page.screenshot({ path: H + "/shots/parts-fail.png", fullPage: true });
    process.exitCode = 2;
  }
  await browser.close();
})();
