/**
 * Responsibility: Bug-hunt 2026-11-10 repro PT-9: a stock-replenishment
 *   request whose order was fully received must not read "On purchase order"
 *   once its parts are released into general stock.
 * Layer: Test. Vitest suite; asserts the CORRECT behaviour, so it fails while
 *   the bug exists.
 * Dependencies: src/domain/purchaseOrders.ts, partsRequests.ts, management;
 *   src/data/demo.ts (seed).
 *
 * Run: cp <this file> src/domain/ && npx vitest run src/domain/zz-hunt-pt-stock-request.test.ts
 */
import { expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import { applyPOCommand, poDraftSchema } from "./purchaseOrders";
import { applyManagement, type Stock } from "./management";
import {
  applyRequestCommand,
  requestDraftSchema,
  requestLineProgress,
  requestStatus,
} from "./partsRequests";

const rq = () => crypto.randomUUID();
const now = Date.parse("2026-10-15T12:00:00Z");

it("PT-9: a received and released stock request is not 'On purchase order' with the full quantity still to order", () => {
  const s = demoSnapshot();
  s.user.isAdmin = true;
  applyManagement(
    s,
    {
      action: "record.save",
      requestUuid: rq(),
      reason: "Opening location",
      record: {
        uuid: "store",
        version: 0,
        kind: "location",
        name: "Store",
        address: "",
        contact: "",
      },
    },
    now,
  );
  applyRequestCommand(
    s,
    {
      kind: "save",
      requestUuid: rq(),
      draft: requestDraftSchema.parse({
        uuid: "req",
        version: 0,
        source: { kind: "stock", uuid: "" },
        mode: "parts",
        date: "2026-10-15",
        engineer: "E",
        priority: "P3 Stock",
        requiredBy: "",
        currency: "USD",
        vendor: "Vendor A",
        shipTo: "Main hangar",
        lines: [
          { uuid: "rl", partNumber: "FILTER", description: "Filter", quantity: 2 },
        ],
      }),
    },
    now,
  );
  const draft = poDraftSchema.parse({
    uuid: "po",
    version: 0,
    vendor: "Vendor A",
    vendorContact: "",
    shipTo: "Main hangar",
    expectedDate: "",
    currency: "USD",
    shippingCents: 0,
    notes: "",
    lines: [
      {
        uuid: "line",
        locationUuid: "store",
        partNumber: "FILTER",
        description: "Filter",
        quantity: 2,
        unitCents: 1999,
        kind: "part",
        requestAllocations: [{ requestUuid: "req", lineUuid: "rl", quantity: 2 }],
      },
    ],
  });
  const po = (c: object, version: number) =>
    applyPOCommand(
      s,
      { requestUuid: rq(), uuid: "po", version, reason: "", ...c } as never,
      now,
    );
  applyPOCommand(s, { kind: "save", requestUuid: rq(), drafts: [draft] }, now);
  po({ kind: "issue" }, 1);
  po(
    {
      kind: "receive",
      date: "2026-10-15",
      invoice: "INV",
      notes: "",
      lines: [{ lineUuid: "line", quantity: 2, condition: "new", serials: [] }],
    },
    2,
  );
  po({ kind: "close" }, 3);
  const request = () => s.partsRequests!.find((r) => r.uuid === "req")!;
  const lot = s.management!.find((r): r is Stock => r.kind === "stock")!;
  // The 2 filters are in stock but held for the stock request itself. Put
  // them on the shelf for anyone to use, which is what the request was for.
  applyRequestCommand(
    s,
    {
      kind: "release",
      requestUuid: rq(),
      uuid: "req",
      version: request().version,
      lineUuid: "rl",
      stockUuid: lot.uuid,
      quantity: 2,
      alternateConfirmed: false,
    },
    now,
  );
  expect(requestStatus(s, request())).not.toBe("On purchase order");
  expect(requestLineProgress(s, request(), "rl").toOrder).toBe(0);
});
