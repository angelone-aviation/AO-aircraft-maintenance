/**
 * Responsibility: Bug-hunt 2026-11-10 repro (PT-1, PT-2): a Flight Program
 *   transfer must not strand an issued purchase order.
 * Layer: Test. convex-test suite; asserts the CORRECT behaviour, so it fails
 *   while the bugs exist.
 * Dependencies: convex/programs, convex/purchaseOrders, convex/partsRequests,
 *   convex/management, src/data/demo.
 *
 * Run: cp <this file> convex/ && npx vitest run convex/zz-hunt-pt-transfer.test.ts
 */
import { convexTest } from "convex-test";
import { it, expect } from "vitest";
import schema from "./schema";
import { api } from "./_generated/api";
import { demoSnapshot } from "../src/data/demo";
const modules = import.meta.glob([
  "./**/*.ts",
  "./_generated/*.js",
  "!./**/*.test.ts",
  "!./**/*.d.ts",
]);
const DAY_MS = 86_400_000;
const today = new Date().toISOString().slice(0, 10);

async function setup() {
  const t = convexTest(schema, modules);
  const identity = await t.run(async (ctx) => {
    for (const uuid of ["A", "B"]) {
      await ctx.db.insert("programs", {
        ...demoSnapshot().programs![0],
        uuid,
        name: uuid,
        email: `${uuid}@example.test`,
      });
      await ctx.db.insert("aircraft", {
        ...demoSnapshot().aircraft[0],
        uuid: `plane-${uuid}`,
        registration: uuid,
        programUuid: uuid,
        program: uuid,
      });
      await ctx.db.insert("management", {
        uuid: `location-${uuid}`,
        kind: "location",
        programUuid: uuid,
        payload: JSON.stringify({
          uuid: `location-${uuid}`,
          version: 0,
          kind: "location",
          programUuid: uuid,
          name: `Hangar ${uuid}`,
          address: "",
          contact: "",
        }),
      });
    }
    const user = await ctx.db.insert("users", {
      name: "system",
      active: true,
      isAdmin: true,
      groupIds: [],
      activeProgramUuid: "A",
    });
    const session = await ctx.db.insert("authSessions", {
      userId: user,
      expirationTime: Date.now() + DAY_MS,
    });
    return { subject: `${user}|${session}` };
  });
  const system = t.withIdentity(identity);
  const po = (c: object) =>
    system.mutation(api.purchaseOrders.execute, {
      programUuid: "A",
      payload: JSON.stringify({ requestUuid: crypto.randomUUID(), ...c }),
    });
  const draft = (uuid: string, line: object) => ({
    kind: "save",
    drafts: [
      {
        uuid,
        version: 0,
        vendor: "Vendor",
        vendorContact: "",
        shipTo: "Hangar",
        expectedDate: "",
        currency: "USD",
        shippingCents: 0,
        notes: "",
        lines: [{ uuid: "line", locationUuid: "location-A", ...line }],
      },
    ],
  });
  return { t, system, po, draft };
}

it("PT-1: a component out for repair on an issued PO cannot leave the program, or can still be received back", async () => {
  const { system, po, draft } = await setup();
  await system.mutation(api.management.execute, {
    programUuid: "A",
    payload: JSON.stringify({
      requestUuid: crypto.randomUUID(),
      reason: "Stock in",
      action: "record.save",
      record: {
        kind: "component",
        uuid: "alt",
        version: 0,
        aircraftUuid: "",
        componentType: "Appliance",
        partNumber: "ALT-1",
        serial: "S1",
        manufacturer: "",
        notes: "",
        trackTime: true,
        trackCycles: false,
        trackCalendar: false,
        installed: false,
        locationUuid: "location-A",
        installedSeconds: 0,
        installedCycles: 0,
        timeSinceNew: 0,
        timeSinceOverhaul: null,
        timeSinceRepair: null,
        cyclesSinceNew: 0,
        serviceDaysBase: 0,
      },
    }),
  });
  await system.mutation(api.partsRequests.execute, {
    programUuid: "A",
    payload: JSON.stringify({
      kind: "save",
      requestUuid: crypto.randomUUID(),
      draft: {
        uuid: "req",
        version: 0,
        source: { kind: "component", uuid: "alt" },
        mode: "repair",
        date: today,
        engineer: "E",
        priority: "P2 Routine",
        requiredBy: "",
        currency: "USD",
        vendor: "Vendor",
        shipTo: "Hangar",
        lines: [
          {
            uuid: "rl",
            partNumber: "ALT-1",
            description: "Alternator",
            quantity: 1,
            componentUuid: "alt",
            service: "repair",
            defect: "Low output",
            workRequested: "Repair",
          },
        ],
      },
    }),
  });
  await po(
    draft("po-repair", {
      partNumber: "ALT-1",
      description: "Alternator",
      quantity: 1,
      unitCents: 50000,
      kind: "component",
      repairComponentUuid: "alt",
      repairWork: "repair",
      requestAllocations: [{ requestUuid: "req", lineUuid: "rl", quantity: 1 }],
    }),
  );
  await po({ kind: "issue", uuid: "po-repair", version: 1, reason: "" });
  await po({
    kind: "ship",
    uuid: "po-repair",
    version: 2,
    date: today,
    carrier: "UPS",
    tracking: "1Z",
    lines: [{ lineUuid: "line", quantity: 1 }],
  });
  let transferRefused = false;
  try {
    await system.mutation(api.programs.transfer, {
      programUuid: "A",
      kind: "component",
      uuid: "alt",
      destination: "B",
      reason: "New base",
    });
  } catch {
    transferRefused = true;
  }
  if (transferRefused) return;
  // The transfer went through, so the order must still take the unit back.
  await expect(
    po({
      kind: "receive",
      uuid: "po-repair",
      version: 3,
      date: today,
      invoice: "INV",
      notes: "",
      lines: [
        {
          lineUuid: "line",
          quantity: 1,
          condition: "overhauled",
          serials: [{ serial: "S1", hours: 0, cycles: 0 }],
        },
      ],
    }),
  ).resolves.toBeDefined();
});

it("PT-2: an aircraft named on an issued PO line cannot leave the program, or the order can still be received", async () => {
  const { system, po, draft } = await setup();
  await po(
    draft("po-plane", {
      partNumber: "FILTER",
      description: "Oil filter",
      quantity: 2,
      unitCents: 1999,
      kind: "part",
      aircraftUuid: "plane-A",
    }),
  );
  await po({ kind: "issue", uuid: "po-plane", version: 1, reason: "" });
  await po({
    kind: "ship",
    uuid: "po-plane",
    version: 2,
    date: today,
    carrier: "UPS",
    tracking: "1Z",
    lines: [{ lineUuid: "line", quantity: 2 }],
  });
  let transferRefused = false;
  try {
    await system.mutation(api.programs.transfer, {
      programUuid: "A",
      kind: "aircraft",
      uuid: "plane-A",
      destination: "B",
      reason: "New base",
    });
  } catch {
    transferRefused = true;
  }
  if (transferRefused) return;
  await expect(
    po({
      kind: "receive",
      uuid: "po-plane",
      version: 3,
      date: today,
      invoice: "INV",
      notes: "",
      lines: [{ lineUuid: "line", quantity: 2, condition: "new", serials: [] }],
    }),
  ).resolves.toBeDefined();
});
