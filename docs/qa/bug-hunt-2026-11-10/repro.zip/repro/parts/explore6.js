const { start, snapshot, seed, loc, stock, H, BASE } = require("./lib");
(async () => {
  const { browser, page, errors } = await start();
  try {
    await seed(page, [loc("store", "Main store"), loc("store2", "Remote store"),
      stock("lotA", "store", "OIL-A", { quantity: 10 }), stock("lotB", "store2", "OIL-A", { quantity: 2 }), stock("lotC", "store", "UNIQ-1"),
      stock("lotD", "store", "ÜBER-№5 " + "X".repeat(60), { description: "Long “unicode” ⅜ part ".repeat(8) })]);
    await page.goto(BASE + "/scan"); await page.waitForTimeout(800);
    const form = page.getByRole("form", { name: "Enter a label manually" });
    const tryCode = async (code) => {
      await page.goto(BASE + "/scan"); await form.getByLabel("Enter code manually", { exact: true }).fill(code);
      await form.getByRole("button", { name: "Open item", exact: true }).click(); await page.waitForTimeout(500);
      const alert = (await form.getByRole("alert").allInnerTexts()).join("|");
      const dlg = await page.getByRole("dialog").count() ? (await page.getByRole("dialog").last().getByLabel("Part number", { exact: true }).inputValue().catch(() => "dialog?")) : "";
      console.log(JSON.stringify(code), "=> alert:", alert, "| opened:", dlg, "| url:", page.url().replace(BASE, ""));
    };
    for (const c of ["NOPE-404", "OIL-A", " uniq-1 ", "lotC", "LOTC", BASE + "/inventory?item=lotC&program=demo-program", "https://evil.example/inventory?item=lotC", BASE + "/inventory?item=lotC&program=other", "javascript:alert(1)", "https://x.test/other?item=lotC", ""]) await tryCode(c);
    // label for long unicode item
    await page.goto(BASE + "/inventory");
    const row = page.getByRole("row").filter({ hasText: "ÜBER" });
    await row.getByRole("button", { name: "Print Label", exact: true }).click();
    const label = page.getByRole("dialog", { name: "Print Label", exact: true });
    await label.getByLabel("QR website address").fill("https://stock.example.test"); await page.waitForTimeout(800);
    console.log("LABEL DIALOG:\n" + (await label.innerText()).slice(0, 800));
    const frame = label.frameLocator("iframe");
    console.log("LABEL FRAME:\n" + (await frame.locator("body").innerText().catch((e) => "no frame: " + e.message.slice(0, 100))));
    await page.screenshot({ path: H + "/shots/parts-label-long.png", fullPage: true });
  } catch (e) { console.log("FAIL", e.message.split("\n").slice(0, 5).join(" | ")); await page.screenshot({ path: H + "/shots/parts-fail.png", fullPage: true }); }
  console.log("errors", errors);
  await browser.close();
})();
