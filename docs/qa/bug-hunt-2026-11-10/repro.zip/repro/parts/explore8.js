const { start, snapshot, seed, loc, stock, H, BASE } = require("./lib");
const alerts = async (page) => [...new Set((await page.locator('[role="alert"], [role="status"]').allInnerTexts()).filter(Boolean))].join(" || ").replace(/\n/g, " ");
(async () => {
  const { browser, page, errors } = await start();
  const d = page.getByRole("dialog").last();
  const act = async (mode, lotUuid, qty) => {
    await d.getByLabel("Inventory action").selectOption({ label: mode });
    await d.getByLabel("Stock lot / location").selectOption(lotUuid); await d.getByLabel("Quantity", { exact: true }).fill(String(qty));
    await d.locator("form").filter({ has: page.getByLabel("Inventory action") }).getByRole("button").last().click(); await page.waitForTimeout(500);
    const st = (await d.getByRole("heading").first().innerText()); const s = await snapshot(page); const r = s.partsRequests[0]; const l = s.management.find((x) => x.uuid === lotUuid);
    console.log(`${mode} ${qty}: screen "${st}" | alerts: ${await alerts(page)} | stored res ${JSON.stringify(r.reservations.map((x) => x.quantity))} issues ${JSON.stringify(r.issues.map((x) => x.quantity))} lot q${l.quantity}/r${l.reservedQuantity}`);
  };
  try {
    await seed(page, [loc("store", "Main store"), stock("lotA", "store", "OIL-A", { quantity: 10, cost: 8.2 })]);
    await page.goto(BASE + "/inventory");
    await page.getByRole("row").filter({ hasText: "OIL-A" }).first().getByRole("button", { name: "Parts / repair requests" }).click();
    await d.getByRole("button", { name: "New request", exact: true }).click();
    await d.getByLabel("Quantity", { exact: true }).fill("5");
    await d.getByRole("button", { name: "Save request", exact: true }).click(); await page.waitForTimeout(600);
    await page.goto(BASE + "/parts-requests");
    await page.getByRole("button", { name: "PR-00001", exact: true }).click(); await page.waitForTimeout(400);
    await act("Reserve", "lotA", 5);
    await act("Issue reserved parts", "lotA", 2);
    await act("Release reservation", "lotA", 1);
    await act("Issue reserved parts", "lotA", 3);
    await act("Reserve", "lotA", 1);
    await d.getByRole("button", { name: "Cancel request" }).click(); await page.waitForTimeout(300);
    console.log("CANCEL UI:", (await d.innerText()).slice(-400).replace(/\n/g, " | "));
    const reason = d.getByLabel(/reason/i).last(); if (await reason.count()) await reason.fill("No longer needed");
    await d.getByRole("button", { name: /Confirm|Cancel request/ }).last().click(); await page.waitForTimeout(600);
    let s = await snapshot(page); let r = s.partsRequests[0]; let l = s.management.find((x) => x.uuid === "lotA");
    console.log("after cancel: screen", JSON.stringify(await d.getByRole("heading").first().innerText().catch(() => "closed")), "stored cancelled", r.cancelled, "res", r.reservations.length, "issues", r.issues.length, "lot", l.quantity, l.reservedQuantity, "| alerts", await alerts(page));
    await page.goto(BASE + "/parts-requests"); await page.waitForTimeout(500);
    console.log("LIST ROW:", (await page.getByRole("row").filter({ hasText: "PR-00001" }).innerText().catch(() => "not listed (filter?)")).replace(/\n/g, " | "));
    // stock history
    console.log("stock audit:", JSON.stringify(s.audit.filter((a) => a.entityUuid === "lotA").map((a) => [a.action, a.reason, JSON.parse(a.before || "{}").quantity, JSON.parse(a.after || "{}").quantity, JSON.parse(a.after || "{}").reservedQuantity])));
    // Vendors
    await page.goto(BASE + "/purchase-orders"); await page.getByRole("button", { name: "View vendors" }).or(page.getByRole("link", { name: "View vendors" })).click(); await page.waitForTimeout(600);
    console.log("VENDORS url:", page.url().replace(BASE, ""), "\n" + (await page.locator("main").innerText()).slice(0, 700));
    console.log("vendor buttons:", JSON.stringify(await page.locator("main").getByRole("button").allInnerTexts()));
  } catch (e) { console.log("FAIL", e.message.split("\n").slice(0, 5).join(" | ")); await page.screenshot({ path: H + "/shots/parts-fail.png", fullPage: true }); }
  console.log("errors", errors);
  await browser.close();
})();
