/**
 * Responsibility: Bug-hunt 2026-11-10 repro PT-11: correcting a stock item's
 *   part number must not stop a job card that already lists that lot from
 *   being saved, signed or completed.
 * Layer: Test. Vitest suite; asserts the CORRECT behaviour, so it fails while
 *   the bug exists.
 * Dependencies: src/domain/taskCards.ts, management; src/data/demo.ts and
 *   tests/fixtures/taskCards.ts (fixtures).
 *
 * Run: cp <this file> src/domain/ && npx vitest run src/domain/zz-hunt-pt-jobcard-stock.test.ts
 */
import { expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import { taskCardCommand } from "../../tests/fixtures/taskCards";
import { saveTaskCard, taskCardFieldsSchema } from "./taskCards";
import { applyManagement, type Stock } from "./management";

const now = Date.parse("2026-10-01T12:00:00Z");

it("PT-11: a job card still saves after the stock item it lists has its part number corrected", () => {
  const s = demoSnapshot();
  s.user.isAdmin = true;
  const owner = s.aircraft[0].programUuid;
  s.management = [
    {
      kind: "location",
      uuid: "shelf",
      version: 1,
      programUuid: owner,
      name: "Shelf A",
      address: "",
      contact: "",
    },
    {
      kind: "stock",
      uuid: "stock-seal",
      version: 1,
      programUuid: owner,
      partNumber: "SEAL-1",
      description: "Seal",
      alternates: "",
      category: "part",
      condition: "new",
      locationUuid: "shelf",
      quantity: 5,
      minimum: 1,
    },
  ];
  let card = saveTaskCard(s, taskCardCommand(), now);
  const fields = () => taskCardFieldsSchema.parse(card);
  card = saveTaskCard(
    s,
    {
      action: "save",
      uuid: card.uuid,
      version: card.version,
      fields: {
        ...fields(),
        partsUsed: [
          {
            uuid: crypto.randomUUID(),
            source: "stock",
            stockUuid: "stock-seal",
            locationUuid: "shelf",
            partNumber: "SEAL-1",
            description: "Seal",
            quantity: 1,
            serialLot: "LOT-1",
            removedComponent: "",
            installedComponent: "",
          },
        ],
      },
    },
    now,
  );
  const lot = s.management.find((r) => r.uuid === "stock-seal") as Stock;
  // An inventory administrator corrects a typo on the stock item.
  applyManagement(
    s,
    {
      action: "record.save",
      requestUuid: crypto.randomUUID(),
      reason: "Correct part number",
      record: { ...lot, partNumber: "SEAL-10" },
    },
    now,
  );
  // The mechanic adds a remark to the card; its parts list is unchanged.
  expect(() =>
    saveTaskCard(
      s,
      {
        action: "save",
        uuid: card.uuid,
        version: card.version,
        fields: { ...fields(), notesRemarks: "Seal replaced" },
      },
      now,
    ),
  ).not.toThrow();
});
