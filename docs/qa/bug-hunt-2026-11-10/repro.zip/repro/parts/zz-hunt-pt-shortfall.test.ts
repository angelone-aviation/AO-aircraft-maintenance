/**
 * Responsibility: Bug-hunt 2026-11-10 repro PT-8: "Create PO for parts" must
 *   suggest ordering what the inspection's own parts check reports short.
 * Layer: Test. Vitest suite; asserts the CORRECT behaviour, so it fails while
 *   the bug exists.
 * Dependencies: src/domain/purchaseOrderRules.ts, requiredParts.ts;
 *   tests/fixtures/requiredParts.ts.
 *
 * Run: cp <this file> src/domain/ && npx vitest run src/domain/zz-hunt-pt-shortfall.test.ts
 */
import { expect, it } from "vitest";
import { partsFixture } from "../../tests/fixtures/requiredParts";
import { inspectionShortfalls } from "./purchaseOrderRules";
import { partsAvailability } from "./requiredParts";
import type { Stock } from "./management";

const now = Date.parse("2026-11-10T12:00:00Z");
const required = [
  { locationUuid: "parts-location", stockUuid: "parts-stock", quantity: 2 },
];
const lot = (s: ReturnType<typeof partsFixture>) =>
  s.management!.find((r) => r.uuid === "parts-stock") as Stock;

it("PT-8: an expired lot does not hide the quantity to order", () => {
  const s = partsFixture();
  lot(s).expirationDate = "2026-01-31";
  const [shown] = partsAvailability(s, required, now);
  // The inspection's parts check: nothing usable, 2 short.
  expect(shown).toMatchObject({ available: 0, shortage: 2 });
  const [suggested] = inspectionShortfalls(s, {
    uuid: "inspection",
    requiredParts: required,
  });
  expect(suggested.quantity).toBe(shown.shortage);
});

it("PT-8: stock reserved for another request does not hide the quantity to order", () => {
  const s = partsFixture();
  lot(s).reservedQuantity = 2;
  const [shown] = partsAvailability(s, required, now);
  expect(shown).toMatchObject({ available: 0, shortage: 2 });
  const [suggested] = inspectionShortfalls(s, {
    uuid: "inspection",
    requiredParts: required,
  });
  expect(suggested.quantity).toBe(shown.shortage);
});
