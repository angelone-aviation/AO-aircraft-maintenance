const { start, snapshot, seed, loc, stock, pdfText, H, BASE } = require("./lib");
const step = async (name, f) => { try { const r = await f(); console.log("ok:", name, r ?? ""); } catch (e) { console.log("FAIL:", name, "::", e.message.split("\n").slice(0, 4).join(" | ")); throw e; } };
(async () => {
  const { browser, page, errors } = await start();
  const d = page.getByRole("dialog").last();
  const detail = page.getByRole("dialog").first();
  const head = async () => (await detail.getByRole("heading").first().innerText());
  try {
    await seed(page, [loc("store", "Main store", { address: "1 Hangar Rd" }), stock("lot1", "store", "FILTER-1", { cost: 19.99 })]);
    await page.goto(BASE + "/purchase-orders");
    await page.getByRole("button", { name: "New PO" }).click();
    await d.getByLabel("Vendor", { exact: true }).fill("Acme Aero");
    await d.getByRole("button", { name: "Quick add", exact: true }).click();
    await d.getByLabel("Shipping address — Saved address", { exact: true }).selectOption("__new");
    const a = page.getByRole("dialog", { name: "Add new shipping address", exact: true });
    await a.getByLabel("Address name", { exact: true }).fill("Main receiving");
    for (const [f, v] of Object.entries({ "Street address": "1 Hangar Rd", City: "Washington", "State / province": "DC", "ZIP / postal code": "20500", Country: "United States", "Contact name": "Receiving", Email: "r@example.com", Phone: "+1 202 555 0100" }))
      await a.getByLabel(`Shipping address — ${f}`, { exact: true }).fill(v);
    await a.getByRole("button", { name: "Save address", exact: true }).click();
    await d.getByLabel("Shipping cost").fill("7.35");
    await d.getByLabel("Part 1 inventory location").selectOption("store");
    await d.getByLabel("Part 1 stock item").selectOption("lot1");
    await d.getByLabel("Part 1 quantity", { exact: true }).fill("3");
    await d.getByRole("button", { name: "Add part", exact: true }).click();
    await d.getByLabel("Part 2 inventory location").selectOption("store");
    await d.getByLabel("Part 2 number").fill("SEAL-9");
    await d.getByLabel("Part 2 description").fill("Sealant");
    await d.getByLabel("Part 2 category").selectOption({ label: "Supply" });
    await d.getByLabel("Part 2 quantity", { exact: true }).fill("7");
    await d.getByLabel("Part 2 unit cost").fill("0.07");
    await d.getByRole("button", { name: "Add part", exact: true }).click();
    await d.getByLabel("Part 3 inventory location").selectOption("store");
    await d.getByLabel("Part 3 number").fill("STARTER-X");
    await d.getByLabel("Part 3 description").fill("Starter exchange");
    await d.getByLabel("Part 3 quantity", { exact: true }).fill("1");
    await d.getByLabel("Part 3 unit cost").fill("1005.01");
    await d.getByLabel("Part 3 is an exchange (core return due)").check();
    await d.getByLabel("Part 3 core due (days after receipt)").fill("10");
    await d.getByRole("button", { name: "Save draft PO", exact: true }).click();
    await page.getByRole("row").filter({ hasText: "Acme" }).getByRole("button").click();
    await step("issue", async () => { await detail.getByRole("button", { name: "Issue PO", exact: true }).click(); await d.getByRole("button", { name: "Finalize PO", exact: true }).click(); await page.waitForTimeout(500); return head(); });
    await step("ship partial", async () => {
      await detail.getByRole("button", { name: "Record shipment", exact: true }).click();
      await page.waitForTimeout(300); console.log("SHIP DIALOG:\n" + (await d.innerText()));
      await d.getByLabel("Carrier", { exact: true }).fill("UPS"); await d.getByLabel("Tracking number").fill("1Z");
      await d.getByLabel("FILTER-1 quantity shipped").fill("2"); await d.getByLabel("SEAL-9 quantity shipped").fill("0"); await d.getByLabel("STARTER-X quantity shipped").fill("0");
      await d.getByRole("button", { name: "Save shipment", exact: true }).click(); await page.waitForTimeout(500); return head();
    });
    await step("receive partial w/ expiry", async () => {
      await detail.getByRole("button", { name: "Receive parts", exact: true }).click(); await page.waitForTimeout(300);
      await d.getByLabel("Invoice number", { exact: true }).fill("INV-1");
      await d.getByLabel("FILTER-1 quantity received").fill("2"); await d.getByLabel("SEAL-9 quantity received").fill("4"); await d.getByLabel("STARTER-X quantity received").fill("0");
      await d.getByLabel("SEAL-9 expiration date").fill("2027-06-30");
      console.log("RECV DIALOG:\n" + (await d.innerText()));
      await d.getByRole("button", { name: "Confirm receipt into inventory", exact: true }).click(); await page.waitForTimeout(600);
      if (await d.getByRole("button", { name: "Confirm receipt into inventory", exact: true }).count()) console.log("STILL OPEN:", (await d.innerText()).slice(-400));
      return head();
    });
    await step("receive rest, expired seal + starter", async () => {
      await detail.getByRole("button", { name: "Receive parts", exact: true }).click(); await page.waitForTimeout(300);
      await d.getByLabel("Invoice number", { exact: true }).fill("INV-2");
      await d.getByLabel("FILTER-1 quantity received").fill("1"); await d.getByLabel("SEAL-9 quantity received").fill("3"); await d.getByLabel("STARTER-X quantity received").fill("1");
      await d.getByLabel("SEAL-9 expiration date").fill("2026-01-31");
      await d.getByRole("button", { name: "Confirm receipt into inventory", exact: true }).click(); await page.waitForTimeout(600);
      if (await d.getByRole("button", { name: "Confirm receipt into inventory", exact: true }).count()) console.log("STILL OPEN:", (await d.innerText()).slice(-600));
      return head();
    });
    console.log("DETAIL AFTER:\n" + (await detail.innerText()));
    await page.screenshot({ path: H + "/shots/parts-po-received.png", fullPage: true });
    const s = await snapshot(page);
    console.log("STOCK:", JSON.stringify(s.management.filter((r) => r.kind === "stock").map((r) => [r.partNumber, r.quantity, r.reservedQuantity, r.expirationDate, r.cost, r.category, r.poRef, r.invoiceNumber, r.vendor])));
    const po = s.purchaseOrders[0];
    console.log("PO:", JSON.stringify({ phase: po.phase, receipts: po.receipts.map((r) => [r.date, r.invoice, r.lines.map((l) => [l.quantity, l.expirationDate])]), cores: po.coreReturns }));
    await step("pdf issued", async () => { const dl = page.waitForEvent("download"); await detail.getByRole("button", { name: "Save PO PDF", exact: true }).click(); const f = H + "/shots/parts-po-received.pdf"; await (await dl).saveAs(f); console.log("PDF:\n" + (await pdfText(f)).join("\n--page--\n")); });
    await step("print PO", async () => {
      const popup = page.waitForEvent("popup", { timeout: 5000 }).catch(() => null);
      await detail.getByRole("button", { name: "Print PO", exact: true }).click();
      const p = await popup; console.log("popup url:", p ? p.url().slice(0, 80) : "NONE"); await page.waitForTimeout(500);
      const alert = await page.getByRole("alert").allInnerTexts().catch(() => []); console.log("alerts:", alert);
    });
    await page.goto(BASE + "/inventory"); await page.waitForTimeout(800);
    console.log("INVENTORY:\n" + (await page.locator("main").innerText()).slice(0, 2500));
    await page.screenshot({ path: H + "/shots/parts-inventory-after-po.png", fullPage: true });
  } catch (e) { await page.screenshot({ path: H + "/shots/parts-fail.png", fullPage: true }); }
  console.log("errors", errors);
  await browser.close();
})();
