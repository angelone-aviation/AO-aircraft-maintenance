/**
 * Responsibility: Bug-hunt 2026-11-10 repro PT-12: what a finished work order
 *   cost in parts must not change when the stock item's unit cost is edited
 *   later.
 * Layer: Test. Vitest suite; asserts the CORRECT behaviour, so it fails while
 *   the bug exists.
 * Dependencies: src/domain/costs.ts, management; src/data/demo.ts (seed).
 *
 * Run: cp <this file> src/domain/ && npx vitest run src/domain/zz-hunt-pt-cost-retro.test.ts
 */
import { expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import { budgetStatus } from "./costs";
import { applyManagement, type Stock } from "./management";
import type { Snapshot } from "./model";

it("PT-12: last year's parts spend does not change when a lot's unit cost is updated this year", () => {
  const s = demoSnapshot();
  s.user.isAdmin = true;
  const plane = s.aircraft[0];
  s.costs = [];
  s.workOrders = [
    { uuid: "wo", aircraftUuid: plane.uuid, dateOpened: "2025-06-01", status: "completed" },
  ] as unknown as Snapshot["workOrders"];
  s.management = [
    { kind: "location", uuid: "shelf", version: 1, programUuid: plane.programUuid, name: "Shelf", address: "", contact: "" },
    {
      kind: "stock",
      uuid: "lot",
      version: 1,
      programUuid: plane.programUuid,
      partNumber: "CYL-1",
      description: "Cylinder",
      category: "part",
      condition: "new",
      locationUuid: "shelf",
      quantity: 3,
      minimum: 0,
      alternates: "",
      cost: 1000,
    },
  ];
  s.partsRequests = [
    {
      uuid: "req",
      source: { kind: "workTask", uuid: "task", workOrderUuid: "wo" },
      lines: [{ uuid: "rl", partNumber: "CYL-1", description: "Cylinder" }],
      issues: [
        { lineUuid: "rl", stockUuid: "lot", quantity: 2, at: Date.parse("2025-06-15T15:00:00Z"), actorId: "a" },
      ],
    },
  ] as unknown as Snapshot["partsRequests"];
  const before = budgetStatus(s, plane.uuid, 2025).actualCents;
  expect(before).toBe(200000);
  // In 2026 the vendor's price goes up and the administrator updates the lot.
  const lot = s.management.find((r) => r.uuid === "lot") as Stock;
  applyManagement(s, {
    action: "record.save",
    requestUuid: crypto.randomUUID(),
    reason: "New vendor price",
    record: { ...lot, cost: 1500 },
  });
  expect(budgetStatus(s, plane.uuid, 2025).actualCents).toBe(before);
});
