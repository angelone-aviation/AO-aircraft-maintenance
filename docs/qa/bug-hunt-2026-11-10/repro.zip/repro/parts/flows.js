// Shared UI flows for the parts hunt scripts.
const { BASE } = require("./lib");
const top = (page) => page.getByRole("dialog").last();
const detail = (page) => page.getByRole("dialog").first();
async function addAddress(page, form, label, name = "Main receiving", street = "1 Hangar Rd") {
  await form.getByLabel(`${label} — Saved address`, { exact: true }).selectOption("__new");
  const a = page.getByRole("dialog", { name: "Add new shipping address", exact: true });
  await a.getByLabel("Address name", { exact: true }).fill(name);
  for (const [f, v] of Object.entries({ "Street address": street, City: "Washington", "State / province": "DC", "ZIP / postal code": "20500", Country: "United States", "Contact name": "Receiving", Email: "r@example.com", Phone: "+1 202 555 0100" }))
    await a.getByLabel(`Shipping address — ${f}`, { exact: true }).fill(v);
  await a.getByRole("button", { name: "Save address", exact: true }).click();
  await a.waitFor({ state: "hidden" });
}
// lines: [{ stock?: uuid, number?, description?, category?, quantity, unit?, exchange?: days }]
async function newPO(page, { vendor = "Acme Aero", shipping = "0", lines, location = "store" }) {
  await page.goto(BASE + "/purchase-orders");
  await page.getByRole("button", { name: "New PO" }).click();
  const d = top(page);
  await d.getByLabel("Vendor", { exact: true }).fill(vendor);
  if (await d.getByRole("button", { name: "Quick add", exact: true }).count()) await d.getByRole("button", { name: "Quick add", exact: true }).click();
  const picker = d.getByLabel("Shipping address — Saved address", { exact: true });
  if (await picker.locator("option", { hasText: "Main receiving" }).count()) await picker.selectOption({ label: await picker.locator("option", { hasText: "Main receiving" }).first().innerText() });
  else await addAddress(page, d, "Shipping address");
  await d.getByLabel("Shipping cost").fill(shipping);
  for (const [i, l] of lines.entries()) {
    const n = i + 1;
    if (i) await d.getByRole("button", { name: "Add part", exact: true }).click();
    await d.getByLabel(`Part ${n} inventory location`).selectOption(l.location ?? location);
    if (l.stock) await d.getByLabel(`Part ${n} stock item`).selectOption(l.stock);
    else {
      await d.getByLabel(`Part ${n} number`).fill(l.number);
      await d.getByLabel(`Part ${n} description`).fill(l.description ?? l.number);
      if (l.category) await d.getByLabel(`Part ${n} category`).selectOption({ label: l.category });
    }
    await d.getByLabel(`Part ${n} quantity`, { exact: true }).fill(String(l.quantity));
    if (l.unit !== undefined) await d.getByLabel(`Part ${n} unit cost`).fill(String(l.unit));
    if (l.exchange) { await d.getByLabel(`Part ${n} is an exchange (core return due)`).check(); await d.getByLabel(`Part ${n} core due (days after receipt)`).fill(String(l.exchange)); }
  }
  await d.getByRole("button", { name: "Save draft PO", exact: true }).click();
  await page.getByRole("heading", { name: "New purchase order" }).waitFor({ state: "hidden" });
}
async function openPO(page, text) {
  await page.goto(BASE + "/purchase-orders");
  await page.getByRole("row").filter({ hasText: text }).getByRole("button").first().click();
  await detail(page).getByRole("heading").first().waitFor();
}
async function issue(page) {
  await detail(page).getByRole("button", { name: "Issue PO", exact: true }).click();
  await top(page).getByRole("button", { name: "Finalize PO", exact: true }).click();
  await detail(page).getByRole("heading").first().filter({ hasText: "Issued" }).waitFor();
}
// qty: { "PART": n }, extra: { "PART": { expiry, condition } }
async function receive(page, qty, extra = {}, invoice = "INV") {
  await detail(page).getByRole("button", { name: "Receive parts", exact: true }).click();
  const d = top(page);
  await d.getByLabel("Invoice number", { exact: true }).fill(invoice);
  for (const f of await d.getByLabel(/quantity received$/).all()) await f.fill("0");
  for (const [pn, n] of Object.entries(qty)) await d.getByLabel(`${pn} quantity received`).fill(String(n));
  for (const [pn, x] of Object.entries(extra)) {
    if (x.expiry) await d.getByLabel(`${pn} expiration date`).fill(x.expiry);
    if (x.condition) await d.getByLabel(`${pn} received condition`).selectOption(x.condition);
  }
  await d.getByRole("button", { name: "Confirm receipt into inventory", exact: true }).click();
  await page.waitForTimeout(600);
  const open = await page.getByRole("button", { name: "Confirm receipt into inventory", exact: true }).count();
  return open ? "REFUSED: " + (await d.innerText()).slice(-300).replace(/\n/g, " | ") : "ok";
}
const head = async (page) => detail(page).getByRole("heading").first().innerText();
module.exports = { top, detail, addAddress, newPO, openPO, issue, receive, head };
