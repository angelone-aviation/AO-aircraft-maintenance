const { start, snapshot, seed, loc, stock, H, BASE } = require("./lib");
const notice = async (page) => [...new Set((await page.locator('[role="alert"], [role="status"]').allInnerTexts()).filter(Boolean))].join(" || ").replace(/\n/g, " ");
(async () => {
  const { browser, page, errors } = await start();
  const d = page.getByRole("dialog").last();
  const rowOf = (uuidText) => page.getByRole("row").filter({ hasText: uuidText });
  const lot = async (uuid) => { const s = await snapshot(page); const r = s.management.find((x) => x.uuid === uuid); return r && { q: r.quantity, res: r.reservedQuantity, v: r.version }; };
  const move = async (rowText, op, qty) => {
    await rowOf(rowText).first().getByRole("button", { name: "Move stock" }).click();
    await d.getByLabel("Movement type").selectOption(op);
    await d.getByLabel("Quantity (counted balance for adjustment)").fill(String(qty));
    await d.getByRole("button", { name: /^Save/ }).click(); await page.waitForTimeout(500);
    const open = await d.getByLabel("Movement type").count();
    const msg = open ? (await d.innerText()).split("\n").slice(-4).join(" | ") : "saved";
    const validity = open ? await d.getByLabel("Quantity (counted balance for adjustment)").evaluate((e) => e.validationMessage) : "";
    if (open) await d.getByRole("button", { name: /Close/ }).first().click().catch(() => page.keyboard.press("Escape"));
    return `${op} ${qty}: ${msg} ${validity} [notice: ${await notice(page)}]`;
  };
  try {
    await seed(page, [loc("store", "Main store"), loc("store2", "Remote store"),
      stock("lotA", "store", "OIL-A", { quantity: 10, reservedQuantity: 4, cost: 8.2 }),
      stock("lotX", "store", "SEAL-EXP", { quantity: 5, expirationDate: "2026-11-08" }),
      stock("lotB", "store2", "OIL-B", { quantity: 2 })],
      `s.partsRequests = [...(s.partsRequests||[])];`);
    await page.goto(BASE + "/inventory"); await page.getByRole("button", { name: "New stock item" }).waitFor();
    console.log(await move("OIL-A", "receive", 3), JSON.stringify(await lot("lotA")));
    console.log(await move("OIL-A", "issue", 2), JSON.stringify(await lot("lotA")));
    console.log(await move("OIL-A", "issue", 8), JSON.stringify(await lot("lotA")));
    console.log(await move("OIL-A", "adjust", 3), JSON.stringify(await lot("lotA")));
    console.log(await move("OIL-A", "adjust", 6), JSON.stringify(await lot("lotA")));
    console.log(await move("OIL-A", "issue", 1.5), JSON.stringify(await lot("lotA")));
    console.log(await move("OIL-A", "issue", -1), JSON.stringify(await lot("lotA")));
    console.log(await move("OIL-A", "receive", 0), JSON.stringify(await lot("lotA")));
    console.log(await move("SEAL-EXP", "issue", 1), JSON.stringify(await lot("lotX")));
    console.log(await move("SEAL-EXP", "adjust", 0), JSON.stringify(await lot("lotX")));
    // details + history
    await rowOf("OIL-A").first().getByRole("button", { name: "Details" }).click(); await page.waitForTimeout(500);
    console.log("DETAILS OIL-A:\n" + (await d.innerText()).slice(0, 3000));
    await page.screenshot({ path: H + "/shots/parts-stock-details.png", fullPage: true });
    const s = await snapshot(page);
    console.log("AUDIT:", JSON.stringify(s.audit.filter((a) => a.entityUuid === "lotA").map((a) => [a.action, a.reason, JSON.parse(a.before || "{}").quantity, JSON.parse(a.after || "{}").quantity])));
  } catch (e) { console.log("FAIL", e.message.split("\n").slice(0, 5).join(" | ")); await page.screenshot({ path: H + "/shots/parts-fail.png", fullPage: true }); }
  console.log("errors", errors);
  await browser.close();
})();
