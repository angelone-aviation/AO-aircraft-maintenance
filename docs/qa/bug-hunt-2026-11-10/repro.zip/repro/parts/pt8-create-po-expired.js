// PT-8 (browser): "Create PO for parts" on an inspection whose only lot is
// expired suggests ordering 0, while the same inspection reports a shortage.
// Usage: node pt8-create-po-expired.js   (ANGELONE_URL defaults to :4400)
const { start, seed, loc, stock, result, H, BASE } = require("./lib");
(async () => {
  const { browser, page } = await start();
  try {
    await seed(
      page,
      [loc("store", "Main store"), stock("lot-exp", "store", "FILTER-1", { quantity: 2, expirationDate: "2026-01-31" })],
      `s.inspections[0].requiredParts = [{ locationUuid: "store", stockUuid: "lot-exp", quantity: 2 }];`,
    );
    await page.goto(BASE + "/inspections");
    await page.reload();
    await page.getByRole("button", { name: "Create PO for parts", exact: true }).first().waitFor();
    const pageText = await page.locator("main").innerText();
    const shortage = (pageText.match(/[^\n]*(short|Short|expired|Expired|FILTER-1)[^\n]*/g) || []).slice(0, 8);
    console.log("Inspection screen says:", JSON.stringify(shortage));
    await page.screenshot({ path: H + "/shots/parts-pt8-inspection.png", fullPage: true });
    await page.getByRole("button", { name: "Create PO for parts", exact: true }).first().click();
    const dialog = page.getByRole("dialog").last();
    await dialog.getByLabel("Part 1 quantity", { exact: true }).waitFor();
    const suggested = await dialog.getByLabel("Part 1 quantity", { exact: true }).inputValue();
    const note = await dialog.getByText(/On hand:/).first().innerText();
    console.log(`Dialog suggests quantity ${suggested}; note: ${note}`);
    await page.screenshot({ path: H + "/shots/parts-pt8-dialog.png", fullPage: true });
    result(suggested === "0", `Create PO for parts suggests 0 for 2 required from an expired lot (${note})`);
  } catch (e) {
    console.log("ERROR", e.message.split("\n").slice(0, 4).join(" | "));
    await page.screenshot({ path: H + "/shots/parts-fail.png", fullPage: true });
    process.exitCode = 2;
  }
  await browser.close();
})();
