/**
 * Responsibility: Bug-hunt 2026-11-10 repros PT-3, PT-4, PT-5 and PT-6:
 *   issued purchase orders and parts requests that later record changes
 *   strand.
 * Layer: Test. Vitest suite; asserts the CORRECT behaviour, so each test
 *   fails while its bug exists.
 * Dependencies: src/domain/purchaseOrders.ts, management, partsRequests.ts,
 *   components.ts; src/data/demo.ts (seed).
 *
 * Run: cp <this file> src/domain/ && npx vitest run src/domain/zz-hunt-pt-orders.test.ts
 */
import { expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import { applyPOCommand, poDraftSchema } from "./purchaseOrders";
import { applyManagement, type Stock } from "./management";
import { applyRequestCommand, requestDraftSchema } from "./partsRequests";
import { componentSchema } from "./components";

const rq = () => crypto.randomUUID();
const now = Date.parse("2026-10-15T12:00:00Z");

function program() {
  const s = demoSnapshot();
  s.user.isAdmin = true;
  applyManagement(
    s,
    {
      action: "record.save",
      requestUuid: rq(),
      reason: "Opening location",
      record: {
        uuid: "store",
        version: 0,
        kind: "location",
        name: "Store",
        address: "",
        contact: "",
      },
    },
    now,
  );
  return s;
}

const draft = (line: object, extra: object = {}) =>
  poDraftSchema.parse({
    uuid: rq(),
    version: 0,
    vendor: "Vendor A",
    vendorContact: "",
    shipTo: "Main hangar",
    expectedDate: "",
    currency: "USD",
    shippingCents: 0,
    notes: "",
    lines: [
      {
        uuid: "line",
        locationUuid: "store",
        partNumber: "FILTER",
        description: "Filter",
        quantity: 2,
        unitCents: 1999,
        kind: "part",
        ...line,
      },
    ],
    ...extra,
  });

it("PT-3: correcting a stock item's part number does not strand a shipped purchase order", () => {
  const s = program();
  applyManagement(
    s,
    {
      action: "record.save",
      requestUuid: rq(),
      reason: "Opening stock",
      record: {
        uuid: "lot",
        version: 0,
        kind: "stock",
        partNumber: "FILTER",
        description: "Filter",
        category: "part",
        condition: "new",
        locationUuid: "store",
        quantity: 1,
        minimum: 0,
        alternates: "",
      },
    },
    now,
  );
  const d = draft({ stockUuid: "lot" });
  applyPOCommand(s, { kind: "save", requestUuid: rq(), drafts: [d] }, now);
  applyPOCommand(
    s,
    { kind: "issue", requestUuid: rq(), uuid: d.uuid, version: 1, reason: "" },
    now,
  );
  applyPOCommand(
    s,
    {
      kind: "ship",
      requestUuid: rq(),
      uuid: d.uuid,
      version: 2,
      date: "2026-10-15",
      carrier: "UPS",
      tracking: "1Z",
      lines: [{ lineUuid: "line", quantity: 2 }],
    },
    now,
  );
  const lot = s.management!.find((r) => r.uuid === "lot") as Stock;
  let editRefused = false;
  try {
    applyManagement(
      s,
      {
        action: "record.save",
        requestUuid: rq(),
        reason: "Correct part number",
        record: { ...lot, partNumber: "FILTER-48110" },
      },
      now,
    );
  } catch {
    editRefused = true;
  }
  if (editRefused) return;
  // The edit was accepted, so the delivery must still be receivable.
  expect(() =>
    applyPOCommand(
      s,
      {
        kind: "receive",
        requestUuid: rq(),
        uuid: d.uuid,
        version: 3,
        date: "2026-10-15",
        invoice: "INV",
        notes: "",
        lines: [{ lineUuid: "line", quantity: 2, condition: "new", serials: [] }],
      },
      now,
    ),
  ).not.toThrow();
});

it("PT-4: one repair order whose component was edited does not block every other purchase order", () => {
  const s = program();
  applyManagement(
    s,
    {
      action: "record.save",
      requestUuid: rq(),
      reason: "Stock in",
      record: componentSchema.parse({
        uuid: "alt",
        version: 0,
        kind: "component",
        aircraftUuid: "",
        componentType: "Appliance",
        partNumber: "ALT-1",
        serial: "S1",
        manufacturer: "",
        model: "",
        notes: "",
        trackTime: true,
        trackCycles: false,
        trackCalendar: false,
        installed: false,
        locationUuid: "store",
        installedSeconds: 0,
        installedCycles: 0,
        timeSinceNew: 0,
        timeSinceOverhaul: null,
        timeSinceRepair: null,
        cyclesSinceNew: 0,
        serviceDaysBase: 0,
      }),
    },
    now,
  );
  applyRequestCommand(
    s,
    {
      kind: "save",
      requestUuid: rq(),
      draft: requestDraftSchema.parse({
        uuid: "repair",
        version: 0,
        source: { kind: "component", uuid: "alt" },
        mode: "repair",
        date: "2026-10-15",
        engineer: "E",
        priority: "P2 Routine",
        requiredBy: "",
        currency: "USD",
        vendor: "Vendor A",
        shipTo: "Main hangar",
        lines: [
          {
            uuid: "rl",
            partNumber: "ALT-1",
            description: "Alternator",
            quantity: 1,
            componentUuid: "alt",
            service: "repair",
            defect: "Low output",
            workRequested: "Repair",
          },
        ],
      }),
    },
    now,
  );
  const repair = draft({
    partNumber: "ALT-1",
    description: "Alternator",
    quantity: 1,
    kind: "component",
    repairComponentUuid: "alt",
    repairWork: "repair",
    requestAllocations: [{ requestUuid: "repair", lineUuid: "rl", quantity: 1 }],
  });
  applyPOCommand(s, { kind: "save", requestUuid: rq(), drafts: [repair] }, now);
  const alt = s.management!.find((r) => r.uuid === "alt")!;
  let editRefused = false;
  try {
    applyManagement(
      s,
      {
        action: "record.save",
        requestUuid: rq(),
        reason: "Correct part number",
        record: { ...alt, partNumber: "ALT-1A" } as typeof alt,
      },
      now,
    );
  } catch {
    editRefused = true;
  }
  if (editRefused) return;
  // An unrelated order for filters must still save.
  expect(() =>
    applyPOCommand(s, { kind: "save", requestUuid: rq(), drafts: [draft({})] }, now),
  ).not.toThrow();
});

it("PT-5: a request whose only purchase order was cancelled can be re-sourced from another vendor", () => {
  const s = program();
  const r = requestDraftSchema.parse({
    uuid: "req",
    version: 0,
    source: { kind: "stock", uuid: "" },
    mode: "parts",
    date: "2026-10-15",
    engineer: "E",
    priority: "P3 Stock",
    requiredBy: "",
    currency: "USD",
    vendor: "Vendor A",
    shipTo: "Main hangar",
    lines: [{ uuid: "rl", partNumber: "FILTER", description: "Filter", quantity: 2 }],
  });
  applyRequestCommand(s, { kind: "save", requestUuid: rq(), draft: r }, now);
  const allocated = {
    requestAllocations: [{ requestUuid: "req", lineUuid: "rl", quantity: 2 }],
  };
  const first = draft(allocated);
  applyPOCommand(s, { kind: "save", requestUuid: rq(), drafts: [first] }, now);
  applyPOCommand(
    s,
    { kind: "issue", requestUuid: rq(), uuid: first.uuid, version: 1, reason: "" },
    now,
  );
  applyPOCommand(
    s,
    {
      kind: "cancel",
      requestUuid: rq(),
      uuid: first.uuid,
      version: 2,
      reason: "Vendor A cannot supply",
    },
    now,
  );
  const version = s.partsRequests!.find((x) => x.uuid === "req")!.version;
  // Nothing is reserved, issued or on order any more, so the buyer can either
  // change the request's vendor or order it from Vendor B.
  const outcomes = [
    () =>
      applyRequestCommand(
        structuredClone(s),
        { kind: "save", requestUuid: rq(), draft: { ...r, version, vendor: "Vendor B" } },
        now,
      ),
    () =>
      applyPOCommand(
        structuredClone(s),
        {
          kind: "save",
          requestUuid: rq(),
          drafts: [draft(allocated, { vendor: "Vendor B" })],
        },
        now,
      ),
  ].map((f) => {
    try {
      f();
      return "accepted";
    } catch (e) {
      return (e as Error).message;
    }
  });
  expect(outcomes).toContain("accepted");
});

it("PT-6: a receipt cannot be dated before the order existed", () => {
  const s = program();
  const d = draft({});
  applyPOCommand(s, { kind: "save", requestUuid: rq(), drafts: [d] }, now);
  applyPOCommand(
    s,
    { kind: "issue", requestUuid: rq(), uuid: d.uuid, version: 1, reason: "" },
    now,
  );
  expect(() =>
    applyPOCommand(
      s,
      {
        kind: "receive",
        requestUuid: rq(),
        uuid: d.uuid,
        version: 2,
        date: "1999-01-01",
        invoice: "INV",
        notes: "",
        lines: [{ lineUuid: "line", quantity: 2, condition: "new", serials: [] }],
      },
      now,
    ),
  ).toThrow();
});
