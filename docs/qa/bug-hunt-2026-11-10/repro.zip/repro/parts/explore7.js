const { start, snapshot, seed, loc, stock, H, BASE } = require("./lib");
const alerts = async (page) => [...new Set((await page.locator('[role="alert"], [role="status"]').allInnerTexts()).filter(Boolean))].join(" || ").replace(/\n/g, " ");
(async () => {
  const { browser, page, errors } = await start();
  const d = page.getByRole("dialog").last();
  try {
    await seed(page, [loc("store", "Main store"), stock("lotA", "store", "OIL-A", { quantity: 10, cost: 8.2 }), stock("lotX", "store", "OIL-A", { quantity: 5, expirationDate: "2026-11-08" })]);
    // A. request from stock row
    await page.goto(BASE + "/inventory");
    await page.getByRole("row").filter({ hasText: "OIL-A" }).first().getByRole("button", { name: "Parts / repair requests" }).click();
    await d.getByRole("button", { name: "New request", exact: true }).click(); await page.waitForTimeout(400);
    console.log("REQ FORM labels:", JSON.stringify((await d.locator("label").allInnerTexts()).map((l) => l.split("\n")[0]).slice(0, 40)));
    console.log("prefill PN:", await d.getByLabel("Part number", { exact: true }).inputValue(), "qty:", await d.getByLabel("Quantity", { exact: true }).inputValue());
    await d.getByLabel("Quantity", { exact: true }).fill("12");
    await d.getByRole("button", { name: "Save request", exact: true }).click(); await page.waitForTimeout(700);
    console.log("after save alerts:", await alerts(page));
    if (await d.getByRole("button", { name: "Save request", exact: true }).count()) { console.log("FORM STILL OPEN:", (await d.innerText()).slice(-500)); }
    await page.goto(BASE + "/parts-requests"); await page.waitForTimeout(600);
    console.log("REQUESTS PAGE:\n" + (await page.locator("main").innerText()).slice(0, 1200));
    await page.getByRole("button", { name: "PR-00001", exact: true }).click(); await page.waitForTimeout(500);
    console.log("REQUEST DETAIL:\n" + (await d.innerText()).slice(0, 2200));
    const lots = d.getByLabel("Stock lot / location");
    console.log("lot options:", JSON.stringify(await lots.locator("option").evaluateAll((os) => os.map((o) => [o.value, o.textContent, o.disabled]))));
    await lots.selectOption("lotA"); await d.getByLabel("Quantity", { exact: true }).fill("11");
    await d.getByRole("button", { name: "Reserve stock", exact: true }).click(); await page.waitForTimeout(500);
    console.log("reserve 11 of 10:", await alerts(page), "| validity:", await d.getByLabel("Quantity", { exact: true }).evaluate((e) => e.validationMessage));
    await d.getByLabel("Quantity", { exact: true }).fill("4");
    await d.getByRole("button", { name: "Reserve stock", exact: true }).click(); await page.waitForTimeout(500);
    console.log("reserve 4:", await alerts(page));
    console.log("DETAIL AFTER RESERVE:\n" + (await d.innerText()).slice(0, 1500));
    await page.screenshot({ path: H + "/shots/parts-request-detail.png", fullPage: true });
    let s = await snapshot(page); let r = s.partsRequests[0];
    console.log("stored:", JSON.stringify({ res: r.reservations, cancelled: r.cancelled, src: r.source, label: r.sourceLabel, lotA: s.management.find((x) => x.uuid === "lotA").reservedQuantity }));
    console.log("buttons:", JSON.stringify(await d.getByRole("button").allInnerTexts()));
  } catch (e) { console.log("FAIL", e.message.split("\n").slice(0, 5).join(" | ")); await page.screenshot({ path: H + "/shots/parts-fail.png", fullPage: true }); }
  console.log("errors", errors);
  await browser.close();
})();
