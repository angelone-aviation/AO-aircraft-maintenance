const { start, snapshot, seed, loc, stock, H, BASE } = require("./lib");
const alerts = async (page) => [...new Set((await page.locator('[role="alert"], [role="status"]').allInnerTexts()).filter(Boolean))].join(" || ").replace(/\n/g, " ");
(async () => {
  const { browser, page, errors } = await start();
  const d = page.locator("body");
  try {
    await page.goto(BASE + "/vendors"); await page.waitForTimeout(700);
    console.log("VENDORS:\n" + (await page.locator("main").innerText()).slice(0, 500));
    const add = async (name, website) => {
      await page.getByRole("button", { name: /Add vendor|New vendor/ }).first().click(); await page.waitForTimeout(300);
      if (name === "__dump") { console.log("VENDOR FORM labels:", JSON.stringify((await page.locator("label").allInnerTexts()).map((l) => l.split("\n")[0]))); name = "Acme Aero"; }
      await d.getByLabel(/name/i).first().fill(name);
      if (website !== undefined) await d.getByLabel(/Website/).fill(website);
      await d.getByRole("button", { name: /^Save/ }).click(); await page.waitForTimeout(500);
      const open = await page.getByRole("button", { name: /^Save/ }).count();
      const v = open && website !== undefined ? await d.getByLabel(/Website/).evaluate((e) => e.validationMessage) : "";
      console.log(`add ${JSON.stringify(name)} ${website ?? ""}: ${open ? "REFUSED" : "saved"} | alerts: ${await alerts(page)} | ${v}`);
      if (open) { await page.goto(BASE + "/vendors"); await page.waitForTimeout(400); }
    };
    await add("__dump");
    await add("acme aero");
    await add("  ACME AERO  ");
    await add("Acme  Aero");
    await add("Js Vendor", "javascript:alert(1)");
    await add("Ftp Vendor", "ftp://example.com");
    await add("V".repeat(250));
    const s = await snapshot(page);
    console.log("stored vendors:", JSON.stringify(s.management.filter((r) => r.kind === "vendor").map((r) => [r.name.slice(0, 30), r.name.length, r.website])));
    await page.goto(BASE + "/settings"); await page.waitForTimeout(700);
    const text = await page.locator("main").innerText();
    const i = text.indexOf("Aircraft Spruce"); console.log("SETTINGS SPRUCE:\n" + (i < 0 ? "no Spruce text; headings: " + JSON.stringify(await page.getByRole("heading").allInnerTexts()) : text.slice(Math.max(0, i - 100), i + 900)));
    await page.goto(BASE + "/costs"); await page.waitForTimeout(700);
    console.log("COSTS:\n" + (await page.locator("main").innerText()).slice(0, 900));
  } catch (e) { console.log("FAIL", e.message.split("\n").slice(0, 5).join(" | ")); await page.screenshot({ path: H + "/shots/parts-fail.png", fullPage: true }); }
  console.log("errors", errors);
  await browser.close();
})();
