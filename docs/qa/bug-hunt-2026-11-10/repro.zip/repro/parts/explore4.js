const { start, snapshot, seed, loc, stock, pdfText, H, BASE } = require("./lib");
const F = require("./flows");
(async () => {
  const { browser, page, errors } = await start();
  try {
    await seed(page, [loc("store", "Main store", { address: "1 Hangar Rd" }), stock("lot1", "store", "FILTER-1", { cost: 19.99 })]);
    await F.newPO(page, { shipping: "7.35", lines: [{ stock: "lot1", quantity: 3 }, { number: "STARTER-X", quantity: 2, unit: "1005.01", exchange: 10 }] });
    await F.openPO(page, "Acme"); await F.issue(page);
    console.log("recv1:", await F.receive(page, { "FILTER-1": 1, "STARTER-X": 1 }, {}, "INV-1"), await F.head(page));
    // fully received PO buttons
    const d = F.top(page), detail = F.detail(page);
    // Core returns
    await page.goto(BASE + "/purchase-orders"); await page.waitForTimeout(500);
    const main = await page.locator("main").innerText();
    console.log("PO PAGE:\n" + main.slice(0, 1800));
    await page.screenshot({ path: H + "/shots/parts-po-list-core.png", fullPage: true });
    const coreBtn = page.getByRole("button", { name: /core/i });
    console.log("core buttons:", await coreBtn.allInnerTexts());
  } catch (e) { console.log("FAIL", e.message.split("\n").slice(0, 5).join(" | ")); await page.screenshot({ path: H + "/shots/parts-fail.png", fullPage: true }); }
  console.log("errors", errors);
  await browser.close();
})();
