// Bug-hunt 2026-11-10, parts: browser helper (enter the demo, read and patch
// the IndexedDB snapshot). Approach copied from the 3 Nov hunt's repro/inv/lib.js.
const { chromium } = require("playwright");
const BASE = process.env.ANGELONE_URL || "http://127.0.0.1:4400";
const H = "hunt";
async function start(opts = {}) {
  let browser;
  try { browser = await chromium.launch(); }
  catch { browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || "/opt/pw-browsers/chromium" }); }
  const context = await browser.newContext({ viewport: { width: 1400, height: 1000 }, acceptDownloads: true, ...opts });
  await context.addInitScript(() => sessionStorage.setItem("angel-one-demo", "true"));
  const page = await context.newPage();
  page.setDefaultTimeout(10000);
  const errors = [];
  page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
  await page.goto(BASE + "/");
  await page.getByRole("heading", { name: "Your fleet, at a glance." }).waitFor();
  return { browser, context, page, errors };
}
async function snapshot(page) {
  return page.evaluate(() => new Promise((resolve, reject) => {
    const req = indexedDB.open("angel-one-v1");
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      const db = req.result;
      const all = db.transaction("snapshots", "readonly").objectStore("snapshots").getAll();
      all.onsuccess = () => { db.close(); resolve(all.result[0]); };
    };
  }));
}
async function mutate(page, fnSrc, arg) {
  await page.evaluate(({ fnSrc, arg }) => new Promise((resolve, reject) => {
    const fn = new Function("s", "arg", fnSrc);
    const req = indexedDB.open("angel-one-v1");
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      const db = req.result, tx = db.transaction("snapshots", "readwrite"), cursor = tx.objectStore("snapshots").openCursor();
      cursor.onsuccess = () => { const e = cursor.result; if (!e) return; const s = e.value; fn(s, arg); e.update(s); e.continue(); };
      tx.oncomplete = () => { db.close(); resolve(); };
      tx.onerror = () => reject(tx.error);
    };
  }), { fnSrc, arg });
}
const loc = (uuid, name, extra = {}) => ({ kind: "location", uuid, programUuid: "demo-program", version: 1, name, address: "", contact: "", ...extra });
const stock = (uuid, locationUuid, partNumber, extra = {}) => ({ kind: "stock", uuid, programUuid: "demo-program", version: 1, locationUuid, partNumber, description: partNumber + " desc", quantity: 5, minimum: 0, alternates: "", category: "part", condition: "new", ...extra });
async function seed(page, records, extraFn = "") {
  await mutate(page, `s.management = [...(s.management||[]), ...arg.records]; delete s.partsInventory; ${extraFn}`, { records });
  await page.reload();
}
async function pdfText(file) {
  const { getDocument } = await import("node_modules/pdfjs-dist/legacy/build/pdf.mjs");
  const data = new Uint8Array(require("fs").readFileSync(file));
  const doc = await getDocument({ data, useSystemFonts: true }).promise;
  const pages = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const c = await (await doc.getPage(i)).getTextContent();
    let out = "", y = null;
    for (const it of c.items) { if (y !== null && Math.abs(it.transform[5] - y) > 1) out += "\n"; out += it.str; y = it.transform[5]; }
    pages.push(out);
  }
  return pages;
}
function result(bug, msg) {
  if (bug) { console.log("REPRODUCED: " + msg); process.exitCode = 1; }
  else { console.log("NOT REPRODUCED"); process.exitCode = 0; }
}
module.exports = { start, snapshot, mutate, seed, loc, stock, pdfText, result, BASE, H };
