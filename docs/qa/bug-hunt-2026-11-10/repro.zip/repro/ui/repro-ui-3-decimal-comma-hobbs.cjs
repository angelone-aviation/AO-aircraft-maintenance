// UI-3: typing a decimal comma ("2342,5") in Ending Hobbs silently becomes
// 23425 and the flight form saves a 21,083.8-hour flight without a warning or
// a review hold; the aircraft total jumps and the aircraft is grounded.
const { start, go, result } = require("./lib.cjs");
(async () => {
  const { browser, page } = await start({ phone: true, extra: { locale: "en-US" } });
  await go(page, "/flights");
  await page.getByRole("button", { name: "Log a completed flight" }).click();
  const dialog = page.getByRole("dialog");
  const hobbs = dialog.getByLabel(/ENDING HOBBS/i);
  await hobbs.pressSequentially("2342,5");
  const typed = await hobbs.inputValue();
  await dialog.getByRole("button", { name: "Save flight" }).click();
  await page.waitForTimeout(1200);
  const closed = !(await dialog.isVisible());
  await go(page, "/");
  const card = await page.locator("main").innerText();
  await browser.close();
  const accepted = closed && /23,425\.0\s*h/.test(card);
  result(
    accepted,
    `"2342,5" was read as ${typed}; the flight was accepted with no warning and N206MA now shows total 23,425.0 h` +
      (/Grounded/.test(card) ? " and is Grounded (100-hour inspection overdue)" : ""),
  );
})();
