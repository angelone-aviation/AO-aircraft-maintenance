// Helper for the ui repro scripts: opens the demo at the shared URL.
const { chromium, devices } = require("playwright");
const BASE = process.env.ANGELONE_URL || "http://127.0.0.1:4400";
async function launch() {
  try {
    return await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  } catch {
    return chromium.launch({ executablePath: "/opt/pw-browsers/chromium" });
  }
}
async function start({ phone = false, viewport = { width: 1440, height: 900 }, extra = {} } = {}) {
  const browser = await launch();
  const opts = phone ? { ...devices["iPhone 13"], deviceScaleFactor: 1 } : { viewport };
  delete opts.defaultBrowserType;
  const context = await browser.newContext({ ...opts, ...extra });
  await context.addInitScript(() => sessionStorage.setItem("angel-one-demo", "true"));
  const page = await context.newPage();
  page.setDefaultTimeout(15000);
  await go(page, "/");
  return { browser, context, page };
}
async function go(page, route) {
  await page.goto(BASE + route);
  await page.locator("main").first().waitFor();
  await page
    .waitForFunction(() => !document.body.innerText.includes("Opening page…"), null, { timeout: 15000 })
    .catch(() => {});
  await page.waitForTimeout(400);
}
function result(bug, msg) {
  if (bug) {
    console.log("REPRODUCED: " + msg);
    process.exitCode = 1;
  } else {
    console.log("NOT REPRODUCED");
    process.exitCode = 0;
  }
}
module.exports = { BASE, start, go, result };
