// UI-2: the Inventory location select in New parts / repair request has no
// accessible name (its <label> points at an id the select never receives).
const { start, go, result } = require("./lib.cjs");
(async () => {
  const { browser, page } = await start();
  await go(page, "/parts-requests");
  await page.getByRole("button", { name: "New request", exact: true }).click();
  const dialog = page.getByRole("dialog");
  await dialog.waitFor();
  const bad = await dialog.evaluate((d) => {
    const label = [...d.querySelectorAll("label")].find((l) => l.textContent.trim() === "Inventory location");
    if (!label) return "label not found";
    const select = label.parentElement.querySelector("select");
    const named = select && (select.labels.length > 0 || select.getAttribute("aria-label") || select.getAttribute("aria-labelledby"));
    return named ? "" : `label for="${label.htmlFor}" but the select has id="${select ? select.id : "?"}" and no accessible name`;
  });
  const byLabel = await dialog.getByLabel("Inventory location", { exact: true }).count();
  await browser.close();
  result(Boolean(bad) || byLabel === 0, bad || "no control is labelled Inventory location");
})();
