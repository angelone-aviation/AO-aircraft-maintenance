// UI-5: user-facing text says "reminder" / "notification" where the glossary
// requires "alert", and the board view writes "1 open discrepancies".
const { start, go, result } = require("./lib.cjs");
(async () => {
  const { browser, page } = await start();
  const hits = [];
  await go(page, "/settings");
  const settings = await page.locator("main").innerText();
  const m = settings.match(/[^.\n]*\breminders?\b[^.\n]*/i);
  if (m) hits.push(`Settings: "${m[0].trim()}"`);
  await go(page, "/airworthiness");
  await page.getByText("FAA connection and renewal settings").click();
  await page.waitForTimeout(400);
  const aw = await page.locator("main").innerText();
  const m2 = aw.match(/[^.\n]*\breminders?\b[^.\n]*/i);
  if (m2) hits.push(`Airworthiness: "${m2[0].trim()}"`);
  // any saved flight raises the workspace notice with its dismiss button
  await go(page, "/flights");
  await page.getByRole("button", { name: "Log a completed flight" }).click();
  const dialog = page.getByRole("dialog");
  await dialog.getByLabel(/ENDING HOBBS/i).fill("2342.4");
  await dialog.getByRole("button", { name: "Save flight" }).click();
  await dialog.waitFor({ state: "hidden" });
  if (await page.getByRole("button", { name: "Dismiss notification" }).count()) hits.push('notice close button is named "Dismiss notification"');
  await go(page, "/board");
  const board = await page.locator("main").innerText();
  if (/\b1 open discrepancies\b/.test(board)) hits.push('Board view: "1 open discrepancies"');
  await browser.close();
  result(hits.length > 0, hits.join("; "));
})();
