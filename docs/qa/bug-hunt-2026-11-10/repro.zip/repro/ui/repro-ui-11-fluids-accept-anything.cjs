// UI-11: fuel and oil fields (step="any") store 2.342,5 as 2.3425, 1e5 as
// 100000 gal and 0,5 qt as 5 qt, with no plausibility check.
const { start, go, result } = require("./lib.cjs");
const { snap } = require("./snap.cjs");
(async () => {
  const { browser, page } = await start({ extra: { locale: "en-US" } });
  await go(page, "/flights");
  await page.getByRole("button", { name: "Log a completed flight" }).click();
  const d = page.getByRole("dialog");
  await d.getByLabel(/ENDING HOBBS/i).fill("2342.4");
  const type = async (label, text) => {
    const f = d.getByLabel(label, { exact: true });
    await f.fill("");
    await f.pressSequentially(text);
  };
  await type("Fuel starting level (US gal)", "2.342,5");
  await type("Fuel quantity added (US gal)", "1e5");
  await type("Fuel shutdown level (US gal)", "45,5");
  await type("Engine oil starting level (US qt)", "7,5");
  await type("Engine oil quantity added (US qt)", "0,5");
  await d.getByRole("button", { name: "Save flight" }).click();
  await page.waitForTimeout(1200);
  const s = await snap(page, ["flights"]);
  const f = s.flights[0] || {};
  await browser.close();
  const bad = f.status === "accepted" && f.fuel && f.fuel.added === 100000;
  result(bad, `accepted flight stored fuel ${JSON.stringify(f.fuel)} and oil ${JSON.stringify(f.oil)}`);
})();
