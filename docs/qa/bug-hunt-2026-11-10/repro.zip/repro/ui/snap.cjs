// Reads keys of the demo snapshot from IndexedDB (no eval: the page CSP blocks it).
async function snap(page, keys) {
  return page.evaluate(
    (keys) =>
      new Promise((res) => {
        const rq = indexedDB.open("angel-one-v1");
        rq.onerror = () => res({});
        rq.onsuccess = () => {
          const g = rq.result.transaction("snapshots").objectStore("snapshots").get("demo");
          g.onerror = () => res({});
          g.onsuccess = () => {
            const o = {};
            for (const k of keys) o[k] = g.result[k];
            res(JSON.parse(JSON.stringify(o)));
          };
        };
      }),
    keys,
  );
}
module.exports = { snap };
