// UI-10: money fields strip every comma, so 45,50 is saved as $4,550.00.
const { start, go, result } = require("./lib.cjs");
const { snap } = require("./snap.cjs");
(async () => {
  const { browser, page } = await start();
  await go(page, "/settings");
  const rate = page.getByLabel("Rate per hour (USD)");
  await rate.fill("45,50");
  await rate.press("Enter");
  await page.waitForTimeout(900);
  const s = await snap(page, ["costs"]);
  const cents = ((s.costs || []).find((c) => c.kind === "settings") || {}).laborRateCents;
  await browser.close();
  result(cents === 455000, `labor rate typed 45,50 was stored as ${cents} cents ($${(cents / 100).toFixed(2)} per hour)`);
})();
