// UI-13: after a refused save the error message is rendered under the sticky
// Save footer (or below the visible part of the form), is not scrolled into
// view, and keyboard focus drops to <body>.
const { start, go, result } = require("./lib.cjs");
async function measure(dialog) {
  return dialog.evaluate((el) => {
    const a = [...el.querySelectorAll("[role=alert]")].pop();
    if (!a) return { none: true };
    const r = a.getBoundingClientRect();
    const y = Math.min(innerHeight - 1, Math.max(0, r.top + r.height / 2));
    const top = document.elementFromPoint(r.left + 20, y);
    return {
      text: a.innerText.trim(),
      readable: r.top >= 0 && r.bottom <= innerHeight && a.contains(top),
      coveredBy: top && !a.contains(top) ? top.className : "",
      focus: document.activeElement.tagName,
    };
  });
}
(async () => {
  const bad = [];
  for (const phone of [true, false]) {
    const { browser, page } = await start({ phone });
    const d = page.getByRole("dialog").last();
    // 1. duplicate registration in Add aircraft
    await go(page, "/aircraft");
    await page.getByRole("button", { name: "Add aircraft", exact: true }).click();
    await d.getByLabel(/^Registration/).fill("N206MA");
    await d.getByLabel(/^Make/).first().fill("Cessna");
    await page.keyboard.press("Tab");
    await d.getByLabel(/^Model/).first().fill("172");
    await page.keyboard.press("Tab");
    await d.getByLabel("Current Hobbs (hours)").fill("100");
    await d.getByLabel("Current tach (hours)").fill("100");
    await d.getByLabel("Current landings").fill("5");
    await d.getByRole("button", { name: /Add aircraft/ }).last().click();
    await page.waitForTimeout(900);
    const m = await measure(d);
    if (!m.none && (!m.readable || m.focus === "BODY"))
      bad.push(`${phone ? "phone" : "desktop"} Add aircraft: "${m.text}" readable=${m.readable}${m.coveredBy ? " (covered by ." + m.coveredBy + ")" : ""}, focus on ${m.focus}`);
    await browser.close();
  }
  result(bad.length > 0, bad.join("; "));
})();
