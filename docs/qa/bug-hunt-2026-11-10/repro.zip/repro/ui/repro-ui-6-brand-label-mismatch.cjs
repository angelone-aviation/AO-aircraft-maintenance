// UI-6: the desktop sidebar brand link shows "AIRCRAFT OPERATIONS" but its
// accessible name is "Angel One overview" (WCAG 2.5.3 Label in Name).
const { start, result } = require("./lib.cjs");
(async () => {
  const { browser, page } = await start();
  const m = await page.evaluate(() => {
    const a = document.querySelector("aside.sidebar a.brand");
    if (!a) return null;
    const visible = [...a.querySelectorAll("small, span")].map((e) => e.innerText.trim()).filter(Boolean).join(" ");
    return { name: a.getAttribute("aria-label") || "", visible };
  });
  await browser.close();
  const bad = Boolean(m && m.visible && !m.name.toLowerCase().includes(m.visible.toLowerCase()));
  result(bad, m ? `visible text "${m.visible}" is not part of the accessible name "${m.name}"` : "");
})();
