/**
 * Responsibility: Proves whether the server guards against an implausible
 *   Hobbs jump on a submitted flight (hunt 2026-11-10, finding UI-8).
 * Layer: Test. convex-test repro; asserts the CORRECT behaviour, so it fails
 *   while the bug exists.
 * Dependencies: convex/operations.ts (submit), convex/schema.ts,
 *   src/data/demo.ts (fixture).
 *
 * Run from a checkout: copy to convex/ then
 *   npx vitest run convex/zz-hunt-ui8-server-hobbs-jump.test.ts
 */
import { convexTest } from "convex-test";
import { describe, it, expect } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { demoSnapshot } from "../src/data/demo";
import type { FlightInput } from "../src/domain/model";
const modules = import.meta.glob([
  "./**/*.ts",
  "./_generated/*.js",
  "!./**/*.test.ts",
  "!./**/*.d.ts",
]);
const DAY_MS = 86_400_000;
const HOUR_SECONDS = 3600;

async function fixture() {
  const t = convexTest(schema, modules);
  const a = demoSnapshot().aircraft[0];
  const ids = await t.run(async (ctx) => {
    await ctx.db.insert("programs", demoSnapshot().programs![0]);
    const admin = await ctx.db.insert("users", {
      name: "Admin",
      email: "admin@example.test",
      active: true,
      isAdmin: true,
      groupIds: [],
    });
    const session = await ctx.db.insert("authSessions", {
      userId: admin,
      expirationTime: Date.now() + DAY_MS,
    });
    await ctx.db.insert("aircraft", a);
    return { admin, session };
  });
  const admin = t.withIdentity({ subject: ids.admin + "|" + ids.session });
  const submit = async (hobbsOn: number) => {
    const input: FlightInput = {
      aircraftUuid: a.uuid,
      pilotId: ids.admin,
      startTime: "2026-10-03T09:00:00Z",
      hobbsOn,
      landings: 1,
      cycles: 0,
      origin: "AAA",
      destination: "BBB",
      operation: "Mission",
      flightRules: "VFR",
      remarks: "",
      discrepancy: "",
    };
    const uuid = crypto.randomUUID();
    let refused: unknown;
    try {
      await admin.mutation(api.operations.submit, {
        operation: {
          programUuid: "demo-program",
          kind: "flight",
          uuid,
          authorId: ids.admin,
          baseVersion: 0,
          input,
        },
      });
    } catch (e) {
      refused = e;
    }
    const stored = await t.run(async (ctx) => ({
      aircraft: await ctx.db
        .query("aircraft")
        .withIndex("uuid", (q) => q.eq("uuid", a.uuid))
        .unique(),
      flights: await ctx.db.query("flights").collect(),
    }));
    return { refused, ...stored };
  };
  return { a, submit };
}

describe("server plausibility guard on a flight's ending Hobbs", () => {
  it("does not apply a flight whose ending Hobbs is 10x the current reading", async () => {
    const { a, submit } = await fixture();
    // 2341.2 h -> 23412 h: a 21,070.8-hour "flight" (a missed decimal point).
    const r = await submit(a.currentHobbs * 10);
    const accepted = r.flights.filter((f) => f.status === "accepted");
    expect(accepted, "the flight was accepted into aircraft totals").toHaveLength(0);
    expect(r.aircraft!.currentHobbs).toBe(a.currentHobbs);
  });

  it("does not apply a single flight longer than 100 hours", async () => {
    const { a, submit } = await fixture();
    const r = await submit(a.currentHobbs + 100 * HOUR_SECONDS + 360);
    expect(r.aircraft!.currentHobbs).toBe(a.currentHobbs);
  });
});
