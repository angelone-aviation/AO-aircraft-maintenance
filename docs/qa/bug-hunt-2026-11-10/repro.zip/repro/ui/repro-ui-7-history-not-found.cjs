// UI-7: the Record history panel inside record dialogs shows a red
// "History not found." error (with a Load more button) for a record that
// simply has no change-log entries yet.
const { start, go, result } = require("./lib.cjs");
(async () => {
  const { browser, page } = await start();
  const hits = [];
  const cases = [
    ["/inspections", "Complete"],
    ["/inspections", "Details"],
    ["/discrepancies", "Record resolution"],
    ["/aircraft", "Edit aircraft"],
  ];
  for (const [route, button] of cases) {
    await go(page, route);
    const b = page.getByRole("button", { name: button, exact: true }).first();
    if (!(await b.isVisible().catch(() => false))) continue;
    await b.click();
    const dialog = page.getByRole("dialog");
    await dialog.waitFor();
    await page.waitForTimeout(900);
    const text = await dialog.innerText();
    if (/History not found\./.test(text))
      hits.push(`${route} > ${button}${/Load more/.test(text) ? " (with Load more)" : ""}`);
    await page.keyboard.press("Escape");
  }
  await browser.close();
  result(hits.length > 0, `"History not found." shown as an error in: ${hits.join("; ")}`);
})();
