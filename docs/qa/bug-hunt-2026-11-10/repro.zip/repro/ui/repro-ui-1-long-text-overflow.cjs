// UI-1: an unbroken 60-character inspection reference, entered through the
// inspection form, makes Alerts and the aircraft list wider than a phone and
// pushes the bottom navigation off-screen.
const { start, go, result } = require("./lib.cjs");
(async () => {
  const { browser, page } = await start({ phone: true });
  await go(page, "/inspections");
  await page.getByRole("button", { name: "Details", exact: true }).first().click();
  const dialog = page.getByRole("dialog");
  const label = "Reference";
  await dialog.getByLabel("Reference", { exact: true }).fill("W".repeat(60));
  await dialog.getByRole("button", { name: "Save inspection", exact: true }).click();
  await dialog.waitFor({ state: "hidden" });
  const wide = [];
  for (const route of ["/alerts", "/aircraft"]) {
    await go(page, route);
    const m = await page.evaluate(() => {
      const tabs = [...document.querySelectorAll("nav.tabbar a, nav.tabbar button")];
      return {
        vw: window.visualViewport ? Math.round(window.visualViewport.width) : window.innerWidth,
        sw: document.documentElement.scrollWidth,
        tabsOff: tabs.filter((t) => t.getBoundingClientRect().left >= 390).length,
        tabs: tabs.length,
      };
    });
    if (m.sw > 391) wide.push(`${route} is ${m.sw}px wide on a 390px phone, ${m.tabsOff} of ${m.tabs} bottom-navigation items off-screen`);
  }
  await browser.close();
  result(wide.length > 0, `(field "${label.trim()}") ` + wide.join("; "));
})();
