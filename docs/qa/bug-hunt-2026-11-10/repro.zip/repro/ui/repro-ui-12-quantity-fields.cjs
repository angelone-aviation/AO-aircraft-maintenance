// UI-12: purchase order quantity and cost fields cannot be emptied, keep a
// leading zero, and turn "-5" and "1e5" into 5.
const { start, go, result } = require("./lib.cjs");
(async () => {
  const { browser, page } = await start({ extra: { locale: "en-US" } });
  await go(page, "/purchase-orders");
  await page.getByRole("button", { name: "New PO", exact: true }).click();
  const d = page.getByRole("dialog");
  const qty = d.getByLabel("Part 1 quantity");
  const seen = {};
  for (const text of ["", "12", "-5", "1e5"]) {
    await qty.fill("");
    await qty.focus();
    if (text) await page.keyboard.type(text);
    seen[text] = await qty.inputValue();
  }
  await browser.close();
  result(seen[""] === "0" || seen["12"] === "012" || seen["-5"] === "05", `Part 1 quantity after typing: ${JSON.stringify(seen)}`);
})();
