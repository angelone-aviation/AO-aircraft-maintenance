// UI-4: Escape or the browser Back button closes a filled-in flight form (and
// inspection completion, work order, discrepancy forms) without asking, and
// the typed data is gone when the form is reopened.
const { start, go, result } = require("./lib.cjs");
(async () => {
  const { browser, page } = await start({ phone: true });
  let asked = 0;
  page.on("dialog", (d) => {
    asked++;
    d.dismiss();
  });
  const lost = [];
  for (const how of ["Escape", "Back"]) {
    await go(page, "/");
    await page.locator('a[href="/flights"]').first().click();
    await page.getByRole("button", { name: "Log a completed flight" }).click();
    const dialog = page.getByRole("dialog");
    await dialog.getByLabel(/ENDING HOBBS/i).fill("2342.4");
    await dialog.getByLabel("Remarks").fill("Diverted for weather; landed with 12 gal");
    if (how === "Escape") await page.keyboard.press("Escape");
    else await page.goBack();
    await page.waitForTimeout(500);
    if (asked) continue;
    if (await dialog.isVisible().catch(() => false)) continue;
    await go(page, "/flights");
    await page.getByRole("button", { name: "Log a completed flight" }).click();
    const kept = await dialog.getByLabel("Remarks").inputValue();
    if (!kept) lost.push(how);
    await page.keyboard.press("Escape");
  }
  await browser.close();
  result(lost.length > 0, `flight form closed with no question and reopened empty after: ${lost.join(", ")}`);
})();
