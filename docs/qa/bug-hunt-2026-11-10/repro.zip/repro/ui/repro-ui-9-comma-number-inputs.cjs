// UI-9: number inputs drop a typed decimal comma; the aircraft form then saves
// Current Hobbs 2341,2 as 23,412 h with no warning.
const { start, go, result } = require("./lib.cjs");
const { snap } = require("./snap.cjs");
(async () => {
  const { browser, page } = await start({ extra: { locale: "en-US" } });
  await go(page, "/aircraft");
  await page.getByRole("button", { name: "Edit aircraft", exact: true }).first().click();
  const dialog = page.getByRole("dialog");
  const hobbs = dialog.getByLabel("Current Hobbs (hours)");
  await hobbs.fill("");
  await hobbs.pressSequentially("2341,2");
  const shown = await hobbs.inputValue();
  await dialog.getByRole("button", { name: "Save aircraft" }).click();
  await page.waitForTimeout(1200);
  const closed = !(await dialog.isVisible());
  const s = await snap(page, ["aircraft"]);
  const stored = s.aircraft.find((a) => a.uuid === "demo-206").currentHobbs / 3600;
  await browser.close();
  result(closed && stored > 20000, `typed 2341,2, the field showed ${shown}, saved without a question; N206MA current Hobbs is now ${stored} h`);
})();
