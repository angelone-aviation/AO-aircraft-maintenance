/**
 * Responsibility: Repro AC-1 (hunt 2026-11-10): change-log rows about
 *   permission groups and program access are written but no reader can see
 *   them, so the weekly summary's "Users and access" family stays empty.
 * Layer: Test. convex-test; asserts the correct behaviour, so it fails today.
 * Dependencies: ./zzHuntAclWorld, convex/_generated.
 *
 * Run: cp repro/acl/zzHuntAclWorld.ts repro/acl/<this file> convex/ &&
 *   npx vitest run convex/zz-hunt-acl-1-access-audit-hidden.test.ts
 */
import { expect, it } from "vitest";
import { api } from "./_generated/api";
import { seedWorld, PROGRAM } from "./zzHuntAclWorld";

const PERIOD = { from: "2026-01-01", to: "2030-12-31" };
const ALL = ["read", "flight", "discrepancy", "resolve", "maintenance"];

async function changeAccess() {
  const w = await seedWorld();
  // A program administrator promotes an observer to program administrator
  // and creates a second administrator group.
  await w.manager.mutation(api.programUsers.updateAccess, {
    programUuid: PROGRAM,
    groupIds: [w.people.groups.managers],
    userId: w.people.observer.id,
    remove: false,
  });
  await w.manager.mutation(api.admin.saveGroup, {
    programUuid: PROGRAM,
    name: "Night crew",
    programAdmin: true,
    aircraftIds: [],
    allAircraft: true,
    permissions: ALL,
  } as never);
  return w;
}

it("shows a program's access changes in its administrator's weekly summary", async () => {
  const w = await changeAccess();
  const { summary } = await w.manager.query(api.auditHistory.summary, {
    programUuid: PROGRAM,
    ...PERIOD,
  });
  expect(summary.families.access).toBeGreaterThanOrEqual(2);
  expect(summary.notable.map((n) => n.action)).toEqual(
    expect.arrayContaining(["user.program_access_changed", "group.saved"]),
  );
});

it("shows them to a system administrator in the program's Change history", async () => {
  const w = await changeAccess();
  const { page } = await w.root.query(api.auditHistory.page, {
    programUuid: PROGRAM,
    cursor: null,
    numItems: 200,
  });
  expect(page.map((a) => a.action)).toEqual(
    expect.arrayContaining(["user.program_access_changed", "group.saved"]),
  );
});

it("shows them to a system administrator somewhere at all", async () => {
  const w = await changeAccess();
  await w.root.mutation(api.programs.select, { programUuid: "" });
  const unassigned = await w.root.query(api.auditHistory.page, {
    cursor: null,
    numItems: 200,
  });
  await w.root.mutation(api.programs.select, { programUuid: PROGRAM });
  const inProgram = await w.root.query(api.auditHistory.page, {
    programUuid: PROGRAM,
    cursor: null,
    numItems: 200,
  });
  const seen = [...unassigned.page, ...inProgram.page].map((a) => a.action);
  expect(seen).toContain("user.program_access_changed");
  expect(seen).toContain("group.saved");
});
