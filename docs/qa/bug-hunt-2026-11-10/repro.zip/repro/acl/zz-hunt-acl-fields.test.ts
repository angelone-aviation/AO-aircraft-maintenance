/**
 * Responsibility: Hunt 2026-11-10, AC-3 and AC-5: enumerates every field
 *   the board view and the owner portal pass, by filling every schema field
 *   of every record with a marker and reading what survives.
 * Layer: Test. Pure domain test; writes the field lists when HUNT_OUT is set.
 * Dependencies: src/data/demo, src/domain (programs, airworthiness,
 *   management, workOrders, costs), tests/fixtures/workOrders.
 *
 * Run: cp to src/domain/, then
 *   HUNT_OUT=<dir> npx vitest run src/domain/zz-hunt-acl-fields.test.ts
 * The last test pins the board whitelist the docs describe, so it fails
 * while free text and people still pass.
 */
import { expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import { scopedSnapshot } from "./programs";
import { adSchema } from "./airworthiness";
import { recordSchema, inspectionSchema } from "./management";
import { workOrderSchema } from "./workOrders";
import { costRecordSchema } from "./costs/records";
import type { Group, Snapshot } from "./model";

const MARK = "MARK";
type Json = Record<string, unknown>;
type Def = {
  type: string;
  innerType?: Zod;
  element?: Zod;
  options?: Zod[];
  shape?: Record<string, Zod>;
  entries?: Record<string, string>;
  values?: unknown[];
  in?: Zod;
};
type Zod = { def: Def; shape?: Record<string, Zod> };

// A value for a schema node: markers for text, small numbers, one element
// per array, every key of an object.
function fill(schema: Zod, path: string): unknown {
  const def = schema.def;
  switch (def.type) {
    case "string":
      return `${MARK}:${path}`;
    case "number":
      return 7;
    case "boolean":
      return true;
    case "enum":
      return Object.values(def.entries ?? {})[0];
    case "literal":
      return def.values?.[0];
    case "array":
      return [fill(def.element!, `${path}[]`)];
    case "object":
      return Object.fromEntries(
        Object.entries(schema.shape ?? def.shape ?? {}).map(([k, v]) => [
          k,
          fill(v, `${path}.${k}`),
        ]),
      );
    case "optional":
    case "nullable":
    case "default":
    case "nonoptional":
    case "readonly":
      return fill(def.innerType!, path);
    case "pipe":
      return fill(def.in!, path);
    case "union":
      return fill(def.options![0], path);
    default:
      return `${MARK}:${path}`;
  }
}

// Every schema field the record lacks is added; what the record already
// holds (ids, kinds, statuses the views filter on) stays.
function enrich<T extends object>(schema: unknown, record: T, name: string): T {
  const filled = fill(schema as Zod, name) as Json;
  const merge = (base: unknown, own: unknown): unknown => {
    if (Array.isArray(base))
      return Array.isArray(own) && own.length
        ? own.map((o) => merge(base[0], o))
        : base;
    if (base && typeof base === "object")
      return Object.fromEntries(
        [...new Set([...Object.keys(base), ...Object.keys((own as Json) ?? {})])].map((k) => [
          k,
          own && typeof own === "object" && k in own && (own as Json)[k] !== "" && (own as Json)[k] !== null
            ? merge((base as Json)[k], (own as Json)[k])
            : (base as Json)[k] ?? (own as Json | undefined)?.[k],
        ]),
      );
    return own ?? base;
  };
  return merge(filled, record) as T;
}

const optionOf = (kind: string) =>
  (recordSchema as unknown as { def: { options: Zod[] } }).def.options.find(
    (o) => (o.shape!.kind.def.values ?? [])[0] === kind,
  )!;

function richSnapshot(): Snapshot {
  const s = demoSnapshot();
  const [a] = s.aircraft;
  const program = s.programs![0].uuid;
  const component = enrich(optionOf("component"), {
    kind: "component", uuid: "c-1", version: 1, programUuid: program,
    aircraftUuid: a.uuid, installed: true,
  }, "component");
  const requirement = enrich(optionOf("componentRequirement"), {
    kind: "componentRequirement", uuid: "q-1", version: 1, programUuid: program,
    componentUuid: "c-1", aircraftUuid: a.uuid,
  }, "requirement");
  const ad = enrich(adSchema, {
    uuid: "ad-1", version: 1, programUuid: program, aircraftUuid: a.uuid,
    componentUuid: "", applicability: "Applicable",
  }, "ad");
  const order = enrich(workOrderSchema, {
    uuid: "wo-1", version: 1, aircraftUuid: a.uuid, status: "completed",
  }, "workOrder");
  const inspection = enrich(inspectionSchema, {
    uuid: "i-1", version: 1, aircraftUuid: a.uuid, archived: false, programUuid: program,
  }, "inspection");
  const discrepancy = {
    uuid: "d-1", aircraftUuid: a.uuid, status: "open" as const, createdAt: 1,
    description: `${MARK}:discrepancy.description`, authorId: `${MARK}:discrepancy.authorId`,
    flightUuid: `${MARK}:discrepancy.flightUuid`, grounding: true,
    resolution: `${MARK}:discrepancy.resolution`, resolvedBy: `${MARK}:discrepancy.resolvedBy`, resolvedAt: 7,
    requiredParts: [{ locationUuid: `${MARK}:discrepancy.requiredParts[].locationUuid`, stockUuid: `${MARK}:discrepancy.requiredParts[].stockUuid`, quantity: 7 }],
    partsVersion: 7,
    deferral: {
      type: "mel" as const, melItem: `${MARK}:discrepancy.deferral.melItem`, category: "C" as const, days: 7,
      placard: `${MARK}:discrepancy.deferral.placard`, deferredOn: "2026-11-01", deferredAt: 7,
      deferredBy: `${MARK}:discrepancy.deferral.deferredBy`, deferredByName: `${MARK}:discrepancy.deferral.deferredByName`,
      expiresOn: "2026-11-11",
    },
  };
  const costOption = (kind: string) =>
    (costRecordSchema as unknown as { def: { options: Zod[] } }).def.options.find(
      (o) => (o.shape!.kind.def.values ?? [])[0] === kind,
    )!;
  const cost = enrich(costOption("workOrder"), {
    kind: "workOrder", uuid: "cost-1", version: 1, programUuid: program,
    aircraftUuid: a.uuid, workOrderUuid: "wo-1",
  }, "cost");
  return {
    ...s,
    aircraft: s.aircraft.map((x) => ({
      ...x, photoUrl: `${MARK}:aircraft.photoUrl`,
    })),
    management: [component, requirement] as Snapshot["management"],
    airworthiness: [ad] as Snapshot["airworthiness"],
    workOrders: [order] as Snapshot["workOrders"],
    inspections: [inspection] as Snapshot["inspections"],
    discrepancies: [discrepancy],
    costs: [cost] as Snapshot["costs"],
  };
}

function viewOf(flags: Partial<Group>[]): Snapshot {
  const s = richSnapshot();
  const program = s.programs![0].uuid;
  const groups: Group[] = flags.map((f, i) => ({
    id: `g-${i}`, name: `G${i}`, programUuid: program, aircraftIds: f.owner ? [s.aircraft[0].uuid] : [],
    permissions: ["read"], ...f,
  }));
  const user = { ...s.user, isAdmin: false, groupIds: groups.map((g) => g.id) };
  return scopedSnapshot({
    ...s, user, groups,
    members: [user, { ...user, id: "other", name: "Other Person", email: "other@example.test" }],
  });
}

// Leaf paths with a value, by top-level collection; array indices dropped.
function passed(view: Snapshot): Record<string, string[]> {
  const out: Record<string, Set<string>> = {};
  const walk = (value: unknown, top: string, path: string) => {
    if (Array.isArray(value)) return value.forEach((v) => walk(v, top, `${path}[]`));
    if (value && typeof value === "object")
      return Object.entries(value).forEach(([k, v]) => walk(v, top, path ? `${path}.${k}` : k));
    if (value === "" || value === undefined || value === null) return;
    (out[top] ??= new Set()).add(path || "(value)");
  };
  for (const [top, value] of Object.entries(view)) walk(value, top, "");
  return Object.fromEntries(
    Object.entries(out).map(([k, v]) => [k, [...v].sort()]),
  );
}

const report: Record<string, unknown> = {};

it("lists what each reduced view passes", async () => {
  const board = passed(viewOf([{ board: true }]));
  const owner = passed(viewOf([{ owner: true }]));
  const mixed = passed(viewOf([{ board: true }, { owner: true }]));
  const observer = passed(viewOf([{}]));
  report.board = board;
  report.owner = owner;
  report.ownerPlusBoardBeyondBoth = Object.fromEntries(
    Object.entries(mixed)
      .map(([top, paths]) => [
        top,
        paths.filter((p) => !board[top]?.includes(p) && !owner[top]?.includes(p)),
      ])
      .filter(([, paths]) => (paths as string[]).length),
  );
  report.ownerPlusBoardEqualsObserver =
    JSON.stringify(mixed) === JSON.stringify(observer);
  if (process.env.HUNT_OUT) {
    const { writeFileSync } = await import("node:fs");
    writeFileSync(
      `${process.env.HUNT_OUT}/acl-reduced-view-fields.json`,
      JSON.stringify(report, null, 1),
    );
  }
  expect(Object.keys(board).length).toBeGreaterThan(5);
});

// docs/board-view.md: status inputs pass; free text, people and files do not.
const BOARD_TEXT_AND_PEOPLE = [
  /sourceNotes$/, /history\[\]\.(method|serviceBulletin|terminatedBy|mechanic|certificate|evidence|recordedBy|correctionReason)$/,
  /tasks\[\]\.description$/, /deferral\.(melItem|placard|deferredBy|deferredByName)$/,
  /notes$/i, /reason$/i, /^manualReference/, /authorId$/, /ChangedBy$/,
];

it("passes the board no free text or people on ADs, deferrals and records", () => {
  const board = passed(viewOf([{ board: true }]));
  const leaking = Object.entries(board)
    .filter(([top]) => ["airworthiness", "discrepancies", "inspections", "management", "workOrders"].includes(top))
    .flatMap(([top, paths]) =>
      paths.filter((p) => BOARD_TEXT_AND_PEOPLE.some((r) => r.test(p))).map((p) => `${top}.${p}`),
    );
  expect(leaking).toEqual([]);
});

it("gives an owner who is also a board member no more than the two views", () => {
  const board = passed(viewOf([{ board: true }]));
  const owner = passed(viewOf([{ owner: true }]));
  const mixed = passed(viewOf([{ board: true }, { owner: true }]));
  const beyond = Object.keys(mixed).filter((top) => !board[top] && !owner[top]);
  expect(beyond).toEqual([]);
});
