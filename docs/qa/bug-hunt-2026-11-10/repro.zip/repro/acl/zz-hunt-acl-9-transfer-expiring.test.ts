/**
 * Responsibility: Repro AC-9 and AC-10 (hunt 2026-11-10): an aircraft
 *   transfer leaves the aircraft's expiring dates with the source program
 *   (which can no longer edit them), while its budget moves to the
 *   destination still tagged with the source program.
 * Layer: Test. convex-test; asserts the correct behaviour, so it fails today.
 * Dependencies: ./zzHuntAclWorld, convex/_generated.
 *
 * Run: cp repro/acl/zzHuntAclWorld.ts repro/acl/<this file> convex/ &&
 *   npx vitest run convex/zz-hunt-acl-9-transfer-expiring.test.ts
 */
import { expect, it } from "vitest";
import { api } from "./_generated/api";
import { addUser, seedWorld, settle, PROGRAM } from "./zzHuntAclWorld";

const MOVED = "sample-aircraft-3";
const DEST = "destination-program";

async function transferWithExpiringDate() {
  const w = await seedWorld();
  await w.t.run(async (ctx) => {
    const { _id, _creationTime, ...program } = (await ctx.db
      .query("programs")
      .first())!;
    await ctx.db.insert("programs", { ...program, uuid: DEST, name: "Dest" });
  });
  await w.root.mutation(api.defaultGroups.initialize, { programUuid: DEST });
  const vera = await w.t.run(async (ctx) => {
    const groups = await ctx.db
      .query("groups")
      .withIndex("program", (q) => q.eq("programUuid", DEST))
      .collect();
    const managers = groups.find((g) => g.name === "Program managers")!._id;
    return addUser(ctx, "vera", [managers], { program: DEST });
  });
  const send = (payload: unknown) => ({
    programUuid: PROGRAM,
    payload: JSON.stringify(payload),
  });
  const item = {
    uuid: crypto.randomUUID(),
    programUuid: PROGRAM,
    aircraftUuid: MOVED,
    kind: "registration",
    label: "N-number registration",
    expiresOn: "2026-12-01",
    version: 0,
  };
  await w.manager.mutation(
    api.expiringItems.save,
    send({ action: "save", requestUuid: crypto.randomUUID(), item }),
  );
  await w.manager.mutation(
    api.costs.execute,
    send({
      action: "budget.set",
      requestUuid: crypto.randomUUID(),
      aircraftUuid: MOVED,
      year: 2026,
      amountCents: 123400,
    }),
  );
  await w.root.mutation(api.programs.transfer, {
    programUuid: PROGRAM,
    kind: "aircraft",
    uuid: MOVED,
    destination: DEST,
    reason: "Moved to the other program.",
  });
  return { w, dest: w.t.withIdentity(vera), item, send };
}

it("shows the moved aircraft's registration expiry to its new program", async () => {
  const { dest } = await transferWithExpiringDate();
  const view = (await dest.query(api.operations.snapshot, {}))!;
  expect(view.aircraft.map((a) => a.uuid)).toEqual([MOVED]);
  expect(view.expiringItems?.map((i) => i.label)).toEqual([
    "N-number registration",
  ]);
});

it("leaves the source program no expiring date for an aircraft it no longer holds, or lets it edit the one it keeps", async () => {
  const { w, send } = await transferWithExpiringDate();
  const view = (await w.manager.query(api.operations.snapshot, {}))!;
  const held = new Set(view.aircraft.map((a) => a.uuid));
  const stranded = (view.expiringItems ?? []).filter(
    (i) => i.aircraftUuid && !held.has(i.aircraftUuid),
  );
  if (!stranded.length) return;
  const edit = await settle(
    w.manager.mutation(
      api.expiringItems.save,
      send({
        action: "save",
        requestUuid: crypto.randomUUID(),
        item: { ...stranded[0], expiresOn: "2027-12-01" },
      }),
    ),
  );
  expect(edit).toHaveProperty("returned");
});

it("AC-10: tags the budget that moved with the aircraft with its new program", async () => {
  const { dest } = await transferWithExpiringDate();
  const view = (await dest.query(api.operations.snapshot, {}))!;
  const budgets = (view.costs ?? []).filter((c) => c.kind === "budget");
  expect(budgets.map((b) => b.programUuid)).toEqual(
    budgets.map(() => DEST),
  );
});
