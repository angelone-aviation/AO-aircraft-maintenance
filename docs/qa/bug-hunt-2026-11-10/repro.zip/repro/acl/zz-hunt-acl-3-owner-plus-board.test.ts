/**
 * Responsibility: Repro AC-3 (hunt 2026-11-10): a user holding only an
 *   aircraft-owner group and a board group gets the full read workspace,
 *   which is more than either reduced view allows.
 * Layer: Test. convex-test; asserts the correct behaviour, so it fails today.
 * Dependencies: ./zzHuntAclWorld, convex/_generated.
 *
 * Run: cp repro/acl/zzHuntAclWorld.ts repro/acl/<this file> convex/ &&
 *   npx vitest run convex/zz-hunt-acl-3-owner-plus-board.test.ts
 */
import { expect, it } from "vitest";
import { api } from "./_generated/api";
import { addUser, seedWorld, settle, PROGRAM } from "./zzHuntAclWorld";

async function ownerOnTheBoard() {
  const w = await seedWorld();
  const { owners, board } = w.people.groups;
  const who = await w.t.run((ctx) => addUser(ctx, "both", [owners, board]));
  return { w, both: w.t.withIdentity(who) };
}

it("sends an owner who sits on the board no more than the two reduced views", async () => {
  const { both } = await ownerOnTheBoard();
  const view = (await both.query(api.operations.snapshot, {}))!;
  // Neither the owner portal nor the board view carries any of these.
  expect(view.flights).toEqual([]);
  expect(view.audit).toEqual([]);
  expect(view.members.map((m) => m.name)).toEqual(["both"]);
  expect(view.taskCards ?? []).toEqual([]);
  expect(view.manuals ?? []).toEqual([]);
  expect(view.workOrderAttachments ?? []).toEqual([]);
  expect(view.workOrders?.every((o) => o.tasks.length === 0)).toBe(true);
});

it("keeps Change history closed to them, as it is to an owner and to a board member", async () => {
  const { w, both } = await ownerOnTheBoard();
  const page = { programUuid: PROGRAM, cursor: null, numItems: 5 };
  expect(await settle(w.owner.query(api.auditHistory.page, page))).toEqual({
    refused: "Aircraft owner access is read-only.",
  });
  expect(await settle(w.board.query(api.auditHistory.page, page))).toEqual({
    refused: "Board access is read-only.",
  });
  expect(await settle(both.query(api.auditHistory.page, page))).toHaveProperty(
    "refused",
  );
});
