/**
 * Responsibility: Repro AC-8 (hunt 2026-11-10): the weekly summary's refused
 *   sign-ins count is always 0 for a Flight Program administrator, because
 *   real refusal rows carry no program and are hidden from them.
 * Layer: Test. convex-test; asserts the documented behaviour, so it fails
 *   today.
 * Dependencies: ./zzHuntAclWorld, convex/_generated.
 *
 * Run: cp repro/acl/zzHuntAclWorld.ts repro/acl/<this file> convex/ &&
 *   npx vitest run convex/zz-hunt-acl-8-refused-signins.test.ts
 */
import { expect, it } from "vitest";
import { api, internal } from "./_generated/api";
import { seedWorld, PROGRAM } from "./zzHuntAclWorld";

it("counts a refused sign-in of a program member in that program's weekly summary", async () => {
  const w = await seedWorld();
  // What convex/http.ts records when Google sign-in is refused for a member.
  await w.t.mutation(internal.identities.recordRefusal, {
    provider: "google",
    providerAccountId: "g-123",
    email: "pilot@example.test",
    reason: "disabled",
    userId: w.people.pilot.id,
  });
  const { summary } = await w.manager.query(api.auditHistory.summary, {
    programUuid: PROGRAM,
    from: "2026-01-01",
    to: "2030-12-31",
  });
  expect(summary.refusedSignIns).toBe(1);
});
