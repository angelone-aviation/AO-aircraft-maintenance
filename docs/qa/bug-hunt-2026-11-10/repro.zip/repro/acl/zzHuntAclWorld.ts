/**
 * Responsibility: Shared fixture for the 2026-11-10 access-control hunt
 *   repros: the seeded sample Flight Program with one signed-in user per role.
 * Layer: Test. convex-test helper; copy next to the repro into convex/.
 * Dependencies: convex-test, convex/schema.ts, convex/sampleProgram.ts,
 *   convex/memberships.ts, convex/_generated.
 */
import { convexTest, type TestConvex } from "convex-test";
import { ConvexError } from "convex/values";
import schema from "./schema";
import { internal } from "./_generated/api";
import type { Id } from "./_generated/dataModel";
import type { MutationCtx } from "./_generated/server";
import { PROGRAM } from "./sampleProgram";
import { syncMemberships } from "./memberships";

export const modules = import.meta.glob([
  "./**/*.ts",
  "./_generated/*.js",
  "!./**/*.test.ts",
  "!./**/*.d.ts",
  "!./zzHuntAclWorld.ts",
]);
export { PROGRAM };
export const AIRCRAFT_1 = "sample-aircraft-1";
export const AIRCRAFT_2 = "sample-aircraft-2";
const SESSION_MS = 86_400_000;
const PDF = "%PDF-1.4";

export type Convex = TestConvex<typeof schema>;

/** A refusal as text, or the returned value. */
export async function settle(call: Promise<unknown>) {
  try {
    return { returned: await call };
  } catch (error) {
    if (error instanceof ConvexError) return { refused: String(error.data) };
    return { refused: error instanceof Error ? error.message : String(error) };
  }
}

export async function addUser(
  ctx: MutationCtx,
  name: string,
  groupIds: Id<"groups">[],
  extra: { isAdmin?: boolean; active?: boolean; program?: string } = {},
) {
  const id = await ctx.db.insert("users", {
    name,
    email: `${name}@example.test`,
    active: extra.active ?? true,
    isAdmin: extra.isAdmin ?? false,
    groupIds,
    activeProgramUuid: extra.program ?? PROGRAM,
  });
  await syncMemberships(ctx, id);
  const session = await ctx.db.insert("authSessions", {
    userId: id,
    expirationTime: Date.now() + SESSION_MS,
  });
  return { id, subject: `${id}|${session}` };
}

/** The sample program with one user per role, each signed in. */
export async function seedWorld() {
  const t = convexTest(schema, modules);
  const email = "root@example.test";
  await t.run((ctx) =>
    ctx.db.insert("users", {
      name: "Root",
      email,
      active: true,
      isAdmin: true,
      groupIds: [],
    }),
  );
  await t.mutation(internal.sampleProgram.seed, { email });
  const files = await t.run(async (ctx) => {
    const stored = [];
    for (let i = 0; i < 4; i++)
      stored.push({
        storageId: await ctx.storage.store(
          new Blob([PDF], { type: "application/pdf" }),
        ),
        size: PDF.length,
      });
    return stored;
  });
  await t.mutation(internal.sampleProgram.attach, { files, email });
  const people = await t.run(async (ctx) => {
    const groups = await ctx.db
      .query("groups")
      .withIndex("program", (q) => q.eq("programUuid", PROGRAM))
      .collect();
    const byName = (name: string) => groups.find((g) => g.name === name)!._id;
    const owners = byName("Aircraft owners");
    await ctx.db.patch(owners, { aircraftIds: [AIRCRAFT_1] });
    const root = (await ctx.db
      .query("users")
      .withIndex("email", (q) => q.eq("email", email))
      .unique())!;
    const rootSession = await ctx.db.insert("authSessions", {
      userId: root._id,
      expirationTime: Date.now() + SESSION_MS,
    });
    return {
      groups: {
        observers: byName("Observers"),
        pilots: byName("Pilots"),
        techs: byName("Maintenance technicians"),
        managers: byName("Program managers"),
        owners,
        board: byName("Board (read-only)"),
      },
      root: { id: root._id, subject: `${root._id}|${rootSession}` },
      observer: await addUser(ctx, "observer", [byName("Observers")]),
      pilot: await addUser(ctx, "pilot", [byName("Pilots")]),
      tech: await addUser(ctx, "tech", [byName("Maintenance technicians")]),
      manager: await addUser(ctx, "manager", [byName("Program managers")]),
      owner: await addUser(ctx, "owner", [owners]),
      board: await addUser(ctx, "board", [byName("Board (read-only)")]),
    };
  });
  const as = (who: { subject: string }) => t.withIdentity(who);
  return {
    t,
    people,
    root: as(people.root),
    observer: as(people.observer),
    pilot: as(people.pilot),
    tech: as(people.tech),
    manager: as(people.manager),
    owner: as(people.owner),
    board: as(people.board),
  };
}
