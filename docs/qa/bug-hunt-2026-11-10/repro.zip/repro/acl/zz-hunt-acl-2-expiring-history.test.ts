/**
 * Responsibility: Repro AC-2 (hunt 2026-11-10): an expiring date's change-log
 *   rows show in the snapshot's recent list but never in paged Change
 *   history, the record's own history or the weekly summary.
 * Layer: Test. convex-test; asserts the correct behaviour, so it fails today.
 * Dependencies: ./zzHuntAclWorld, convex/_generated.
 *
 * Run: cp repro/acl/zzHuntAclWorld.ts repro/acl/<this file> convex/ &&
 *   npx vitest run convex/zz-hunt-acl-2-expiring-history.test.ts
 */
import { expect, it } from "vitest";
import { api } from "./_generated/api";
import { seedWorld, PROGRAM } from "./zzHuntAclWorld";

const SAVED = "expiring-date.saved";

async function saveExpiringDate() {
  const w = await seedWorld();
  const uuid = crypto.randomUUID();
  const item = {
    uuid,
    programUuid: PROGRAM,
    kind: "insurance",
    label: "Hull policy",
    expiresOn: "2030-01-01",
    version: 0,
  };
  await w.manager.mutation(api.expiringItems.save, {
    programUuid: PROGRAM,
    payload: JSON.stringify({
      action: "save",
      requestUuid: crypto.randomUUID(),
      item,
    }),
  });
  return { w, uuid };
}

it("is in the snapshot's recent change log (holds today)", async () => {
  const { w } = await saveExpiringDate();
  const view = (await w.manager.query(api.operations.snapshot, {}))!;
  expect(view.audit.map((a) => a.action)).toContain(SAVED);
});

it("is in the program's paged Change history", async () => {
  const { w } = await saveExpiringDate();
  const { page } = await w.manager.query(api.auditHistory.page, {
    programUuid: PROGRAM,
    cursor: null,
    numItems: 200,
  });
  expect(page.map((a) => a.action)).toContain(SAVED);
});

it("pages the expiring date's own history", async () => {
  const { w, uuid } = await saveExpiringDate();
  const { page } = await w.manager.query(api.auditHistory.page, {
    programUuid: PROGRAM,
    entityUuid: uuid,
    cursor: null,
    numItems: 10,
  });
  expect(page.map((a) => a.action)).toEqual([SAVED]);
});

it("is counted in the weekly summary", async () => {
  const { w } = await saveExpiringDate();
  const before = await w.manager.query(api.auditHistory.summary, {
    programUuid: PROGRAM,
    from: "2026-01-01",
    to: "2030-12-31",
  });
  // The seed writes four sample.created rows; the save is the fifth.
  expect(before.summary.total).toBe(5);
});
