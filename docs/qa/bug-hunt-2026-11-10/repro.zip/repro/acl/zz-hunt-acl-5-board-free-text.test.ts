/**
 * Responsibility: Repro AC-5 (hunt 2026-11-10): the board whitelist, which
 *   promises that no free text passes, sends AD source notes, AD compliance
 *   method text, AD action descriptions and the MEL item text.
 * Layer: Test. convex-test; asserts the correct behaviour, so it fails today.
 * Dependencies: ./zzHuntAclWorld, convex/_generated, src/domain/airworthiness.
 *
 * Run: cp repro/acl/zzHuntAclWorld.ts repro/acl/<this file> convex/ &&
 *   npx vitest run convex/zz-hunt-acl-5-board-free-text.test.ts
 */
import { expect, it } from "vitest";
import { api } from "./_generated/api";
import { seedWorld, AIRCRAFT_1 } from "./zzHuntAclWorld";
import { adSchema } from "../src/domain/airworthiness";

const NO_LIMITS = {
  dueDate: "",
  dueHours: null,
  dueCycles: null,
  intervalDays: null,
  intervalHours: null,
  intervalCycles: null,
  recurrence: "Unknown",
  workOrderUuid: "",
};

async function seedFreeText() {
  const w = await seedWorld();
  await w.t.run(async (ctx) => {
    const onAircraft = <T extends "airworthiness" | "discrepancies">(table: T) =>
      ctx.db
        .query(table)
        .withIndex("aircraft", (q) => q.eq("aircraftUuid", AIRCRAFT_1))
        .first();
    const doc = (await onAircraft("airworthiness"))!;
    const ad = JSON.parse(doc.payload);
    const taskUuid = crypto.randomUUID();
    const next = adSchema.parse({
      ...ad,
      source: { ...ad.source, sourceNotes: "MARK-sourceNotes" },
      tasks: [{ ...NO_LIMITS, uuid: taskUuid, description: "MARK-task" }],
      history: [
        {
          uuid: crypto.randomUUID(),
          taskUuid,
          date: "2026-01-01",
          hours: 10,
          cycles: null,
          method: "MARK-method",
          serviceBulletin: "MARK-serviceBulletin",
          terminatedBy: "MARK-terminatedBy",
          workOrderUuid: "",
          mechanic: "MARK-mechanic",
          certificate: "MARK-certificate",
          evidence: "MARK-evidence",
          recordedAt: 1,
          recordedBy: "MARK-recordedBy",
        },
      ],
    });
    await ctx.db.patch(doc._id, { payload: JSON.stringify(next) });
    const report = (await onAircraft("discrepancies"))!;
    await ctx.db.patch(report._id, {
      deferral: {
        type: "mel",
        melItem: "MARK-melItem",
        category: "C",
        placard: "MARK-placard",
        deferredOn: "2026-11-01",
        deferredAt: 1,
        deferredBy: "MARK-deferredBy",
        deferredByName: "MARK-deferredByName",
      },
    });
  });
  return w;
}

it("sends a board member none of the free text typed on ADs and deferrals", async () => {
  const w = await seedFreeText();
  const view = await w.board.query(api.operations.snapshot, {});
  const passed = JSON.stringify(view).match(/MARK-[A-Za-z]+/g) ?? [];
  // Cleared today: mechanic, certificate, evidence, recordedBy, placard,
  // deferredBy, deferredByName. The rest still pass.
  expect([...new Set(passed)]).toEqual([]);
});
