/**
 * Responsibility: Repro AC-6 (hunt 2026-11-10): editing a saved address
 *   overwrites it and writes a change-log row with no before or after that
 *   nobody can read.
 * Layer: Test. convex-test; asserts the correct behaviour, so it fails today.
 * Dependencies: ./zzHuntAclWorld, convex/_generated.
 *
 * Run: cp repro/acl/zzHuntAclWorld.ts repro/acl/<this file> convex/ &&
 *   npx vitest run convex/zz-hunt-acl-6-address-audit.test.ts
 */
import { expect, it } from "vitest";
import { api } from "./_generated/api";
import { seedWorld, PROGRAM } from "./zzHuntAclWorld";

const ADDRESS = {
  organization: "Depot",
  street: "1 Main St",
  street2: "",
  city: "Town",
  region: "TX",
  postalCode: "75001",
  country: "United States",
  contactName: "Alice",
  email: "alice@example.test",
  phone: "555-555-0100",
  confirmed: false,
};

async function editAddress() {
  const w = await seedWorld();
  const uuid = crypto.randomUUID();
  const save = (version: number, street: string) =>
    w.manager.mutation(api.savedAddresses.save, {
      programUuid: PROGRAM,
      payload: JSON.stringify({
        uuid,
        version,
        name: "Depot",
        address: { ...ADDRESS, street },
      }),
    });
  await save(0, "1 Main St");
  await save(1, "99 Other Rd");
  return { w, uuid };
}

it("records what a saved address was before and after an edit", async () => {
  const { w, uuid } = await editAddress();
  const rows = await w.t.run(async (ctx) =>
    ctx.db
      .query("audit")
      .withIndex("entity", (q) => q.eq("entityUuid", uuid))
      .collect(),
  );
  expect(rows.map((r) => r.action)).toEqual(["address.saved", "address.saved"]);
  expect(rows[1].before).toContain("1 Main St");
  expect(rows[1].after).toContain("99 Other Rd");
});

it("lets the program administrator read the address's history", async () => {
  const { w, uuid } = await editAddress();
  const { page } = await w.manager.query(api.auditHistory.page, {
    programUuid: PROGRAM,
    entityUuid: uuid,
    cursor: null,
    numItems: 10,
  });
  expect(page).toHaveLength(2);
});
