/**
 * Responsibility: Repro AC-4 (hunt 2026-11-10): the owner portal's "current
 *   Form 337 copies" whitelist also passes logbook page photos of flights
 *   and work orders, with download URLs and the linked record ids.
 * Layer: Test. convex-test; asserts the correct behaviour, so it fails today.
 * Dependencies: ./zzHuntAclWorld, convex/_generated.
 *
 * Run: cp repro/acl/zzHuntAclWorld.ts repro/acl/<this file> convex/ &&
 *   npx vitest run convex/zz-hunt-acl-4-owner-logbook-photos.test.ts
 */
import { expect, it } from "vitest";
import { api } from "./_generated/api";
import { seedWorld, PROGRAM, AIRCRAFT_1 } from "./zzHuntAclWorld";

const JPEG = {
  name: "page.jpg",
  type: "image/jpeg",
  bytes: new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 1, 2, 3]).buffer,
};

it("sends an aircraft owner Form 337 copies only, not logbook page photos", async () => {
  const w = await seedWorld();
  const ids = await w.t.run(async (ctx) => {
    const onAircraft = (table: "flights" | "workOrders") =>
      ctx.db
        .query(table)
        .withIndex("aircraft", (q) => q.eq("aircraftUuid", AIRCRAFT_1))
        .first();
    return {
      flight: (await onAircraft("flights"))!.uuid,
      order: (await onAircraft("workOrders"))!.uuid,
    };
  });
  const target = { aircraftUuid: AIRCRAFT_1, programUuid: PROGRAM };
  await w.pilot.action(api.aircraftFiles.upload, {
    ...target,
    ...JPEG,
    category: "logbook-page",
    linkedKind: "flight",
    linkedUuid: ids.flight,
  });
  await w.tech.action(api.aircraftFiles.upload, {
    ...target,
    ...JPEG,
    category: "logbook-page",
    linkedKind: "work-order",
    linkedUuid: ids.order,
  });
  const view = (await w.owner.query(api.operations.snapshot, {}))!;
  // The owner portal holds no flights and only completed work-order
  // summaries; ownerSnapshot documents "current Form 337 copies".
  expect(view.flights).toEqual([]);
  expect(view.aircraftFiles?.map((f) => f.category)).toEqual([]);
});
