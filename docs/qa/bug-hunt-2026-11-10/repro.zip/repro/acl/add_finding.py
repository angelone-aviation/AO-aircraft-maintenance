# Responsibility: Appends one finding (a JSON object read from stdin) to the
#   acl findings file as a single line, after checking it parses.
# Layer: Script. Hunt tooling only.
# Dependencies: Python standard library.
import json
import sys

finding = json.load(sys.stdin)
with open(sys.argv[1], "a", encoding="utf-8") as out:
    out.write(json.dumps(finding, ensure_ascii=False) + "\n")
print("added", finding["id"])
