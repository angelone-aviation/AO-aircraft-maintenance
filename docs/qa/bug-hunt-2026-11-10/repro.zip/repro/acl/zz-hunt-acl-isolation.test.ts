/**
 * Responsibility: Hunt 2026-11-10 isolation probe (AC-9 onward): members of
 *   the sample program call every public function with the ids of a program
 *   split off from it by real transfers, and must read, change, link to and
 *   reveal nothing of it.
 * Layer: Test. convex-test suite; derived from convex/tenantIsolation.test.ts
 *   (its cases are reused, its own describes are skipped).
 * Dependencies: convex/schema.ts, convex/sampleProgram.ts,
 *   convex/memberships.ts, convex/_generated, src/domain/faaSearch.ts.
 *
 * Run: cp to convex/, then
 *   HUNT_OUT=<dir for the per-role JSON reports> npx vitest run \
 *   convex/zz-hunt-acl-isolation.test.ts
 */
import { convexTest, type TestConvex } from "convex-test";
import { beforeAll, describe, expect, it } from "vitest";
import {
  getFunctionName,
  type FunctionArgs,
  type FunctionReference,
  type StorageActionWriter,
} from "convex/server";
import { ConvexError } from "convex/values";
import schema from "./schema";
import { api, internal } from "./_generated/api";
import type { Doc, Id, TableNames } from "./_generated/dataModel";
import type { MutationCtx } from "./_generated/server";
import { PROGRAM as PROGRAM_B } from "./sampleProgram";
import { syncMemberships } from "./memberships";
import { blankSearch, searchAssets } from "../src/domain/faaSearch";
import { STALE_RECORD_MESSAGE } from "../src/domain/rejection";

const modules = import.meta.glob([
  "./**/*.ts",
  "./_generated/*.js",
  "!./**/*.test.ts",
  "!./**/*.d.ts",
]);
const TABLES = Object.keys(schema.tables) as TableNames[];
const STORAGE = "_storage";
const PROGRAM_A = "victim-program";
const IN_A = { programUuid: PROGRAM_A };
const B_AIRCRAFT = "sample-aircraft-1";
const ROOT_EMAIL = "root@example.test";
const ALICE_EMAIL = "alice@example.test";
const SESSION_MS = 86_400_000;
// sampleProgram.attach files exactly one example PDF per sample aircraft.
const SAMPLE_PDFS = 4;
const PDF = "%PDF-1.4";
const PDF_TYPE = "application/pdf";
const PDF_FILE = {
  name: "file.pdf",
  type: PDF_TYPE,
  bytes: new TextEncoder().encode(PDF).buffer,
};
// A well-formed base64 SHA-256; no file is ever uploaded against it.
const SHA256 = `${"A".repeat(43)}=`;
const NEW_ACCOUNT = {
  email: "new@example.test",
  name: "New User",
  password: "correct horse battery staple",
};
const ADDRESS_UUID = "11111111-1111-4111-8111-111111111111";
const ADDRESS = {
  organization: "A depot",
  street: "1 Main St",
  street2: "",
  city: "Town",
  region: "TX",
  postalCode: "75001",
  country: "United States",
  contactName: "Alice",
  email: ALICE_EMAIL,
  phone: "555-555-0100",
  confirmed: false,
};
const FLIGHT = {
  startTime: "2026-01-01T10:00:00Z",
  hobbsOn: 3600,
  landings: 1,
  cycles: 1,
  origin: "AAA",
  destination: "BBB",
  operation: "Mission",
  flightRules: "VFR",
  remarks: "",
  discrepancy: "",
} as const;

const AIRCRAFT_DENIED = "You do not have permission for this aircraft.";
const MAINTENANCE = "Aircraft maintenance permission required.";
const FLIGHT_PERMISSION = "Aircraft flight permission required.";
const FLIGHT_NOT_FOUND = "Flight not found.";
const WORK_ORDER_NOT_FOUND = "Work order not found.";
const MANUAL_MAINTENANCE = "Maintenance access is required.";
const WORK_ORDER_DENIED = "Work order maintenance access denied.";
const CHECKLIST_DENIED = "Checklist editing permission denied.";
const PERMISSION_DENIED = "Permission denied.";
const INVENTORY_ADMIN =
  "Inventory administrator access to this item is required.";
const LICENSE_OWNER =
  "Only the account owner or an administrator may access license records.";
const STALE_PROGRAM =
  "Flight Program changed. Reopen the form in the correct program.";
const ADMIN = "Administrator permission required.";
const FOREIGN_GROUP =
  "Users can only be assigned groups in this Flight Program.";
const RECORD_TAKEN = "Record belongs to another Flight Program.";
const PO_NOT_FOUND = "PO not found.";
const HISTORY_NOT_FOUND = "History not found.";
const GROUP_NOT_FOUND = "Permission group not found.";

type Kind = "query" | "mutation" | "action";
type Convex = TestConvex<typeof schema>;
type Client = ReturnType<Convex["withIdentity"]>;
type Outcome = { refused: string } | { returned: unknown };
type Dump = Record<string, string>;
type FirstRows = { [T in TableNames]: Doc<T> };
type ProgramA = Awaited<ReturnType<typeof readProgramA>>;
type ArgsOf<F extends FunctionReference<Kind>> = NoInfer<
  (a: ProgramA, me: Id<"users">) => FunctionArgs<F>
>;

/** A stored record's JSON; cases send it back whole or read its version. */
interface Payload {
  uuid: string;
  version: number;
  [field: string]: unknown;
}

/** One call on A by someone working in B, and the answer it must get. */
interface Case {
  /** The function as `module:name`, the form the coverage check lists. */
  fn: string;
  kind: Kind;
  /** What of A's the call aims at; completes the test name. */
  target: string;
  call: (client: Client, a: ProgramA, me: Id<"users">) => Promise<unknown>;
  expected: Outcome;
  /** A member of A may make this call legitimately; only outsiders try. */
  outsiderOnly?: boolean;
}

/** A call not yet pinned: `refuses` or `returns` completes the case. */
interface Attempt {
  refuses: (message: string) => Case;
  returns: (value: unknown) => Case;
}

// Public functions that reach no Flight Program record, and why.
const NOT_PROGRAM_SCOPED: Record<string, string> = {
  "identities:providers": "Lists the enabled sign-in buttons, before sign-in.",
  "auth:signIn": "Convex Auth's sign-in; the caller has no session yet.",
  "auth:signOut": "Convex Auth; ends the caller's own session.",
  "auth:isAuthenticated": "Convex Auth; answers for the caller's own session.",
  "identities:mine": "Lists the caller's own linked identities.",
  "admin:saveLicense": "Writes the caller's own license fields.",
  "admin:saveLogbookPhrases": "Writes the caller's own logbook phrases.",
  "admin:saveReleaseStatements": "Writes the caller's own release statements.",
  "alerts:setEmailPreference": "Writes the caller's own alert-email choice.",
  "urgentAlerts:setUrgentEmailPreference":
    "Writes the caller's own urgent-alert email choice.",
  "pushSubscriptions:publicKey":
    "Returns the deployment's public push key, the same for everyone.",
};
const EXPIRING_UUID = "22222222-2222-4222-8222-222222222222";
const PUSH_SUBSCRIPTION = {
  endpoint: "https://push.example.test/b-device",
  keys: { p256dh: "p".repeat(87), auth: "a".repeat(22) },
};

const CASES: Case[] = [
  callQuery(api.operations.snapshot, "its own snapshot", () => ({})).returns(
    expect.objectContaining({ activeProgramUuid: PROGRAM_B }),
  ),
  callMutation(api.operations.submit, "a flight on A's aircraft", (a, me) => ({
    operation: buildFlight(me, a.row.aircraft.uuid),
  })).refuses(AIRCRAFT_DENIED),
  callMutation(api.operations.submit, "a flight under A's plan", (a, me) => ({
    operation: buildFlight(me, B_AIRCRAFT, a.row.flightPlans.uuid),
  })).refuses("Flight plan is unavailable for this aircraft."),
  callMutation(api.operations.submit, "a report on A's flight", (a, me) => ({
    operation: stampB({
      kind: "discrepancy",
      uuid: crypto.randomUUID(),
      authorId: me,
      aircraftUuid: B_AIRCRAFT,
      flightUuid: a.row.flights.uuid,
      description: "Seen on A's flight.",
    }),
  })).refuses("Linked flight does not belong to this aircraft."),
  callMutation(api.operations.resolveDiscrepancy, "A's report", (a) =>
    stampB({ uuid: a.row.discrepancies.uuid, resolution: "Fixed." }),
  ).refuses(AIRCRAFT_DENIED),
  callMutation(api.operations.deferDiscrepancy, "A's report", (a) =>
    sendInB({
      uuid: a.row.discrepancies.uuid,
      deferredOn: "2026-01-01",
      deferral: { type: "mel", melItem: "1", category: "C", placard: "Inop" },
    }),
  ).refuses(AIRCRAFT_DENIED),
  callMutation(api.operations.saveDiscrepancyParts, "A's report", (a) =>
    stampB({
      uuid: a.row.discrepancies.uuid,
      version: a.row.discrepancies.partsVersion ?? 0,
      payload: "[]",
    }),
  ).refuses(PERMISSION_DENIED),
  callMutation(api.operations.reviewFlight, "A's flight", (a) =>
    buildReview(a.row.flights, a.row.aircraft.uuid),
  ).refuses(AIRCRAFT_DENIED),
  callMutation(api.operations.reviewFlight, "A's flight, as B's", (a) =>
    buildReview(a.row.flights, B_AIRCRAFT),
  ).refuses("Flight not found."),
  callMutation(api.workOrders.save, "templates into A's work order", (a) =>
    sendInB({ action: "copyTemplates", ...readVersion(a.row.workOrders) }),
  ).refuses(WORK_ORDER_DENIED),
  callMutation(api.workOrders.save, "A's work order uuid on B's", (a) =>
    sendInB({
      action: "save",
      uuid: a.row.workOrders.uuid,
      version: 0,
      fields: { ...parsePayload(a.row.workOrders), aircraftUuid: B_AIRCRAFT },
      componentUuids: [],
      tasks: [],
    }),
  ).refuses(WORK_ORDER_DENIED),
  callMutation(api.workOrders.removeFile, "A's work order file", (a) =>
    stampB({ id: a.row.workOrderFiles._id }),
  ).refuses(AIRCRAFT_DENIED),
  callAction(api.workOrders.upload, "A's work order", (a) =>
    stampB({ workOrderUuid: a.row.workOrders.uuid, ...PDF_FILE }),
  ).refuses(AIRCRAFT_DENIED),
  callMutation(api.workOrderCopies.resume, "A's work order", (a) => ({
    workOrderUuid: a.row.workOrders.uuid,
    programUuid: PROGRAM_B,
  })).refuses(WORK_ORDER_DENIED),
  callMutation(api.costs.execute, "a cost on A's work order", (a) =>
    sendInB(
      buildCommand("other.add", {
        workOrderUuid: a.row.workOrders.uuid,
        entry: {
          uuid: crypto.randomUUID(),
          date: "2026-01-01",
          description: "Hangar fee",
          amountCents: 100,
        },
      }),
    ),
  ).refuses("Work order not found."),
  callMutation(api.taskCards.save, "a signature on A's job card", (a) =>
    sendInB({
      action: "sign",
      kind: "technician",
      ...readVersion(a.row.taskCards),
    }),
  ).refuses("Job card maintenance access denied."),
  callMutation(api.taskCards.save, "A's job card uuid on B's", (a) =>
    sendInB({
      action: "save",
      uuid: a.row.taskCards.uuid,
      version: 0,
      fields: {
        ...parsePayload(a.row.taskCards),
        aircraftUuid: B_AIRCRAFT,
        workOrderUuid: "",
        workTaskUuid: "",
        inspectionUuid: "",
        componentUuid: "",
      },
    }),
  ).refuses(RECORD_TAKEN),
  callMutation(api.taskCards.removeEvidence, "A's job card evidence", (a) =>
    stampB({ id: a.row.taskEvidence._id }),
  ).refuses("Evidence not found."),
  callAction(api.taskCards.upload, "evidence on A's job card", (a) =>
    stampB({
      taskCardUuid: a.row.taskCards.uuid,
      category: "supporting-document",
      ...PDF_FILE,
    }),
  ).refuses("An open job card and maintenance access are required."),
  callMutation(api.taskImports.save, "job cards into A's inspection", (a) =>
    sendInB({
      csv: "Item,Instruction\n1,Inspect",
      targetKind: "inspection",
      targetUuid: a.row.inspections.uuid,
      targetVersion: a.row.inspections.version ?? 0,
      reviewed: true,
    }),
  ).refuses("Target is unavailable or maintenance access is denied."),
  callMutation(api.management.execute, "A's stock item", (a) =>
    sendInB(buildCommand("record.save", { record: a.stock })),
  ).refuses("Use an explicit Flight Program transfer."),
  callMutation(api.management.execute, "A's stock item, as B's", (a) =>
    sendInB(
      buildCommand("record.save", {
        record: stampB({ ...a.stock, version: 0 }),
      }),
    ),
  ).refuses("Storage location must belong to this Flight Program."),
  callMutation(api.management.execute, "A's inspection", (a) =>
    sendInB(
      buildCommand("inspection.save", {
        record: stripSystemFields(a.row.inspections),
      }),
    ),
  ).refuses(PERMISSION_DENIED),
  callMutation(api.inventoryFiles.remove, "A's stock file", (a) =>
    stampB({ id: a.row.inventoryFiles._id }),
  ).refuses(INVENTORY_ADMIN),
  callAction(api.inventoryFiles.upload, "a file on A's stock", (a) =>
    stampB({ stockUuid: a.row.inventoryFiles.stockUuid, ...PDF_FILE }),
  ).refuses(INVENTORY_ADMIN),
  callMutation(api.purchaseOrders.execute, "A's purchase order", (a) =>
    sendInB(buildCancel(a.row.purchaseOrders)),
  ).refuses("Purchase order not found."),
  callQuery(api.purchaseOrders.files, "A's purchase order", (a) =>
    stampB({ poUuid: a.row.purchaseOrders.uuid }),
  ).refuses(PO_NOT_FOUND),
  callMutation(api.poFiles.remove, "A's purchase order file", (a) =>
    stampB({ id: a.row.poFiles._id }),
  ).refuses(PO_NOT_FOUND),
  callAction(api.poFiles.upload, "a file on A's purchase order", (a) =>
    stampB({ poUuid: a.row.purchaseOrders.uuid, ...PDF_FILE }),
  ).refuses(PO_NOT_FOUND),
  callQuery(api.aircraftSpruce.orders, "A's purchase order", (a) =>
    stampB({ poUuid: a.row.purchaseOrders.uuid }),
  ).returns(null),
  callAction(api.aircraftSpruceActions.sync, "A's purchase order", (a) =>
    stampB({ poUuid: a.row.purchaseOrders.uuid, order: "" }),
  ).refuses("PO not found in this Flight Program."),
  callMutation(api.partsRequests.execute, "A's parts request", (a) =>
    sendInB(buildCancel(a.row.partsRequests)),
  ).refuses("Request changed. Reopen it before saving."),
  callMutation(api.airworthiness.save, "A's AD", (a) =>
    sendInB({ kind: "save", record: parsePayload(a.row.airworthiness) }),
  ).refuses(MAINTENANCE),
  callMutation(api.checklists.save, "A's checklist", (a) =>
    sendInB(buildChecklistSave(a, {})),
  ).refuses(CHECKLIST_DENIED),
  callMutation(api.checklists.save, "A's checklist, as B's", (a) =>
    sendInB(buildChecklistSave(a, stampB({ aircraftUuid: "" }))),
  ).refuses(CHECKLIST_DENIED),
  callMutation(api.flightPlans.save, "A's flight plan", (a) =>
    sendInB(buildPlanSave(a, {})),
  ).refuses(AIRCRAFT_DENIED),
  callMutation(api.flightPlans.save, "A's plan uuid on B's aircraft", (a) =>
    sendInB(buildPlanSave(a, { aircraftUuid: B_AIRCRAFT, version: 0 })),
  ).refuses("Plan ID already used."),
  callMutation(api.inspectionTemplates.save, "A's template", (a) =>
    sendInB([parsePayload(a.row.inspectionTemplates)]),
  ).refuses("Template belongs to another Flight Program."),
  callMutation(api.inspectionTemplates.remove, "A's template", (a) =>
    sendInB({
      templates: [readVersion(a.row.inspectionTemplates)],
      taskCards: [],
    }),
  ).refuses(
    "A selected template is unavailable in this Flight Program. Refresh the list.",
  ),
  callMutation(api.inspectionTemplates.activate, "A's template on B's", (a) =>
    sendInB({
      templateUuid: a.row.inspectionTemplates.uuid,
      templateVersion: readVersion(a.row.inspectionTemplates).version,
      targetUuid: B_AIRCRAFT,
      mode: "recurring",
      description: "Annual",
      reviewed: true,
    }),
  ).refuses("Template is unavailable in this Flight Program."),
  callMutation(api.componentTemplates.save, "A's template uuid, as B's", (a) =>
    sendInB(stampB({ ...parsePayload(a.row.componentTemplates), version: 0 })),
  ).refuses(RECORD_TAKEN),
  callMutation(api.componentTemplates.apply, "A's template on B's", (a) =>
    sendInB({
      templateUuid: a.row.componentTemplates.uuid,
      version: readVersion(a.row.componentTemplates).version,
      aircraftUuid: B_AIRCRAFT,
      rowIds: ["1"],
    }),
  ).refuses("Template and aircraft maintenance access required."),
  callQuery(api.engineTrends.list, "A's aircraft", (a) =>
    stampB({ aircraftUuid: a.row.aircraft.uuid }),
  ).refuses("Aircraft read permission required."),
  callMutation(api.engineTrends.execute, "A's aircraft", (a) => ({
    aircraftUuid: a.row.aircraft.uuid,
    ...sendInB({ action: "remove", uuid: crypto.randomUUID() }),
  })).refuses(MAINTENANCE),
  callMutation(api.faa.command, "an AD check of A's aircraft", (a) =>
    sendInB({ kind: "check", aircraftUuid: a.row.aircraft.uuid }),
  ).refuses(MAINTENANCE),
  callAction(api.faaSearch.search, "an AD search on A's aircraft", (a) =>
    sendInB(buildSearch(a.row.aircraft)),
  ).refuses(MAINTENANCE),
  callMutation(api.fleet.save, "A's aircraft", (a) =>
    sendInB(buildCommand("aircraft.save", { aircraft: copyAircraft(a, {}) })),
  ).refuses(STALE_RECORD_MESSAGE),
  callMutation(api.fleet.save, "A's aircraft uuid, as new", (a) =>
    sendInB(
      buildCommand("aircraft.save", {
        aircraft: copyAircraft(a, { registration: "N0NEW", version: 0 }),
      }),
    ),
  ).refuses("Aircraft belongs to another Flight Program."),
  callMutation(api.fleet.save, "A's program", (a) =>
    sendInB(
      buildCommand("program.save", {
        program: { ...stripSystemFields(a.row.programs), name: "Renamed by B" },
      }),
    ),
  ).refuses(ADMIN),
  callMutation(api.programs.transfer, "A's aircraft", (a) =>
    stampB({
      kind: "aircraft",
      uuid: a.row.aircraft.uuid,
      destination: PROGRAM_B,
      reason: "Ours now.",
    }),
  ).refuses("System administrator required for Flight Program transfers."),
  {
    ...callMutation(api.programs.select, "program A", () => IN_A).refuses(
      "Flight Program access denied.",
    ),
    outsiderOnly: true,
  },
  callQuery(api.manuals.open, "A's manual", (a) =>
    stampB({ uuid: a.row.manuals.uuid }),
  ).refuses("Manual is not available in this workspace."),
  callMutation(api.manuals.rename, "A's manual", (a) =>
    stampB({ uuid: a.row.manuals.uuid, title: "Renamed by B" }),
  ).refuses(MANUAL_MAINTENANCE),
  callMutation(api.manuals.edit, "A's manual", (a) =>
    stampB({ uuid: a.row.manuals.uuid, payload: "{}" }),
  ).refuses(MANUAL_MAINTENANCE),
  callMutation(api.manuals.setApplicability, "A's manual", (a) =>
    stampB({ uuid: a.row.manuals.uuid, payload: "{}" }),
  ).refuses(MANUAL_MAINTENANCE),
  callMutation(api.manuals.beginUpload, "a manual for A's aircraft", (a) => ({
    sha256: SHA256,
    ...sendInB(describeManual(a.row.aircraft.uuid)),
  })).refuses("Maintenance access is required to upload a manual."),
  callAction(api.manuals.finishUpload, "Alice's upload of A's file", (a) =>
    stampB({
      ticket: a.row.manualUploads._id,
      storageId: a.row.manuals.storageId,
    }),
  ).refuses("Upload expired. Please upload again."),
  callAction(api.aircraftPhotos.upload, "A's aircraft", (a) =>
    stampB({
      aircraftUuid: a.row.aircraft.uuid,
      type: "image/png",
      bytes: PDF_FILE.bytes,
    }),
  ).refuses(MAINTENANCE),
  callMutation(api.aircraftPhotos.remove, "A's aircraft photo", (a) =>
    stampB({ aircraftUuid: a.row.aircraft.uuid }),
  ).refuses(MAINTENANCE),
  callMutation(api.aircraftFiles.archive, "A's Form 337", (a) =>
    stampB({ id: a.row.aircraftFiles._id, reason: "Superseded." }),
  ).refuses(MAINTENANCE),
  callAction(api.aircraftFiles.upload, "a Form 337 on A's aircraft", (a) =>
    stampB({
      aircraftUuid: a.row.aircraft.uuid,
      category: "form-337",
      ...PDF_FILE,
    }),
  ).refuses(MAINTENANCE),
  callAction(api.aircraftFiles.upload, "a photo of A's flight line", (a) =>
    stampB({
      aircraftUuid: a.row.aircraft.uuid,
      category: "logbook-page",
      linkedKind: "flight",
      linkedUuid: a.row.flights.uuid,
      ...PDF_FILE,
    }),
  ).refuses(FLIGHT_PERMISSION),
  // B may write its own aircraft, but A's records are not on it.
  callAction(
    api.aircraftFiles.upload,
    "a photo filing A's flight on B's aircraft",
    (a) =>
      stampB({
        aircraftUuid: B_AIRCRAFT,
        category: "logbook-page",
        linkedKind: "flight",
        linkedUuid: a.row.flights.uuid,
        ...PDF_FILE,
      }),
  ).refuses(FLIGHT_NOT_FOUND),
  callAction(
    api.aircraftFiles.upload,
    "a photo filing A's work order on B's aircraft",
    (a) =>
      stampB({
        aircraftUuid: B_AIRCRAFT,
        category: "logbook-page",
        linkedKind: "work-order",
        linkedUuid: a.row.workOrders.uuid,
        ...PDF_FILE,
      }),
  ).refuses(WORK_ORDER_NOT_FOUND),
  callQuery(api.auditHistory.page, "A's work order history", (a) =>
    stampB({ entityUuid: a.row.workOrders.uuid, cursor: null, numItems: 50 }),
  ).refuses(HISTORY_NOT_FOUND),
  callQuery(api.auditHistory.page, "A's aircraft history", (a) =>
    stampB({ aircraftUuid: a.row.aircraft.uuid, cursor: null, numItems: 50 }),
  ).refuses(HISTORY_NOT_FOUND),
  callQuery(api.auditHistory.page, "its own history", () =>
    stampB({ cursor: null, numItems: 50 }),
  ).returns(expect.objectContaining({ page: [] })),
  callQuery(api.auditHistory.summary, "its own week", () =>
    stampB({ from: "2026-01-01", to: "2026-12-31" }),
  ).returns(expect.objectContaining({ truncated: false })),
  callQuery(api.alerts.readKeys, "program A", () => IN_A).refuses(
    STALE_PROGRAM,
  ),
  callMutation(api.alerts.markRead, "program A", () =>
    stampA({ keys: ["inspection-due"] }),
  ).refuses(STALE_PROGRAM),
  callMutation(api.expiringItems.save, "A's expiring date", (a) =>
    sendInB({
      action: "archive",
      uuid: a.row.expiringItems.uuid,
      version: readVersion(a.row.expiringItems).version,
    }),
  ).refuses("Expiring date not found."),
  callMutation(api.expiringItems.save, "A's expiring date uuid, as B's", (a) =>
    sendInB({
      action: "save",
      item: {
        ...parsePayload(a.row.expiringItems),
        programUuid: PROGRAM_B,
        version: 0,
      },
    }),
  ).refuses(RECORD_TAKEN),
  callMutation(api.expiringItems.save, "a system-wide expiring date", () =>
    sendInB({
      action: "save",
      item: {
        uuid: crypto.randomUUID(),
        kind: "secret",
        label: "Deployment secret",
        expiresOn: "2030-01-01",
        version: 0,
      },
    }),
  ).refuses(ADMIN),
  callMutation(api.pushSubscriptions.subscribe, "program A", () =>
    stampA(PUSH_SUBSCRIPTION),
  ).refuses(STALE_PROGRAM),
  callMutation(api.pushSubscriptions.unsubscribe, "program A", () =>
    stampA({ endpoint: PUSH_SUBSCRIPTION.endpoint }),
  ).refuses(STALE_PROGRAM),
  callQuery(api.savedAddresses.list, "program A", () => IN_A).refuses(
    STALE_PROGRAM,
  ),
  callMutation(api.savedAddresses.save, "A's saved address", () =>
    sendInB({ uuid: ADDRESS_UUID, version: 1, name: "B's", address: ADDRESS }),
  ).refuses("Address not found in this Flight Program."),
  callAction(api.addressVerification.lookup, "program A", () =>
    stampA({ payload: JSON.stringify(ADDRESS) }),
  ).refuses(STALE_PROGRAM),
  callQuery(api.aircraftSpruce.status, "program A", () => IN_A).refuses(
    STALE_PROGRAM,
  ),
  callMutation(api.aircraftSpruce.disconnect, "program A", () =>
    stampA({ version: 0 }),
  ).refuses(STALE_PROGRAM),
  callAction(api.aircraftSpruceActions.link, "program A", () =>
    stampA({
      version: 0,
      userid: "b-buyer",
      password: "not-a-real-password",
      apikey: "not-a-real-key",
      currency: "USD",
    }),
  ).refuses(STALE_PROGRAM),
  callAction(
    api.aircraftSpruceActions.refresh,
    "program A",
    () => IN_A,
  ).refuses(STALE_PROGRAM),
  callAction(api.aircraftSpruceActions.search, "program A", () =>
    stampA({ search: "filter" }),
  ).refuses(STALE_PROGRAM),
  callQuery(api.groupDeletion.preview, "A's administrators", (a) =>
    stampB({ id: a.adminGroup }),
  ).refuses(GROUP_NOT_FOUND),
  callMutation(api.groupDeletion.remove, "A's administrators", (a) =>
    stampB({ id: a.adminGroup, expected: "Administrators" }),
  ).refuses(GROUP_NOT_FOUND),
  callMutation(api.admin.saveGroup, "A's administrators, into B", (a) =>
    stampB({
      id: a.adminGroup,
      name: "Admins",
      aircraftIds: [],
      permissions: ["read"],
    }),
  ).refuses("A permission group cannot be moved to another Flight Program."),
  callMutation(api.admin.saveGroup, "a B group over A's aircraft", (a) =>
    stampB({
      name: "Reach",
      aircraftIds: [a.row.aircraft.uuid],
      permissions: ["read"],
    }),
  ).refuses("Group aircraft must belong to its Flight Program."),
  callMutation(api.programUsers.updateAccess, "itself, into A", (a, me) =>
    stampB({ userId: me, groupIds: [a.adminGroup], remove: false }),
  ).refuses(FOREIGN_GROUP),
  callMutation(api.programUsers.addExisting, "Alice, into A", (a) =>
    stampB({ email: ALICE_EMAIL, groupIds: [a.adminGroup] }),
  ).refuses(FOREIGN_GROUP),
  callAction(api.programUsers.create, "an account in A", (a) =>
    stampB({ ...NEW_ACCOUNT, groupIds: [a.adminGroup] }),
  ).refuses(FOREIGN_GROUP),
  callQuery(api.certifications.list, "Alice's licenses", (a) => ({
    userId: a.alice,
  })).refuses(LICENSE_OWNER),
  callMutation(api.certifications.save, "Alice's licenses", (a) => ({
    userId: a.alice,
    payload: "[]",
  })).refuses(LICENSE_OWNER),
  callQuery(api.certifications.fileUrl, "Alice's license copy", (a) => ({
    id: a.row.certificationFiles._id,
  })).refuses(LICENSE_OWNER),
  callMutation(api.certifications.remove, "Alice's license copy", (a) => ({
    id: a.row.certificationFiles._id,
  })).refuses(LICENSE_OWNER),
  callAction(api.certifications.upload, "a license copy for Alice", (a) => ({
    userId: a.alice,
    kind: "ap",
    ...PDF_FILE,
  })).refuses(LICENSE_OWNER),
  callMutation(api.admin.updateUser, "itself, into A", (a, me) => ({
    id: me,
    active: true,
    isAdmin: false,
    groupIds: [a.adminGroup],
  })).refuses(ADMIN),
  callAction(api.admin.createUser, "an account", () => NEW_ACCOUNT).refuses(
    ADMIN,
  ),
  callAction(api.admin.resetPassword, "Alice's password", (a) => ({
    id: a.alice,
    password: NEW_ACCOUNT.password,
  })).refuses(ADMIN),
  callQuery(api.identities.forUser, "Alice's sign-ins", (a) => ({
    userId: a.alice,
  })).refuses(ADMIN),
  callMutation(api.identities.remove, "Alice's Google sign-in", (a) => ({
    userId: a.alice,
    id: a.row.authAccounts._id,
  })).refuses(ADMIN),
  callMutation(api.defaultGroups.initialize, "program A", () => IN_A).refuses(
    ADMIN,
  ),
  callQuery(api.groupAudit.groupsToReview, "all groups", () => ({})).refuses(
    ADMIN,
  ),
  callQuery(api.backups.latestOffsiteCopy, "backups", () => ({})).refuses(
    ADMIN,
  ),
  callQuery(api.addressVerification.status, "the key", () => ({})).refuses(
    ADMIN,
  ),
  callAction(api.addressVerification.setKey, "the key", () => ({
    key: "not-a-real-key",
    version: 0,
  })).refuses(ADMIN),
  callAction(api.faaCredentials.replace, "the FAA key", () => ({
    key: "not-a-real-key",
    expiresOn: "2099-01-01",
    version: 0,
  })).refuses(ADMIN),
];

const ATTACKERS = [
  { label: "B's program administrator", memberOfA: false },
  { label: "B's administrator who also reads A", memberOfA: true },
];

describe.skip.each(ATTACKERS)("$label", ({ memberOfA }) => {
  let world: Awaited<ReturnType<typeof seedWorld>>;
  let before: Dump;

  beforeAll(async () => {
    world = await seedWorld(memberOfA);
    before = await dumpDatabase(world.t);
  });

  it.each(CASES.filter((c) => !(memberOfA && c.outsiderOnly)))(
    "$fn: $target",
    async ({ call, expected }) => {
      const outcome = await settle(call(world.attacker, world.a, world.me));
      expect(outcome).toEqual(expected);
      expect(findNamesOfA(outcome, world.a, memberOfA)).toEqual([]);
    },
  );

  // These two run after every case above: vitest runs a file's tests in order.
  it("changes, adds and deletes no row", async () => {
    const changed = listChanges(before, await dumpDatabase(world.t));
    expect(changed.filter((key) => !key.startsWith(STORAGE))).toEqual([]);
  });

  it("deletes no stored file and stores none", async () => {
    const changed = listChanges(before, await dumpDatabase(world.t));
    expect(changed.filter((key) => key.startsWith(STORAGE))).toEqual([]);
  });
});

// A board member of B holds read-only access to B's whole fleet. Whatever a
// case sends, every write is refused, nothing of A's comes back, and the
// snapshot is the board whitelist: no flights, change log, rates or people.
describe.skip("B's board member", () => {
  let world: Awaited<ReturnType<typeof seedWorld>>;
  let before: Dump;

  beforeAll(async () => {
    world = await seedWorld(false, "board");
    before = await dumpDatabase(world.t);
  });

  it.each(CASES)("$fn: $target", async ({ kind, call }) => {
    const outcome = await settle(call(world.attacker, world.a, world.me));
    expect(findNamesOfA(outcome, world.a, false)).toEqual([]);
    if (kind !== "query") expect(outcome).toHaveProperty("refused");
  });

  it("reads only the board whitelist of its own program", async () => {
    const view = (await world.attacker.query(api.operations.snapshot, {}))!;
    expect(view.activeProgramUuid).toBe(PROGRAM_B);
    expect(view.aircraft.map((a) => a.uuid)).toEqual([B_AIRCRAFT]);
    expect(view.flights).toEqual([]);
    expect(view.audit).toEqual([]);
    expect(view.members.map((m) => m.id)).toEqual([view.user.id]);
    expect(view.costs).toBeUndefined();
    expect(view.boardCosts?.map((c) => c.aircraftUuid)).toEqual([B_AIRCRAFT]);
    expect(JSON.stringify(view)).not.toMatch(/rateCents|laborRateCents/);
  });

  it("changes, adds and deletes no row or file", async () => {
    expect(listChanges(before, await dumpDatabase(world.t))).toEqual([]);
  });
});

it.skip("attacks every public function, or says why it need not", async () => {
  const exported = await listPublicFunctions();
  const covered = new Set([
    ...CASES.map((c) => c.fn),
    ...Object.keys(NOT_PROGRAM_SCOPED),
  ]);
  expect(exported.filter((fn) => !covered.has(fn))).toEqual([]);
  expect([...covered].filter((fn) => !exported.includes(fn))).toEqual([]);
});

function callQuery<F extends FunctionReference<"query">>(
  fn: F,
  target: string,
  args: ArgsOf<F>,
): Attempt {
  const ref: FunctionReference<"query"> = fn;
  return attempt(fn, "query", target, (c, a, me) => c.query(ref, args(a, me)));
}

function callMutation<F extends FunctionReference<"mutation">>(
  fn: F,
  target: string,
  args: ArgsOf<F>,
): Attempt {
  const ref: FunctionReference<"mutation"> = fn;
  return attempt(fn, "mutation", target, (c, a, me) =>
    c.mutation(ref, args(a, me)),
  );
}

function callAction<F extends FunctionReference<"action">>(
  fn: F,
  target: string,
  args: ArgsOf<F>,
): Attempt {
  const ref: FunctionReference<"action"> = fn;
  return attempt(fn, "action", target, (c, a, me) =>
    c.action(ref, args(a, me)),
  );
}

function attempt(
  fn: FunctionReference<Kind>,
  kind: Kind,
  target: string,
  call: Case["call"],
): Attempt {
  const name = getFunctionName(fn);
  const pin = (expected: Outcome) => ({
    fn: name,
    kind,
    target,
    call,
    expected,
  });
  return {
    refuses: (message) => pin({ refused: message }),
    returns: (value) => pin({ returned: value }),
  };
}

// A refusal is the answer most cases expect, so it becomes a value to compare.
function settle(call: Promise<unknown>): Promise<Outcome> {
  return call.then(
    (value) => ({ returned: value }),
    (error: unknown) => ({ refused: readMessage(error) }),
  );
}

function readMessage(error: unknown): string {
  if (error instanceof ConvexError) return String(error.data);
  return error instanceof Error ? error.message : String(error);
}

// A member of A may know A exists, since it can switch to A; no one working
// in B may see any of A's records.
function findNamesOfA(outcome: Outcome, a: ProgramA, memberOfA: boolean) {
  const text = JSON.stringify(outcome);
  const names = memberOfA ? a.recordUuids : [PROGRAM_A, ...a.recordUuids];
  return names.filter((name) => text.includes(name));
}

function stampA<T extends object>(fields: T) {
  return { ...fields, programUuid: PROGRAM_A };
}

function stampB<T extends object>(fields: T) {
  return { ...fields, programUuid: PROGRAM_B };
}

function sendInB(payload: unknown) {
  return stampB({ payload: JSON.stringify(payload) });
}

function parsePayload(row: { payload: string }) {
  return JSON.parse(row.payload) as Payload;
}

function readVersion(row: { payload: string }) {
  const { uuid, version } = parsePayload(row);
  return { uuid, version };
}

function buildCommand(action: string, fields: object) {
  return {
    action,
    requestUuid: crypto.randomUUID(),
    reason: "Ours",
    ...fields,
  };
}

function buildCancel(row: { payload: string }) {
  const command = { kind: "cancel", requestUuid: crypto.randomUUID() };
  return { ...command, reason: "Not needed.", ...readVersion(row) };
}

function buildChecklistSave(a: ProgramA, changes: object) {
  const record = parsePayload(a.row.checklists);
  return { record: { ...record, ...changes }, baseVersion: record.version };
}

function buildPlanSave(a: ProgramA, changes: Partial<Payload>) {
  const plan = { ...parsePayload(a.row.flightPlans), ...changes };
  return { plan, baseVersion: plan.version };
}

function copyAircraft(a: ProgramA, changes: object) {
  return {
    ...stripSystemFields(a.row.aircraft),
    programUuid: undefined,
    ...changes,
  };
}

function describeManual(aircraftUuid: string) {
  return {
    aircraftUuid,
    title: "Manual",
    documentNumber: "",
    revision: "1",
    revisionDate: "",
    filename: "manual.pdf",
    size: PDF.length,
    pageCount: 1,
  };
}

function buildSearch(aircraft: Doc<"aircraft">) {
  const assets = searchAssets({ aircraft: [aircraft] }, aircraft.uuid);
  return blankSearch(aircraft.uuid, assets);
}

function buildFlight(me: Id<"users">, aircraftUuid: string, plan?: string) {
  const input = { ...FLIGHT, aircraftUuid, pilotId: me, flightPlanUuid: plan };
  const flight = { kind: "flight" as const, uuid: crypto.randomUUID(), input };
  return stampB({ ...flight, authorId: me, baseVersion: 0 });
}

function buildReview(flight: Doc<"flights">, aircraftUuid: string) {
  const { pilotId, startTime, hobbsOn, landings, cycles, origin } = flight;
  const { destination, operation, flightRules, remarks, discrepancy } = flight;
  return stampB({
    uuid: flight.uuid,
    decision: "reject" as const,
    reason: "Not our flight.",
    input: {
      aircraftUuid,
      pilotId,
      startTime,
      hobbsOn,
      landings,
      cycles,
      origin,
      destination,
      operation,
      flightRules,
      remarks,
      discrepancy,
    },
  });
}

function stripSystemFields<T extends { _id: string; _creationTime: number }>(
  doc: T,
) {
  const { _id, _creationTime, ...fields } = doc;
  return fields;
}

async function seedWorld(
  memberOfA: boolean,
  role: "admin" | "board" = "admin",
) {
  const t = convexTest(schema, modules);
  await seedSampleProgram(t);
  const people = await t.run(async (ctx) => {
    const groups = await addProgramB(ctx);
    const alice = await addUser(ctx, ALICE_EMAIL, [groups.aAdmins], PROGRAM_A);
    await addFilesOfA(ctx, alice.id);
    const own = role === "board" ? groups.bBoard : groups.bAdmins;
    const attackerGroups = memberOfA ? [own, groups.aReaders] : [own];
    const email = "attacker@example.test";
    const attacker = await addUser(ctx, email, attackerGroups, PROGRAM_B);
    return { alice, attacker };
  });
  await addRecordsOfA(t, t.withIdentity(people.alice));
  const a = await t.run((ctx) => readProgramA(ctx, people.alice.id));
  const attacker = t.withIdentity(people.attacker);
  return { t, a, me: people.attacker.id, attacker };
}

async function seedSampleProgram(t: Convex) {
  const email = ROOT_EMAIL;
  const root = { name: "Root", email, active: true, isAdmin: true };
  await t.run((ctx) => ctx.db.insert("users", { ...root, groupIds: [] }));
  await t.mutation(internal.sampleProgram.seed, { email });
  const files = await t.run(async (ctx) => {
    const stored = [];
    for (let i = 0; i < SAMPLE_PDFS; i++)
      stored.push({ storageId: await storePdf(ctx), size: PDF.length });
    return stored;
  });
  await t.mutation(internal.sampleProgram.attach, { files, email });
}

// Program B copies A's program and first aircraft, so every shape a case
// sends is valid in B and only the program boundary can refuse it.
async function addProgramB(ctx: MutationCtx) {
  const program = (await ctx.db.query("programs").first())!;
  const aircraft = (await ctx.db.query("aircraft").first())!;
  const name = "Program B";
  await ctx.db.insert("programs", {
    ...stripSystemFields(program),
    uuid: PROGRAM_B,
    name,
  });
  await ctx.db.insert(
    "aircraft",
    stampB({
      ...stripSystemFields(aircraft),
      uuid: B_AIRCRAFT,
      registration: "N0B",
      program: name,
    }),
  );
  const aGroups = await ctx.db
    .query("groups")
    .withIndex("program", (q) => q.eq("programUuid", PROGRAM_A))
    .collect();
  const bAdmins = await ctx.db.insert("groups", {
    programUuid: PROGRAM_B,
    name: "B administrators",
    programAdmin: true,
    aircraftIds: [],
    permissions: ["read", "flight", "discrepancy", "resolve", "maintenance"],
  });
  const bBoard = await ctx.db.insert("groups", {
    programUuid: PROGRAM_B,
    name: "B board",
    board: true,
    aircraftIds: [],
    permissions: ["read"],
  });
  const aAdmins = aGroups.find((g) => g.programAdmin)!._id;
  const aReaders = aGroups.find(
    (g) =>
      !g.programAdmin &&
      !g.owner &&
      !g.board &&
      g.permissions.join() === "read",
  )!._id;
  return { bAdmins, bBoard, aAdmins, aReaders };
}

async function addUser(
  ctx: MutationCtx,
  email: string,
  groupIds: Id<"groups">[],
  activeProgramUuid: string,
) {
  const name = email.split("@")[0];
  const id = await ctx.db.insert("users", {
    name,
    email,
    active: true,
    isAdmin: false,
    groupIds,
    activeProgramUuid,
  });
  await syncMemberships(ctx, id);
  const expirationTime = Date.now() + SESSION_MS;
  const session = await ctx.db.insert("authSessions", {
    userId: id,
    expirationTime,
  });
  return { id, subject: `${id}|${session}` };
}

// SAMPLE seeds none of these; each is the target of a case.
async function addFilesOfA(
  ctx: MutationCtx & { storage: StorageActionWriter },
  alice: Id<"users">,
) {
  const aircraftUuid = (await ctx.db.query("aircraft").first())!.uuid;
  const file = { type: PDF_TYPE, size: PDF.length, uploadedAt: Date.now() };
  const certificate = { userId: alice, kind: "ap", name: "certificate.pdf" };
  const form337 = {
    aircraftUuid,
    category: "form-337" as const,
    name: "337.pdf",
  };
  await ctx.db.insert("certificationFiles", {
    ...certificate,
    ...file,
    storageId: await storePdf(ctx),
  });
  await ctx.db.insert("aircraftFiles", {
    ...form337,
    ...file,
    storageId: await storePdf(ctx),
  });
  const storageId = await storePdf(ctx);
  await ctx.db.insert("aircraftPhotos", { aircraftUuid, storageId });
  const google = { provider: "google", providerAccountId: "alice" };
  await ctx.db.insert("authAccounts", { userId: alice, ...google });
  const name = ADDRESS.organization;
  await ctx.db.insert(
    "savedAddresses",
    stampA({
      uuid: ADDRESS_UUID,
      version: 1,
      name,
      nameKey: name.toLowerCase(),
      address: ADDRESS,
    }),
  );
}

// Alice writes these through the app, so their stored shape is the real one.
async function addRecordsOfA(t: Convex, alice: Client) {
  const { aircraft, inspection } = await t.run(async (ctx) => ({
    aircraft: (await ctx.db.query("aircraft").first())!,
    inspection: (await ctx.db.query("inspections").first())!,
  }));
  const sendInA = (payload: unknown) =>
    stampA({ payload: JSON.stringify(payload) });
  const { make, model } = aircraft;
  const row = { id: "1", componentType: "Engine", partNumber: "P1", model };
  const template = { name: "Engines", make, model, rows: [row] };
  await alice.mutation(
    api.componentTemplates.save,
    sendInA({ ...template, uuid: crypto.randomUUID(), version: 0 }),
  );
  const draft = draftPartsRequest(inspection.uuid);
  await alice.mutation(
    api.partsRequests.execute,
    sendInA({ kind: "save", requestUuid: crypto.randomUUID(), draft }),
  );
  const manual = sendInA(describeManual(aircraft.uuid));
  await alice.mutation(api.manuals.beginUpload, { ...manual, sha256: SHA256 });
  await alice.mutation(
    api.expiringItems.save,
    sendInA({
      action: "save",
      item: {
        uuid: EXPIRING_UUID,
        programUuid: PROGRAM_A,
        kind: "insurance",
        label: "Hull policy",
        expiresOn: "2030-01-01",
        version: 0,
      },
    }),
  );
}

function draftPartsRequest(inspectionUuid: string) {
  const line = { partNumber: "P1", description: "Filter", quantity: 1 };
  return {
    uuid: crypto.randomUUID(),
    version: 0,
    source: { kind: "inspection", uuid: inspectionUuid },
    mode: "parts",
    date: "2026-01-01",
    engineer: "Alice",
    priority: "P2 Routine",
    requiredBy: "",
    currency: "USD",
    lines: [{ ...line, uuid: crypto.randomUUID() }],
  };
}

function storePdf(ctx: { storage: StorageActionWriter }) {
  return ctx.storage.store(new Blob([PDF], { type: PDF_TYPE }));
}

// The first row of every table a case reads is A's: the seed adds B's program,
// aircraft and group after A's rows.
async function readProgramA(ctx: MutationCtx, alice: Id<"users">) {
  const firsts = await Promise.all(
    TABLES.map(async (table) => [table, await ctx.db.query(table).first()]),
  );
  const groups = await ctx.db
    .query("groups")
    .withIndex("program", (q) => q.eq("programUuid", PROGRAM_A))
    .collect();
  const management = await ctx.db.query("management").collect();
  return {
    row: Object.fromEntries(firsts) as FirstRows,
    alice,
    adminGroup: groups.find((g) => g.programAdmin)!._id,
    stock: management.map(parsePayload).find((r) => r.kind === "stock")!,
    recordUuids: await listRecordUuids(ctx),
  };
}

// Program uuids are left out: B's fills B's own answers, and findNamesOfA treats
// A's apart.
async function listRecordUuids(ctx: MutationCtx): Promise<string[]> {
  const tables = TABLES.filter((table) => table !== "programs");
  const rows = await Promise.all(
    tables.map((table) => ctx.db.query(table).collect()),
  );
  return rows
    .flat()
    .flatMap((row) => ("uuid" in row ? [row.uuid] : []))
    .filter((uuid) => uuid !== B_AIRCRAFT);
}

async function dumpDatabase(t: Convex): Promise<Dump> {
  return t.run(async (ctx) => {
    const tables = await Promise.all(
      TABLES.map(async (table) =>
        (await ctx.db.query(table).collect())
          .filter((row) => !isOwnAllowance(row))
          .map((row) => keyRow(table, row)),
      ),
    );
    const files = await ctx.db.system.query(STORAGE).collect();
    return Object.fromEntries([
      ...tables.flat(),
      ...files.map((file) => keyRow(STORAGE, file)),
    ]);
  });
}

// Characterizes current behaviour: Spruce sync spends one of B's own hourly
// syncs before it looks the purchase order up. That counter is B's, not A's.
function isOwnAllowance(row: object) {
  return "key" in row && row.key === `spruce:sync:program:${PROGRAM_B}`;
}

function keyRow(table: string, row: { _id: string }): [string, string] {
  return [`${table}/${row._id}`, JSON.stringify(row)];
}

function listChanges(before: Dump, after: Dump): string[] {
  const keys = new Set([...Object.keys(before), ...Object.keys(after)]);
  return [...keys].filter((key) => before[key] !== after[key]);
}

async function listPublicFunctions(): Promise<string[]> {
  const paths = Object.keys(modules).filter(
    (path) => !path.startsWith("./_generated/"),
  );
  const names = await Promise.all(paths.map(listModuleFunctions));
  return names.flat().sort();
}

async function listModuleFunctions(path: string): Promise<string[]> {
  const module = path.slice("./".length, -".ts".length);
  const exports = Object.entries((await modules[path]()) as object);
  return exports
    .filter(([, value]) => isPublicFunction(value))
    .map(([name]) => `${module}:${name}`);
}

// Convex's builders mark what they register. Reading the marks, not the
// builder's name, also finds a function made with a custom builder.
function isPublicFunction(value: unknown): boolean {
  if (typeof value !== "function") return false;
  const marks = value as { isPublic?: boolean; isHttp?: boolean };
  return marks.isPublic === true || marks.isHttp === true;
}

// ---------------------------------------------------------------------------
// Hunt 2026-11-10 (tester 4): the reverse direction, with both programs rich.
// The seeded sample program is split by real transfers: aircraft 3 and 4 and
// their records move to the victim program (PROGRAM_A here); the attacker
// works in the sample program (PROGRAM_B here) with aircraft 1 and 2. Every
// case above is re-aimed at the victim's rows, and EXTRA adds the calls that
// name two records at once: the attacker's own record with one of the
// victim's ids swapped in.
// ---------------------------------------------------------------------------

const V_AIRCRAFT = "sample-aircraft-3";
const V = {
  aircraft: V_AIRCRAFT,
  inspection: "sample-inspection-3",
  component: "sample-component-3",
  spare: "sample-spare-3",
  requirement: "sample-requirement-3",
  stock: "77777777-7777-4777-8777-777777777777",
  location: "88888888-8888-4888-8888-888888888888",
  discrepancy: "sample-discrepancy-3",
  flight: "sample-flight-3",
};
const OWN = {
  inspection: "sample-inspection-1",
  component: "sample-component-1",
  requirement: "sample-requirement-1",
  stock: "sample-stock-1",
  location: "sample-location-1",
  discrepancy: "sample-discrepancy-1",
};
const V_MANUAL = "44444444-4444-4444-8444-444444444444";
const V_FLIGHT = "55555555-5555-4555-8555-555555555555";
const V_REPORT = "66666666-6666-4666-8666-666666666666";
const V_ENDPOINT = "https://push.example.test/victim-device";
const V_EXPIRING = "33333333-3333-4333-8333-333333333333";
const HUNT_ROLES = ["manager", "tech", "pilot", "both"] as const;
type HuntRole = (typeof HUNT_ROLES)[number];
const HUNT_GROUP: Record<HuntRole, string> = {
  manager: "Program managers",
  tech: "Maintenance technicians",
  pilot: "Pilots",
  both: "Program managers",
};

interface Ext {
  vera: Id<"users">;
  ownGroup: Id<"groups">;
  vGroup: Id<"groups">;
  vPo: string;
  vTemplate: string;
  ownComponentTemplate: Payload;
  vFlight: string;
  vReport: string;
  vManual: string;
}
let HUNT_T: Convex;
const ext = (a: ProgramA) => a as unknown as ProgramA & Ext;

// The attacker's own stored record, read fresh so its version is current.
async function own(
  table: "workOrders" | "taskCards" | "purchaseOrders" | "airworthiness" | "checklists" | "flightPlans" | "inspectionTemplates" | "management",
  pick: (p: Payload, row: { aircraftUuid?: string }) => boolean,
): Promise<Payload> {
  return HUNT_T.run(async (ctx) => {
    const rows = await ctx.db.query(table).collect();
    const found = rows
      .map((r) => ({ p: parsePayload(r), r: r as { aircraftUuid?: string } }))
      .find(({ p, r }) => pick(p, r));
    return found!.p;
  });
}
const onOwnAircraft = (_: Payload, r: { aircraftUuid?: string }) =>
  r.aircraftUuid === B_AIRCRAFT;
const byUuid = (uuid: string) => (p: Payload) => p.uuid === uuid;
const ownInspection = () =>
  HUNT_T.run(async (ctx) => {
    const doc = (await ctx.db
      .query("inspections")
      .withIndex("uuid", (q) => q.eq("uuid", OWN.inspection))
      .unique())!;
    // The sample inspection lacks its last compliance; a save needs it.
    return { ...stripSystemFields(doc), lastSeconds: 3996000 };
  });

const victimInspectionVersion = () =>
  HUNT_T.run(async (ctx) => {
    const doc = await ctx.db
      .query("inspections")
      .withIndex("uuid", (q) => q.eq("uuid", V.inspection))
      .unique();
    return doc?.version ?? 0;
  });

function extra(
  fn: FunctionReference<Kind>,
  kind: Kind,
  target: string,
  call: Case["call"],
  control = false,
): Case & { control: boolean } {
  return {
    fn: getFunctionName(fn),
    kind,
    target,
    call,
    expected: { refused: "" },
    control,
  };
}
const mgmt = (c: Client, action: string, fields: object) =>
  c.mutation(api.management.execute, sendInB(buildCommand(action, fields)));
const workOrder = (c: Client, command: object) =>
  c.mutation(api.workOrders.save, sendInB(command));
const taskCard = (c: Client, command: object) =>
  c.mutation(api.taskCards.save, sendInB(command));
const costCommand = (c: Client, action: string, fields: object) =>
  c.mutation(api.costs.execute, sendInB(buildCommand(action, fields)));
const adCommand = (c: Client, command: object) =>
  c.mutation(api.airworthiness.save, sendInB(command));
const saveExpiring = (c: Client, item: object) =>
  c.mutation(
    api.expiringItems.save,
    sendInB({ action: "save", requestUuid: crypto.randomUUID(), item }),
  );
const historyOf = (c: Client, entityUuid: string) =>
  c.query(api.auditHistory.page, stampB({ entityUuid, cursor: null, numItems: 50 }));

const M = api.management.execute;
const EXTRA: (Case & { control: boolean })[] = [
  // Identity and replay ids on the attacker's own aircraft.
  extra(api.operations.submit, "mutation", "own flight naming the victim's member as pilot", (c, a, me) =>
    c.mutation(api.operations.submit, {
      operation: stampB({
        kind: "flight" as const,
        uuid: crypto.randomUUID(),
        authorId: me,
        baseVersion: 0,
        input: { ...FLIGHT, aircraftUuid: B_AIRCRAFT, pilotId: ext(a).vera },
      }),
    }),
  ),
  extra(api.operations.submit, "mutation", "own flight under the victim's flight uuid", (c, a, me) =>
    c.mutation(api.operations.submit, {
      operation: { ...buildFlight(me, B_AIRCRAFT), uuid: ext(a).vFlight },
    }),
  ),
  extra(api.operations.submit, "mutation", "own report under the victim's report uuid", (c, a, me) =>
    c.mutation(api.operations.submit, {
      operation: stampB({
        kind: "discrepancy" as const,
        uuid: ext(a).vReport,
        authorId: me,
        aircraftUuid: B_AIRCRAFT,
        description: "Replay of the victim's report id.",
      }),
    }),
  ),
  extra(api.operations.saveDiscrepancyParts, "mutation", "CONTROL own report reserving own stock", (c) =>
    c.mutation(
      api.operations.saveDiscrepancyParts,
      stampB({
        uuid: OWN.discrepancy,
        version: 0,
        payload: JSON.stringify([
          { locationUuid: OWN.location, stockUuid: OWN.stock, quantity: 1 },
        ]),
      }),
    ),
    true,
  ),
  extra(api.operations.saveDiscrepancyParts, "mutation", "own report reserving the victim's stock", (c) =>
    c.mutation(
      api.operations.saveDiscrepancyParts,
      stampB({
        uuid: OWN.discrepancy,
        version: 1,
        payload: JSON.stringify([
          { locationUuid: V.location, stockUuid: V.stock, quantity: 1 },
        ]),
      }),
    ),
  ),
  // Inspections and inventory: own record, one victim id.
  extra(M, "mutation", "CONTROL own inspection saved", async (c) =>
    mgmt(c, "inspection.save", { record: await ownInspection() }), true),
  extra(M, "mutation", "own inspection on the victim's component", async (c) =>
    mgmt(c, "inspection.save", {
      record: { ...(await ownInspection()), componentUuid: V.component },
    }),
  ),
  extra(M, "mutation", "own inspection requiring the victim's stock", async (c) =>
    mgmt(c, "inspection.save", {
      record: {
        ...(await ownInspection()),
        requiredParts: [
          { locationUuid: V.location, stockUuid: V.stock, quantity: 1 },
        ],
      },
    }),
  ),
  extra(M, "mutation", "own inspection citing the victim's manual", async (c, a) =>
    mgmt(c, "inspection.save", {
      record: {
        ...(await ownInspection()),
        manualReference: {
          manualUuid: ext(a).vManual,
          section: "5-10",
          printedPage: "1",
          pdfPage: 1,
        },
      },
    }),
  ),
  extra(M, "mutation", "a new inspection on the victim's aircraft", async (c) =>
    mgmt(c, "inspection.save", {
      record: {
        ...(await ownInspection()),
        uuid: crypto.randomUUID(),
        version: 0,
        aircraftUuid: V.aircraft,
      },
    }),
  ),
  extra(M, "mutation", "completing the victim's inspection", async (c) =>
    mgmt(c, "inspection.complete", {
      uuid: V.inspection,
      version: await victimInspectionVersion(),
      date: "2026-11-01",
      seconds: 4000000,
      cycles: 1,
    }),
  ),
  extra(M, "mutation", "own component installed on the victim's aircraft", async (c) =>
    mgmt(c, "record.save", {
      record: {
        ...(await own("management", byUuid(OWN.component))),
        aircraftUuid: V.aircraft,
      },
    }),
  ),
  extra(M, "mutation", "own component stamped into the victim's program", async (c) =>
    mgmt(c, "record.save", {
      record: {
        ...(await own("management", byUuid(OWN.component))),
        programUuid: PROGRAM_A,
      },
    }),
  ),
  extra(M, "mutation", "own component under the victim's parent component", async (c) =>
    mgmt(c, "record.save", {
      record: {
        ...(await own("management", byUuid(OWN.component))),
        parentComponentUuid: V.component,
      },
    }),
  ),
  extra(M, "mutation", "own requirement moved to the victim's component", async (c) =>
    mgmt(c, "record.save", {
      record: {
        ...(await own("management", byUuid(OWN.requirement))),
        componentUuid: V.component,
      },
    }),
  ),
  extra(M, "mutation", "a new requirement on the victim's component", async (c) =>
    mgmt(c, "record.save", {
      record: {
        ...(await own("management", byUuid(OWN.requirement))),
        uuid: crypto.randomUUID(),
        version: 0,
        componentUuid: V.component,
        aircraftUuid: V.aircraft,
      },
    }),
  ),
  extra(M, "mutation", "a new stock lot at the victim's location", async (c) =>
    mgmt(c, "record.save", {
      record: {
        ...(await own("management", byUuid(OWN.stock))),
        uuid: crypto.randomUUID(),
        version: 0,
        locationUuid: V.location,
      },
    }),
  ),
  extra(M, "mutation", "issuing the victim's stock", async (c) =>
    mgmt(c, "stock.move", {
      uuid: V.stock,
      version: (await own("management", byUuid(V.stock))).version,
      operation: "issue",
      quantity: 1,
    }),
  ),
  // Work orders and job cards.
  extra(api.workOrders.save, "mutation", "CONTROL own work order gains own report", async (c) => {
    const wo = await own("workOrders", onOwnAircraft);
    return workOrder(c, {
      action: "add",
      uuid: wo.uuid,
      version: wo.version,
      source: { kind: "discrepancy", uuid: OWN.discrepancy },
    });
  }, true),
  ...(["inspection", "discrepancy", "componentRequirement", "airworthiness", "manual"] as const).map(
    (kind) =>
      extra(api.workOrders.save, "mutation", `own work order gains the victim's ${kind}`, async (c, a) => {
        const wo = await own("workOrders", onOwnAircraft);
        const uuid = {
          inspection: V.inspection,
          discrepancy: V.discrepancy,
          componentRequirement: V.requirement,
          airworthiness: parsePayload(a.row.airworthiness).uuid,
          manual: a.row.manuals.uuid,
        }[kind];
        return workOrder(c, {
          action: "add",
          uuid: wo.uuid,
          version: wo.version,
          source: { kind, uuid },
        });
      }),
  ),
  extra(api.workOrders.save, "mutation", "own work order over the victim's component", async (c) => {
    const wo = await own("workOrders", onOwnAircraft);
    return workOrder(c, {
      action: "save",
      uuid: wo.uuid,
      version: wo.version,
      fields: wo,
      componentUuids: [V.component],
      tasks: wo.tasks,
    });
  }),
  ...(["inspection", "componentRequirement", "discrepancy", "workOrder"] as const).map((kind) =>
    extra(api.taskCards.save, "mutation", `own job card linked to the victim's ${kind}`, async (c, a) => {
      const card = await own("taskCards", onOwnAircraft);
      const uuid = {
        inspection: V.inspection,
        componentRequirement: V.requirement,
        discrepancy: V.discrepancy,
        workOrder: a.row.workOrders.uuid,
      }[kind];
      return taskCard(c, {
        action: "link",
        uuid: card.uuid,
        version: card.version,
        link: { kind, uuid },
      });
    }),
  ),
  extra(api.taskCards.save, "mutation", "own job card saved on the victim's component", async (c) => {
    const card = await own("taskCards", onOwnAircraft);
    return taskCard(c, {
      action: "save",
      uuid: card.uuid,
      version: card.version,
      fields: { ...card, componentUuid: V.component },
    });
  }),
  ...(["inspectionUuid", "discrepancyUuid", "workOrderUuid", "requirementUuid"] as const).map((field) =>
    extra(api.taskCards.save, "mutation", `own job card saved with the victim's ${field}`, async (c, a) => {
      const card = await own("taskCards", onOwnAircraft);
      const uuid = {
        inspectionUuid: V.inspection,
        discrepancyUuid: ext(a).vReport,
        workOrderUuid: a.row.workOrders.uuid,
        requirementUuid: V.requirement,
      }[field];
      return taskCard(c, {
        action: "save",
        uuid: card.uuid,
        version: card.version,
        fields: { ...card, [field]: uuid, ...(field === "workOrderUuid" ? { workTaskUuid: "" } : {}) },
      });
    }),
  ),
  extra(api.taskCards.save, "mutation", "CONTROL own job card linked to own report", async (c) => {
    const card = await own("taskCards", onOwnAircraft);
    return taskCard(c, {
      action: "link",
      uuid: card.uuid,
      version: card.version,
      link: { kind: "discrepancy", uuid: OWN.discrepancy },
    });
  }, true),
  // Parts and purchasing.
  extra(api.partsRequests.execute, "mutation", "CONTROL a parts request for own inspection", (c) =>
    c.mutation(
      api.partsRequests.execute,
      sendInB({
        kind: "save",
        requestUuid: crypto.randomUUID(),
        draft: draftPartsRequest(OWN.inspection),
      }),
    ),
    true,
  ),
  extra(api.partsRequests.execute, "mutation", "a parts request for the victim's inspection", (c) =>
    c.mutation(
      api.partsRequests.execute,
      sendInB({
        kind: "save",
        requestUuid: crypto.randomUUID(),
        draft: draftPartsRequest(V.inspection),
      }),
    ),
  ),
  extra(api.purchaseOrders.execute, "mutation", "CONTROL own draft order re-saved", async (c) => {
    const po = await own("purchaseOrders", (p) => JSON.stringify(p).includes(OWN.stock));
    return c.mutation(
      api.purchaseOrders.execute,
      sendInB({ kind: "save", requestUuid: crypto.randomUUID(), drafts: [po] }),
    );
  }, true),
  extra(api.purchaseOrders.execute, "mutation", "own draft order delivering to the victim's stock and location", async (c) => {
    const po = await own("purchaseOrders", (p) => JSON.stringify(p).includes(OWN.stock));
    const lines = (po.lines as Payload[]).map((l) => ({
      ...l,
      stockUuid: V.stock,
      locationUuid: V.location,
    }));
    return c.mutation(
      api.purchaseOrders.execute,
      sendInB({
        kind: "save",
        requestUuid: crypto.randomUUID(),
        drafts: [{ ...po, lines }],
      }),
    );
  }),
  extra(api.purchaseOrders.execute, "mutation", "own draft order for the victim's aircraft, inspection and work order", async (c, a) => {
    const po = await own("purchaseOrders", (p) => JSON.stringify(p).includes(OWN.stock));
    const lines = (po.lines as Payload[]).map((l) => ({
      ...l,
      aircraftUuid: V.aircraft,
      inspectionUuid: V.inspection,
      workOrderUuid: a.row.workOrders.uuid,
    }));
    return c.mutation(
      api.purchaseOrders.execute,
      sendInB({
        kind: "save",
        requestUuid: crypto.randomUUID(),
        drafts: [{ ...po, lines }],
      }),
    );
  }),
  // Costs.
  extra(api.costs.execute, "mutation", "CONTROL a budget for own aircraft", (c) =>
    costCommand(c, "budget.set", { aircraftUuid: B_AIRCRAFT, year: 2026, amountCents: 100 }), true),
  extra(api.costs.execute, "mutation", "a budget for the victim's aircraft", (c) =>
    costCommand(c, "budget.set", { aircraftUuid: V.aircraft, year: 2026, amountCents: 100 }),
  ),
  extra(api.costs.execute, "mutation", "labor on the victim's work order", (c, a) =>
    costCommand(c, "labor.add", {
      workOrderUuid: a.row.workOrders.uuid,
      entry: { uuid: crypto.randomUUID(), date: "2026-01-01", technician: "X", minutes: 60 },
    }),
  ),
  extra(api.costs.execute, "mutation", "the victim's stock priced on own work order", async (c) => {
    const wo = await own("workOrders", onOwnAircraft);
    return costCommand(c, "part.unitCost", {
      workOrderUuid: wo.uuid,
      stockUuid: V.stock,
      unitCents: 1,
    });
  }),
  // Airworthiness directives.
  extra(api.airworthiness.save, "mutation", "CONTROL own AD saved", async (c) =>
    adCommand(c, { kind: "save", record: await own("airworthiness", onOwnAircraft) }), true),
  extra(api.airworthiness.save, "mutation", "own AD moved to the victim's component", async (c) =>
    adCommand(c, {
      kind: "save",
      record: {
        ...(await own("airworthiness", onOwnAircraft)),
        componentUuid: V.component,
      },
    }),
  ),
  extra(api.airworthiness.save, "mutation", "a new AD on the victim's aircraft", async (c) =>
    adCommand(c, {
      kind: "save",
      record: {
        ...(await own("airworthiness", onOwnAircraft)),
        uuid: crypto.randomUUID(),
        version: 0,
        aircraftUuid: V.aircraft,
      },
    }),
  ),
  extra(api.airworthiness.save, "mutation", "ADs imported onto the victim's aircraft", async (c) => {
    const ad = await own("airworthiness", onOwnAircraft);
    const source = { ...(ad.source as object), number: "2099-01-01" };
    return adCommand(c, {
      kind: "import",
      aircraftUuid: V.aircraft,
      entries: [{ source, componentUuid: "" }],
    });
  }),
  // Checklists, plans, templates, expiring dates.
  extra(api.checklists.save, "mutation", "own checklist moved to the victim's aircraft", async (c) => {
    const record = await own("checklists", onOwnAircraft);
    return c.mutation(
      api.checklists.save,
      sendInB({
        record: { ...record, aircraftUuid: V.aircraft },
        baseVersion: record.version,
      }),
    );
  }),
  extra(api.flightPlans.save, "mutation", "a new plan on the victim's aircraft", async (c) => {
    const plan = await own("flightPlans", onOwnAircraft);
    return c.mutation(
      api.flightPlans.save,
      sendInB({
        plan: { ...plan, uuid: crypto.randomUUID(), version: 0, aircraftUuid: V.aircraft },
        baseVersion: 0,
      }),
    );
  }),
  extra(api.inspectionTemplates.activate, "mutation", "own template activated on the victim's aircraft", async (c) => {
    const template = await own("inspectionTemplates", (p) => p.programUuid === PROGRAM_B);
    return c.mutation(
      api.inspectionTemplates.activate,
      sendInB({
        templateUuid: template.uuid,
        templateVersion: template.version,
        targetUuid: V.aircraft,
        mode: "recurring",
        description: "Annual",
        reviewed: true,
      }),
    );
  }),
  extra(api.inspectionTemplates.activate, "mutation", "own template activated on the victim's component", async (c) => {
    const template = await own("inspectionTemplates", (p) => p.programUuid === PROGRAM_B);
    return c.mutation(
      api.inspectionTemplates.activate,
      sendInB({
        templateUuid: template.uuid,
        templateVersion: template.version,
        targetUuid: V.component,
        mode: "recurring",
        description: "Annual",
        reviewed: true,
      }),
    );
  }),
  extra(api.componentTemplates.apply, "mutation", "own component template applied to the victim's aircraft", (c, a) =>
    c.mutation(
      api.componentTemplates.apply,
      sendInB({
        templateUuid: ext(a).ownComponentTemplate.uuid,
        version: ext(a).ownComponentTemplate.version,
        aircraftUuid: V.aircraft,
        rowIds: ["1"],
      }),
    ),
  ),
  extra(api.expiringItems.save, "mutation", "CONTROL an expiring date for own aircraft", (c) =>
    saveExpiring(c, {
      uuid: crypto.randomUUID(),
      programUuid: PROGRAM_B,
      aircraftUuid: B_AIRCRAFT,
      kind: "insurance",
      label: "Own hull policy",
      expiresOn: "2030-01-01",
      version: 0,
    }),
    true,
  ),
  extra(api.expiringItems.save, "mutation", "an expiring date for the victim's aircraft", (c) =>
    saveExpiring(c, {
      uuid: crypto.randomUUID(),
      programUuid: PROGRAM_B,
      aircraftUuid: V.aircraft,
      kind: "insurance",
      label: "Their hull policy",
      expiresOn: "2030-01-01",
      version: 0,
    }),
  ),
  extra(api.expiringItems.save, "mutation", "a new expiring date stamped into the victim's program", (c) =>
    saveExpiring(c, {
      uuid: crypto.randomUUID(),
      programUuid: PROGRAM_A,
      kind: "insurance",
      label: "Planted",
      expiresOn: "2030-01-01",
      version: 0,
    }),
  ),
  extra(api.fleet.save, "mutation", "own aircraft stamped into the victim's program", async (c) => {
    const aircraft = await HUNT_T.run(async (ctx) =>
      stripSystemFields(
        (await ctx.db
          .query("aircraft")
          .withIndex("uuid", (q) => q.eq("uuid", B_AIRCRAFT))
          .unique())!,
      ),
    );
    return c.mutation(
      api.fleet.save,
      sendInB(
        buildCommand("aircraft.save", {
          aircraft: { ...aircraft, programUuid: PROGRAM_A },
        }),
      ),
    );
  }),
  // History, by ids the attacker could learn.
  extra(api.auditHistory.page, "query", "the victim's expiring date history", (c) =>
    historyOf(c, V_EXPIRING)),
  extra(api.auditHistory.page, "query", "the victim's purchase order history", (c, a) =>
    historyOf(c, ext(a).vPo)),
  extra(api.auditHistory.page, "query", "the victim's group history", (c, a) =>
    historyOf(c, ext(a).vGroup)),
  extra(api.auditHistory.page, "query", "the victim's member history", (c, a) =>
    historyOf(c, ext(a).vera)),
  extra(api.auditHistory.page, "query", "the victim program's own history", (c) =>
    historyOf(c, PROGRAM_A)),
  extra(api.auditHistory.page, "query", "the victim's component history", (c) =>
    historyOf(c, V.component)),
  extra(api.auditHistory.page, "query", "the victim's aircraft history from a cursor", (c) =>
    c.query(
      api.auditHistory.page,
      stampB({ aircraftUuid: V.aircraft, cursor: String(Date.now() + 1e6), numItems: 50 }),
    ),
  ),
  extra(api.auditHistory.summary, "query", "the victim program's week", (c) =>
    c.query(api.auditHistory.summary, stampA({ from: "2026-01-01", to: "2030-12-31" })),
  ),
  // People.
  extra(api.programUsers.updateAccess, "mutation", "the victim's member, given own group", (c, a) =>
    c.mutation(
      api.programUsers.updateAccess,
      stampB({ userId: ext(a).vera, groupIds: [ext(a).ownGroup], remove: false }),
    ),
  ),
  extra(api.programUsers.updateAccess, "mutation", "the victim's member, removed", (c, a) =>
    c.mutation(
      api.programUsers.updateAccess,
      stampB({ userId: ext(a).vera, groupIds: [], remove: true }),
    ),
  ),
  extra(api.pushSubscriptions.unsubscribe, "mutation", "the victim's device, unsubscribed", (c) =>
    c.mutation(api.pushSubscriptions.unsubscribe, stampB({ endpoint: V_ENDPOINT })),
  ),
  extra(api.alerts.markRead, "mutation", "own reads, replacing all (victim's reads must stay)", (c) =>
    c.mutation(api.alerts.markRead, stampB({ keys: ["own-key"], all: true })),
    true,
  ),
];

async function seedSplitWorld(role: HuntRole) {
  const t = convexTest(schema, modules);
  await seedSampleProgram(t);
  const rootSubject = await t.run(async (ctx) => {
    const root = (await ctx.db
      .query("users")
      .withIndex("email", (q) => q.eq("email", ROOT_EMAIL))
      .unique())!;
    const session = await ctx.db.insert("authSessions", {
      userId: root._id,
      expirationTime: Date.now() + SESSION_MS,
    });
    const program = (await ctx.db.query("programs").first())!;
    await ctx.db.insert("programs", {
      ...stripSystemFields(program),
      uuid: PROGRAM_A,
      name: "Victim program",
    });
    return `${root._id}|${session}`;
  });
  const root = t.withIdentity({ subject: rootSubject });
  await root.mutation(api.defaultGroups.initialize, { programUuid: PROGRAM_A });
  const transfers: Record<string, Outcome> = {};
  for (const [kind, uuid] of [
    ["aircraft", "sample-aircraft-3"],
    ["aircraft", "sample-aircraft-4"],
    ["component", "sample-spare-3"],
    ["component", "sample-spare-4"],
  
  ] as const)
    transfers[`${kind} ${uuid}`] = await settle(
      root.mutation(api.programs.transfer, {
        programUuid: PROGRAM_B,
        kind,
        uuid,
        destination: PROGRAM_A,
        reason: "Split the fleet between two programs.",
      }),
    );
  const people = await t.run(async (ctx) => {
    const groupsOf = (programUuid: string) =>
      ctx.db
        .query("groups")
        .withIndex("program", (q) => q.eq("programUuid", programUuid))
        .collect();
    const named = (groups: Doc<"groups">[], name: string) =>
      groups.find((g) => g.name === name)!._id;
    const victimGroups = await groupsOf(PROGRAM_A);
    const ownGroups = await groupsOf(PROGRAM_B);
    const vGroup = named(victimGroups, "Program managers");
    const vera = await addUser(ctx, ALICE_EMAIL, [vGroup], PROGRAM_A);
    const ownGroup = named(ownGroups, HUNT_GROUP[role]);
    const groupIds =
      role === "both" ? [ownGroup, named(victimGroups, "Observers")] : [ownGroup];
    const attacker = await addUser(ctx, "attacker@example.test", groupIds, PROGRAM_B);
    const helper = await addUser(ctx, "helper@example.test", [named(ownGroups, "Program managers")], PROGRAM_B);
    await addVictimFiles(ctx, vera.id);
    return { vera, attacker, helper, vGroup, ownGroup };
  });
  const vera = t.withIdentity(people.vera);
  const victimWrites = await addVictimRecords(t, vera);
  const template = { name: "Own engines", make: "Cessna", model: "172S", rows: [{ id: "1", componentType: "Engine", partNumber: "P1", model: "172S" }] };
  const ownTemplateUuid = crypto.randomUUID();
  await t.withIdentity(people.helper).mutation(
    api.componentTemplates.save,
    sendInB({ ...template, uuid: ownTemplateUuid, version: 0 }),
  );
  const a = await t.run(async (ctx) => {
    const victim = await readVictim(ctx, people.vera.id);
    const templates = await ctx.db.query("componentTemplates").collect();
    return {
      ...victim,
      vera: people.vera.id,
      ownGroup: people.ownGroup,
      vGroup: people.vGroup,
      vPo: victim.row.purchaseOrders.uuid,
      ownComponentTemplate: templates.map(parsePayload).find((p) => p.uuid === ownTemplateUuid)!,
      vFlight: V_FLIGHT,
      vReport: V_REPORT,
      vManual: V_MANUAL,
    };
  });
  return {
    t,
    a: a as unknown as ProgramA,
    victimIds: a.victimIds,
    victimRowKeys: a.victimRowKeys,
    me: people.attacker.id,
    attacker: t.withIdentity(people.attacker),
    vera,
    root,
    transfers,
    victimWrites,
  };
}

// What the transfer does not carry, filed for the victim directly.
async function addVictimFiles(
  ctx: MutationCtx & { storage: StorageActionWriter },
  vera: Id<"users">,
) {
  const file = { type: PDF_TYPE, size: PDF.length, uploadedAt: Date.now() };
  const order = (await ctx.db
    .query("workOrders")
    .withIndex("aircraft", (q) => q.eq("aircraftUuid", V_AIRCRAFT))
    .first())!;
  await ctx.db.insert("certificationFiles", {
    userId: vera, kind: "ap", name: "certificate.pdf", ...file,
    storageId: await storePdf(ctx),
  });
  await ctx.db.insert("aircraftFiles", {
    aircraftUuid: V_AIRCRAFT, category: "form-337", name: "337.pdf", ...file,
    storageId: await storePdf(ctx),
  });
  await ctx.db.insert("aircraftFiles", {
    aircraftUuid: V_AIRCRAFT, category: "logbook-page", linkedKind: "flight",
    linkedUuid: V.flight, name: "line.pdf", ...file,
    storageId: await storePdf(ctx),
  });
  await ctx.db.insert("aircraftFiles", {
    aircraftUuid: V_AIRCRAFT, category: "logbook-page", linkedKind: "work-order",
    linkedUuid: order.uuid, name: "page.pdf", ...file,
    storageId: await storePdf(ctx),
  });
  await ctx.db.insert("aircraftPhotos", {
    aircraftUuid: V_AIRCRAFT, storageId: await storePdf(ctx),
  });
  await ctx.db.insert("authAccounts", {
    userId: vera, provider: "google", providerAccountId: "vera",
  });
  const name = ADDRESS.organization;
  await ctx.db.insert("savedAddresses", stampA({
    uuid: ADDRESS_UUID, version: 1, name, nameKey: name.toLowerCase(), address: ADDRESS,
  }));
  await ctx.db.insert("pushSubscriptions", {
    userId: vera, programUuid: PROGRAM_A, endpoint: V_ENDPOINT,
    keys: PUSH_SUBSCRIPTION.keys, createdAt: Date.now(), lastSeenAt: Date.now(),
  });
  await ctx.db.insert("alertReads", {
    userId: vera, programUuid: PROGRAM_A, key: "victim-key", readAt: Date.now(),
  });
  await ctx.db.insert("alertDeliveries", {
    userId: vera, programUuid: PROGRAM_A, key: "victim-key", sentAt: Date.now(), channel: "push",
  });
  // Purchase orders and inspection templates stay with the source program
  // on a transfer, so the victim gets its own copies.
  const po = (await ctx.db.query("purchaseOrders").collect()).find((p) => p.payload.includes("sample-stock-3"))!;
  const poUuid = crypto.randomUUID();
  await ctx.db.insert("purchaseOrders", {
    uuid: poUuid, programUuid: PROGRAM_A,
    payload: JSON.stringify({ ...parsePayload(po), uuid: poUuid, programUuid: PROGRAM_A, number: "VICTIM-PO-1" }),
  });
  await ctx.db.insert("poFiles", {
    poUuid, programUuid: PROGRAM_A, name: "victim-quote.pdf", ...file,
    storageId: await storePdf(ctx),
  });
  await ctx.db.insert("manuals", {
    uuid: V_MANUAL, aircraftUuid: V_AIRCRAFT, title: "Victim manual", documentNumber: "",
    revision: "1", revisionDate: "", filename: "victim.pdf", size: PDF.length, pageCount: 1,
    storageId: await storePdf(ctx), uploadedAt: Date.now(), uploadedBy: vera,
  });
  const template = (await ctx.db.query("inspectionTemplates").first())!;
  const templateUuid = crypto.randomUUID();
  await ctx.db.insert("inspectionTemplates", {
    uuid: templateUuid, programUuid: PROGRAM_A,
    payload: JSON.stringify({ ...parsePayload(template), uuid: templateUuid, programUuid: PROGRAM_A, name: "VICTIM template" }),
  });
}

// Vera writes these through the app, so their stored shape is the real one.
async function addVictimRecords(t: Convex, vera: Client) {
  const sendInA = (payload: unknown) => stampA({ payload: JSON.stringify(payload) });
  const row = { id: "1", componentType: "Engine", partNumber: "P1", model: "182T" };
  const out: Record<string, Outcome> = {};
  out.componentTemplate = await settle(vera.mutation(
    api.componentTemplates.save,
    sendInA({ name: "Victim engines", make: "Cessna", model: "182T", rows: [row], uuid: crypto.randomUUID(), version: 0 }),
  ));
  out.partsRequest = await settle(vera.mutation(
    api.partsRequests.execute,
    sendInA({ kind: "save", requestUuid: crypto.randomUUID(), draft: draftPartsRequest(V.inspection) }),
  ));
  out.manualUpload = await settle(vera.mutation(api.manuals.beginUpload, {
    ...sendInA(describeManual(V_AIRCRAFT)), sha256: SHA256,
  }));
  out.expiring = await settle(vera.mutation(
    api.expiringItems.save,
    sendInA({ action: "save", item: {
      uuid: V_EXPIRING, programUuid: PROGRAM_A, aircraftUuid: V_AIRCRAFT, kind: "insurance",
      label: "Victim hull policy", expiresOn: "2030-01-01", version: 0,
    } }),
  ));
  out.budget = await settle(vera.mutation(
    api.costs.execute,
    sendInA(buildCommand("budget.set", { aircraftUuid: V_AIRCRAFT, year: 2026, amountCents: 5000000 })),
  ));
  out.adSave = await settle((async () => {
    const ad = await t.run(async (ctx) => parsePayload((await ctx.db
      .query("airworthiness")
      .withIndex("aircraft", (q) => q.eq("aircraftUuid", V_AIRCRAFT))
      .first())!));
    return vera.mutation(api.airworthiness.save, sendInA({ kind: "save", record: ad }));
  })());
  // The sample locations cannot move while its purchase orders deliver to
  // them, so the victim gets a location and a stock lot of its own.
  const [location, stock] = await t.run(async (ctx) => {
    const rows = await ctx.db.query("management").collect();
    const find = (uuid: string) => parsePayload(rows.find((r) => r.uuid === uuid)!);
    return [find(OWN.location), find(OWN.stock)];
  });
  const saveRecord = (record: object) =>
    settle(vera.mutation(api.management.execute, sendInA(buildCommand("record.save", { record }))));
  out.location = await saveRecord({ ...location, uuid: V.location, version: 0, programUuid: PROGRAM_A, name: "Victim hangar" });
  out.stock = await saveRecord({ ...stock, uuid: V.stock, version: 0, programUuid: PROGRAM_A, locationUuid: V.location, reservedQuantity: 0 });
  await t.run(async (ctx) => {
    await ctx.db.insert("inventoryFiles", {
      stockUuid: V.stock, name: "victim-8130.pdf", type: PDF_TYPE, size: PDF.length,
      uploadedAt: Date.now(), storageId: await storePdf(ctx),
    } as never);
  });
  const veraId = await t.run(async (ctx) => (await ctx.db
    .query("users")
    .withIndex("email", (q) => q.eq("email", ALICE_EMAIL))
    .unique())!._id);
  out.report = await settle(vera.mutation(api.operations.submit, {
    operation: stampA({
      kind: "discrepancy" as const, uuid: V_REPORT, authorId: veraId,
      aircraftUuid: V_AIRCRAFT, description: "Victim's open report.",
    }),
  }));
  out.flight = await settle(vera.mutation(api.operations.submit, {
    operation: stampA({
      kind: "flight" as const, uuid: V_FLIGHT, authorId: veraId, baseVersion: 0,
      input: { ...FLIGHT, aircraftUuid: V_AIRCRAFT, pilotId: veraId },
    }),
  }));
  return out;
}

// The victim's first row of every table, and every id that names a victim
// record. A row is the victim's by its aircraft, else its program column,
// else because it names a victim record already found.
async function readVictim(ctx: MutationCtx, vera: Id<"users">) {
  const victimAircraft = new Set(["sample-aircraft-3", "sample-aircraft-4"]);
  const names = new Set<string>([vera, ...victimAircraft]);
  const all: { table: TableNames; row: Record<string, unknown> }[] = [];
  for (const table of TABLES)
    for (const row of await ctx.db.query(table).collect())
      all.push({ table, row: row as Record<string, unknown> });
  const SHARED = new Set(["audit", "programs", "users", "authSessions", "rateLimits", "memberships", "commandRequests", "transferredAudit"]);
  const victimRows = new Map<string, { table: TableNames; row: Record<string, unknown> }>();
  for (let pass = 0; pass < 4; pass++)
    for (const entry of all) {
      const { table, row } = entry;
      if (SHARED.has(table) || victimRows.has(row._id as string)) continue;
      const text = JSON.stringify(row);
      // The aircraft decides first: a transfer leaves the program column of
      // AD and cost rows on the source program until someone saves them.
      const mine =
        typeof row.aircraftUuid === "string" && row.aircraftUuid
          ? victimAircraft.has(row.aircraftUuid)
          : "programUuid" in row && row.programUuid !== undefined
            ? row.programUuid === PROGRAM_A
            : [...names].some((n) => text.includes(`"${n}"`));
      if (!mine) continue;
      victimRows.set(row._id as string, entry);
      names.add(row._id as string);
      if (typeof row.uuid === "string") names.add(row.uuid);
    }
  const first = (table: TableNames) =>
    table === "programs"
      ? all.find((e) => e.table === table && e.row.uuid === PROGRAM_A)?.row
      : table === "users"
        ? all.find((e) => e.table === table && e.row._id === vera)?.row
        : [...victimRows.values()].find((e) => e.table === table)?.row;
  const management = [...victimRows.values()]
    .filter((e) => e.table === "management")
    .map((e) => parsePayload(e.row as { payload: string }));
  const groups = [...victimRows.values()].filter((e) => e.table === "groups");
  const recordUuids = [...victimRows.values()]
    .flatMap((e) => (typeof e.row.uuid === "string" ? [e.row.uuid] : []));
  return {
    row: Object.fromEntries(TABLES.map((table) => [table, first(table)])) as FirstRows,
    alice: vera,
    adminGroup: groups.find((g) => g.row.programAdmin)!.row._id as Id<"groups">,
    stock: management.find((r) => r.kind === "stock") ?? management[0],
    recordUuids,
    victimIds: [...names],
    victimRowKeys: [...victimRows.values()].map((e) => `${e.table}/${e.row._id as string}`),
    victimTables: Object.fromEntries(
      TABLES.map((table) => [table, [...victimRows.values()].filter((e) => e.table === table).length]),
    ),
  };
}

const HUNT_OUT = process.env.HUNT_OUT ?? "";

describe.each(HUNT_ROLES)("hunt: %s of the sample program against the split-off program", (role) => {
  it("reads, writes, links and reveals nothing of the victim's", async () => {
    const world = await seedSplitWorld(role);
    HUNT_T = world.t;
    const baselineView = JSON.stringify(
      await world.attacker.query(api.operations.snapshot, {}),
    );
    const known = new Set(world.victimIds.filter((id) => baselineView.includes(id)));
    const secret = world.victimIds.filter((id) => !known.has(id));
    const before = await dumpDatabase(world.t);
    const outcomes: Record<string, string> = {};
    const leaks: string[] = [];
    const allowed: string[] = [];
    // A member of both may switch to the victim program; that case would
    // move every later call into it.
    const cases = [...CASES, ...EXTRA].filter(
      (c) => !(role === "both" && c.outsiderOnly),
    );
    for (const c of cases) {
      const key = `${c.kind} ${c.fn} :: ${c.target}`;
      const outcome = await settle(
        (async () => c.call(world.attacker, world.a, world.me))(),
      );
      const text = JSON.stringify(outcome);
      outcomes[key] = text.slice(0, 300);
      const control = "control" in c && c.control === true;
      const seen = secret.filter((id) => text.includes(id));
      if (seen.length && !control) leaks.push(`${key} => ${seen.join(",")}`);
      if (!("refused" in outcome) && c.kind !== "query" && !control) allowed.push(key);
    }
    const after = await dumpDatabase(world.t);
    const changed = listChanges(before, after);
    const victimChanged = changed.filter((key) => world.victimRowKeys.includes(key));
    const linked = changed
      .filter((key) => !world.victimRowKeys.includes(key) && after[key])
      .filter((key) => world.victimIds.some((id) => after[key].includes(id) && !(before[key] ?? "").includes(id)))
      .map((key) => `${key}: ${after[key].slice(0, 400)}`);
    const report = {
      role,
      transfers: world.transfers,
      victimWrites: world.victimWrites,
      victimTables: (world.a as unknown as { victimTables: object }).victimTables,
      knownToAttacker: [...known],
      leaks,
      victimChanged,
      linked,
      allowedWrites: allowed,
      outcomes,
    };
    if (HUNT_OUT) {
      const { writeFileSync } = await import("node:fs");
      writeFileSync(`${HUNT_OUT}/acl-isolation-${role}.json`, JSON.stringify(report, null, 1));
    }
    expect({ leaks, victimChanged, linked }).toEqual({ leaks: [], victimChanged: [], linked: [] });
  }, 300_000);
});
