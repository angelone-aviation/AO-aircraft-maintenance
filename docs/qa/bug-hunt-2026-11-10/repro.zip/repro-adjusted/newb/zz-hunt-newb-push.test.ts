/**
 * Responsibility: Bug-hunt 2026-11-10 repros (area newb) for Web Push
 *   subscriptions and system-wide expiring dates: each test asserts the
 *   CORRECT behaviour and fails today.
 * Layer: Test. convex-test suite with stubbed Resend and push services.
 * Dependencies: convex/push.ts, convex/pushSubscriptions.ts,
 *   convex/urgentAlerts.ts, convex/alerts.ts, tests/fixtures/alertProgram.ts.
 */
import { afterEach, expect, it, vi } from "vitest";
import { api, internal } from "./_generated/api";
import { toBase64Url } from "./webPushProtocol";
import {
  DEMO_PROGRAM,
  OTHER_PROGRAM,
  seedAlertProgram,
  sentEmails,
  stubResend,
  type AlertWorld,
} from "../tests/fixtures/alertProgram";

const KEYS = {
  p256dh:
    "BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4",
  auth: "BTBZMqHH6r4Tts7J_aSIgg",
};
const SUBSCRIPTION = {
  programUuid: DEMO_PROGRAM,
  endpoint: "https://fcm.googleapis.com/send/admin-phone",
  keys: KEYS,
};
const SYSTEM_UUID = "33333333-3333-4333-8333-333333333333";

afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
  vi.useRealTimers();
});

async function stubVapid() {
  const pair = await crypto.subtle.generateKey(
    { name: "ECDSA", namedCurve: "P-256" },
    true,
    ["sign", "verify"],
  );
  const raw = new Uint8Array(
    await crypto.subtle.exportKey("raw", pair.publicKey),
  );
  const jwk = await crypto.subtle.exportKey("jwk", pair.privateKey);
  vi.stubEnv("VAPID_PUBLIC_KEY", toBase64Url(raw));
  vi.stubEnv("VAPID_PRIVATE_KEY", jwk.d!);
  vi.stubEnv("VAPID_SUBJECT", "mailto:alerts@example.test");
}

function stubPushService(status = 201) {
  const request = vi
    .fn<typeof fetch>()
    .mockImplementation(async () => new Response(null, { status }));
  vi.stubGlobal("fetch", request);
  return request;
}

async function checkProgram(world: AlertWorld, programUuid = DEMO_PROGRAM) {
  const result = await world.t.action(internal.urgentAlerts.sendImmediate, {
    programUuid,
  });
  await world.t.finishAllScheduledFunctions(vi.runAllTimers);
  return result;
}

async function systemAdmin(world: AlertWorld, groupIds: string[] = []) {
  const made = await world.t.run(async (ctx) => {
    const userId = await ctx.db.insert("users", {
      active: true,
      isAdmin: true,
      name: "root",
      email: "root@example.test",
      groupIds: groupIds as never,
      activeProgramUuid: DEMO_PROGRAM,
      emailAlerts: true,
      urgentAlertEmails: true,
    });
    const session = await ctx.db.insert("authSessions", {
      userId,
      expirationTime: Date.now() + 86_400_000,
    });
    return { userId, identity: { subject: `${userId}|${session}` } };
  });
  await world.t.mutation(internal.memberships.backfill, {});
  return { ...made, client: world.t.withIdentity(made.identity) };
}

const saveSystemDate = (client: AlertWorld["a"]) =>
  client.mutation(api.expiringItems.save, {
    programUuid: DEMO_PROGRAM,
    payload: JSON.stringify({
      action: "save",
      item: {
        uuid: SYSTEM_UUID,
        kind: "secret",
        label: "Entra client secret",
        expiresOn: "2020-01-01",
        version: 0,
      },
    }),
  });

it("NB-5: refuses a push endpoint that is not a public push service", async () => {
  const { a } = await seedAlertProgram();
  for (const endpoint of [
    "https://127.0.0.1:8443/admin",
    "https://localhost/internal",
    "https://169.254.169.254/latest/meta-data/",
    "https://10.0.0.5/",
    "https://[::1]/",
    "https://user:secret@intranet.example.test/hook",
  ])
    await expect(
      a.mutation(api.pushSubscriptions.subscribe, { ...SUBSCRIPTION, endpoint }),
      endpoint,
    ).rejects.toThrow();
});

it("NB-5b: the server never POSTs to a member-chosen internal address", async () => {
  const world = await seedAlertProgram();
  vi.useFakeTimers();
  await stubVapid();
  const endpoint = "https://169.254.169.254/latest/meta-data/";
  await world.a
    .mutation(api.pushSubscriptions.subscribe, { ...SUBSCRIPTION, endpoint })
    .catch(() => undefined);
  const request = stubPushService();
  await checkProgram(world);
  expect(request.mock.calls.map(([url]) => String(url))).toEqual([]);
});

it("NB-6: a device stops receiving a member's alerts once their sessions have ended", async () => {
  const world = await seedAlertProgram();
  vi.useFakeTimers();
  await stubVapid();
  await world.a.mutation(api.pushSubscriptions.subscribe, SUBSCRIPTION);
  // The member signs out on the device, or an administrator ends their
  // sessions because the phone was lost: no session is left.
  await world.t.run(async (ctx) => {
    for (const s of await ctx.db.query("authSessions").collect())
      if (s.userId === world.ids.a.userId) await ctx.db.delete(s._id);
  });
  const request = stubPushService();
  await checkProgram(world);
  expect(request.mock.calls.map(([url]) => String(url))).toEqual([]);
});

it("NB-7: a system administrator outside every group is emailed an expired system-wide date", async () => {
  const world = await seedAlertProgram();
  vi.useFakeTimers();
  const root = await systemAdmin(world);
  const request = stubResend();
  await saveSystemDate(root.client);
  await world.t.finishAllScheduledFunctions(vi.runAllTimers);
  await world.t.action(internal.urgentAlerts.daily, {});
  await world.t.finishAllScheduledFunctions(vi.runAllTimers);
  await world.t.action(internal.alerts.sendDigests, {});
  const mine = sentEmails(request).filter((e) =>
    e.to.includes("root@example.test"),
  );
  expect(mine.map((e) => e.text).join("\n")).toContain(
    "Entra client secret expired on 2020-01-01",
  );
});

it("NB-8: an expired system-wide date is emailed once, not once per Flight Program", async () => {
  const world = await seedAlertProgram();
  vi.useFakeTimers();
  const groupIds = await world.t.run(async (ctx) =>
    (await ctx.db.query("groups").collect())
      .filter((g) => g.programAdmin)
      .map((g) => g._id),
  );
  const root = await systemAdmin(world, groupIds);
  const request = stubResend();
  await saveSystemDate(root.client);
  await world.t.finishAllScheduledFunctions(vi.runAllTimers);
  await world.t.action(internal.urgentAlerts.daily, {});
  await world.t.finishAllScheduledFunctions(vi.runAllTimers);
  const mentions = sentEmails(request).filter(
    (e) =>
      e.to.includes("root@example.test") &&
      e.text.includes("Entra client secret expired"),
  );
  expect(mentions.map((e) => e.subject)).toHaveLength(1);
  expect(OTHER_PROGRAM).toBe("other-program");
});

it("NB-2 (push): an urgent alert that cleared and came back is pushed again", async () => {
  const world = await seedAlertProgram();
  vi.useFakeTimers();
  await stubVapid();
  const setProfile = (operationalStatus: "grounded" | "airworthy") =>
    world.t.run(async (ctx) => {
      for (const i of await ctx.db.query("inspections").collect())
        await ctx.db.patch(i._id, { dueDate: "2999-01-01" });
      const a = (await ctx.db.query("aircraft").collect()).find(
        (x) => x.uuid === world.ids.aircraftUuid,
      )!;
      await ctx.db.patch(a._id, { operationalStatus });
    });
  await world.a.mutation(api.pushSubscriptions.subscribe, SUBSCRIPTION);
  const request = stubPushService();
  await setProfile("grounded");
  expect(await checkProgram(world)).toMatchObject({ pushed: 1 });
  await setProfile("airworthy");
  expect(await checkProgram(world)).toMatchObject({ pushed: 0 });
  await setProfile("grounded");
  expect(await checkProgram(world)).toMatchObject({ pushed: 1 });
  expect(request).toHaveBeenCalledTimes(2);
});
