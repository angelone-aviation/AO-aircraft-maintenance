/**
 * Responsibility: Bug-hunt 2026-11-10 repros SE-1 and SE-2 (push endpoint as
 *   a server-side request forgery vector; subscriptions outliving the session).
 * Layer: Test. convex-test; asserts the CORRECT behaviour, so it fails today.
 * Dependencies: convex/pushSubscriptions.ts, convex/push.ts,
 *   convex/urgentAlerts.ts, tests/fixtures/alertProgram.ts.
 *
 * Run: cp to convex/ then `npx vitest run convex/zz-hunt-sec-push.test.ts`.
 */
import { afterEach, expect, it, vi } from "vitest";
import { api, internal } from "./_generated/api";
import { toBase64Url } from "./webPushProtocol";
import { DEMO_PROGRAM, seedAlertProgram } from "../tests/fixtures/alertProgram";

const KEYS = {
  p256dh:
    "BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4",
  auth: "BTBZMqHH6r4Tts7J_aSIgg",
};
const sub = (endpoint: string) => ({
  programUuid: DEMO_PROGRAM,
  endpoint,
  keys: KEYS,
});

afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
  vi.useRealTimers();
});

async function stubVapid() {
  const pair = await crypto.subtle.generateKey(
    { name: "ECDSA", namedCurve: "P-256" },
    true,
    ["sign", "verify"],
  );
  const raw = new Uint8Array(
    await crypto.subtle.exportKey("raw", pair.publicKey),
  );
  const jwk = await crypto.subtle.exportKey("jwk", pair.privateKey);
  vi.stubEnv("VAPID_PUBLIC_KEY", toBase64Url(raw));
  vi.stubEnv("VAPID_PRIVATE_KEY", jwk.d!);
  vi.stubEnv("VAPID_SUBJECT", "mailto:alerts@example.test");
}

// SE-1. A read-only member names any https URL as their "device"; the server
// then POSTs to it, with the deployment's VAPID token, on every urgent alert.
const INTERNAL = [
  "https://127.0.0.1:8443/admin",
  "https://169.254.169.254/latest/meta-data/",
  "https://[::1]:3210/api/",
  "https://10.0.0.5/internal",
  "https://attacker.example.test/collect?program=demo",
];

it("SE-1: a member cannot make the server send requests to hosts that are not push services", async () => {
  const world = await seedAlertProgram();
  vi.useFakeTimers();
  await stubVapid();
  const accepted: string[] = [];
  for (const endpoint of INTERNAL)
    await world.reader
      .mutation(api.pushSubscriptions.subscribe, sub(endpoint))
      .then(() => accepted.push(endpoint))
      .catch(() => undefined);
  const request = vi
    .fn<typeof fetch>()
    .mockImplementation(async () => new Response(null, { status: 201 }));
  vi.stubGlobal("fetch", request);
  await world.t.action(internal.urgentAlerts.sendImmediate, {
    programUuid: DEMO_PROGRAM,
  });
  await world.t.finishAllScheduledFunctions(vi.runAllTimers);
  const fetched = request.mock.calls.map(([url]) => String(url));
  console.log("SE-1 accepted endpoints:", accepted);
  console.log("SE-1 server fetched:", fetched);
  expect(accepted).toEqual([]);
  expect(fetched).toEqual([]);
});

// SE-2. Signing out ends the session but the device keeps being alerted for
// the signed-out account: nothing removes the subscription.
it("SE-2: a device stops receiving an account's alerts once that account signs out of it", async () => {
  const world = await seedAlertProgram();
  vi.useFakeTimers();
  await stubVapid();
  await world.a.mutation(
    api.pushSubscriptions.subscribe,
    sub("https://fcm.googleapis.com/send/shared-hangar-tablet"),
  );
  await world.a.action(api.auth.signOut, {});
  await expect(
    world.a.query(api.operations.snapshot, {}),
  ).resolves.toBeNull();
  const request = vi
    .fn<typeof fetch>()
    .mockImplementation(async () => new Response(null, { status: 201 }));
  vi.stubGlobal("fetch", request);
  const result = await world.t.action(internal.urgentAlerts.sendImmediate, {
    programUuid: DEMO_PROGRAM,
  });
  await world.t.finishAllScheduledFunctions(vi.runAllTimers);
  const rows = await world.t.run((ctx) =>
    ctx.db.query("pushSubscriptions").collect(),
  );
  console.log("SE-2 after sign-out:", {
    pushed: result.pushed,
    requests: request.mock.calls.length,
    rows: rows.length,
  });
  expect(request).not.toHaveBeenCalled();
});
