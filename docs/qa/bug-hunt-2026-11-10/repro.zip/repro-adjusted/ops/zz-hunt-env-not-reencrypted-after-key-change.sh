#!/usr/bin/env bash
# OP-1 repro. Usage: bash zz-hunt-env-not-reencrypted-after-key-change.sh <checkout>
# Runs scripts/backup/nightly.sh twice against a fake Convex CLI and a folder
# bucket: night 1 with age key A, night 2 with key B ("Changing the backup key"
# in docs/runbooks/backup-restore.md, step 2). The environment variables did not
# change, so night 2 uploads no env/ copy: the only env/ copy opens with key A.
set -euo pipefail
checkout=${1:-$PWD}
script="$checkout/scripts/backup/nightly.sh"
tmp=$(mktemp -d); trap 'rm -rf -- "$tmp"' EXIT
bin="$tmp/bin"; mkdir -p "$bin" "$tmp/r2/angelone-backups" "$tmp/run"
age-keygen -o "$tmp/keyA.txt" 2>/dev/null; age-keygen -o "$tmp/keyB.txt" 2>/dev/null
pubA=$(age-keygen -y "$tmp/keyA.txt"); pubB=$(age-keygen -y "$tmp/keyB.txt")
printf 'CREDENTIALS_ENCRYPTION_KEY=fake\nSITE_URL=https://app.example.org\n' >"$tmp/env.txt"
cat >"$bin/npx" <<'FAKE'
#!/usr/bin/env bash
set -euo pipefail
shift
case "$1" in
  --version) echo 1.49.0 ;;
  export) src=$(mktemp -d); mkdir -p "$src/users" "$src/_storage"; : >"$src/_storage/documents.jsonl"; echo '{"_id":"u1"}' >"$src/users/documents.jsonl"; (cd "$src" && zip -qrX "$4" .); rm -rf "$src" ;;
  env) cat "$FAKE_ROOT/env.txt" ;;
  run) echo null ;;
esac
FAKE
cat >"$bin/aws" <<'FAKE'
#!/usr/bin/env bash
set -euo pipefail
pos=(); declare -A opt=()
while (($#)); do case "$1" in
  --no-paginate|--only-show-errors|--no-progress) shift ;;
  --*) opt[${1#--}]=$2; shift 2 ;;
  *) pos+=("$1"); shift ;; esac; done
root="$FAKE_ROOT/r2"
case "${pos[0]} ${pos[1]}" in
  "s3 cp") rest=${pos[3]#s3://}; mkdir -p "$(dirname "$root/$rest")"; cp "${pos[2]}" "$root/$rest" ;;
  "s3api head-object") f="$root/${opt[bucket]}/${opt[key]}"; [[ -f "$f" ]] || { echo "An error occurred (404) when calling the HeadObject operation: Not Found" >&2; exit 254; }; wc -c <"$f" | tr -d ' ' ;;
  "s3api get-object") cp "$root/${opt[bucket]}/${opt[key]}" "${pos[2]}"; echo '{}' ;;
  "s3api list-objects-v2") d="$root/${opt[bucket]}/${opt[prefix]}"; if [[ -d "$d" ]]; then echo 1; else echo 0; fi ;;
esac
FAKE
chmod +x "$bin/npx" "$bin/aws"
night() { # night <public key>
  sleep 1.1
  env -i PATH="$bin:$PATH" HOME="$HOME" TMPDIR="$tmp/run" FAKE_ROOT="$tmp" GITHUB_SHA=test \
    CONVEX_DEPLOY_KEY="prod:fake|key" BACKUP_AGE_PUBLIC_KEY="$1" R2_ACCOUNT_ID=0123456789abcdef0123456789abcdef \
    R2_ACCESS_KEY_ID=id R2_SECRET_ACCESS_KEY=secret bash "$script" >"$tmp/out.txt" 2>&1 || { cat "$tmp/out.txt"; exit 2; }
  grep -i "environment variables" "$tmp/out.txt" || true
}
night "$pubA"
night "$pubB"   # the operator changed BACKUP_AGE_PUBLIC_KEY and ran the workflow by hand
opens_with_b=0
for f in "$tmp"/r2/angelone-backups/env/*.age; do
  if age -d -i "$tmp/keyB.txt" "$f" >/dev/null 2>&1; then opens_with_b=1; fi
done
echo "env/ objects: $(ls "$tmp"/r2/angelone-backups/env | wc -l); daily objects: $(find "$tmp"/r2/angelone-backups/daily -name '*.zip.age' | wc -l)"
if [[ $opens_with_b == 0 ]]; then
  echo "REPRODUCED: after the key change no env/ copy can be decrypted with the new key; the environment variables are only encrypted to the old key"
  exit 1
fi
echo "NOT REPRODUCED"
