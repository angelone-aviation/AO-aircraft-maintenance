/**
 * Responsibility: Bug-hunt 2026-11-10 repro PT-7: the board view (totalled on
 *   the server, in UTC) and the Costs screen (totalled in the browser's zone)
 *   must put an issued part in the same year.
 * Layer: Test. Vitest suite; asserts the CORRECT behaviour, so it fails while
 *   the bug exists.
 * Dependencies: src/domain/boardView.ts, costs.ts; src/data/demo.ts (seed).
 *
 * Run: cp <this file> src/domain/ && npx vitest run src/domain/zz-hunt-pt-cost-period.test.ts
 */
import { afterEach, expect, it } from "vitest";
import { demoSnapshot } from "../data/demo";
import { boardCostTotals } from "./boardView";
import { budgetStatus } from "./costs";
import type { Snapshot } from "./model";

const zone = process.env.TZ;
afterEach(() => {
  process.env.TZ = zone;
});

it("PT-7 (adjusted A, undated issue): the board view and the Costs screen agree on the year", () => {
  const s = demoSnapshot();
  const plane = s.aircraft[0].uuid;
  const order = { uuid: "wo", aircraftUuid: plane, dateOpened: "2026-12-30" };
  s.workOrders = [order as unknown as NonNullable<Snapshot["workOrders"]>[number]];
  s.costs = [];
  s.management = [
    ...(s.management ?? []),
    {
      kind: "stock",
      uuid: "lot",
      version: 1,
      programUuid: s.aircraft.find((a) => a.uuid === plane)!.programUuid,
      partNumber: "CYL-1",
      description: "Cylinder",
      category: "part",
      condition: "new",
      locationUuid: "store",
      quantity: 0,
      minimum: 0,
      alternates: "",
      cost: 5000,
    },
  ];
  // 19:00 on 31 Dec 2026 in Chicago, which is 01:00 on 1 Jan 2027 in UTC.
  const issuedAt = Date.parse("2027-01-01T01:00:00Z");
  s.partsRequests = [
    {
      uuid: "req",
      source: { kind: "workTask", uuid: "task", workOrderUuid: order.uuid },
      lines: [{ uuid: "rl", partNumber: "CYL-1", description: "Cylinder" }],
      issues: [
        { lineUuid: "rl", stockUuid: "lot", quantity: 1, at: issuedAt, actorId: "a" },
      ],
    } as unknown as NonNullable<Snapshot["partsRequests"]>[number],
  ];

  // The administrator's Costs screen runs in the browser.
  process.env.TZ = "America/Chicago";
  const costsScreen2026 = budgetStatus(s, plane, 2026).actualCents;
  // The board member's totals are computed by the Convex server, in UTC.
  process.env.TZ = "UTC";
  const board2027 = boardCostTotals(s, "2027-01-15").find(
    (c) => c.aircraftUuid === plane,
  )!.yearCents;

  process.env.TZ = "America/Chicago";
  const costsScreen2027 = budgetStatus(s, plane, 2027).actualCents;
  // Adjusted per fixes/parts.md PT-7: an issue stored without a date counts
  // on its UTC date on every screen, so the expectation is agreement.
  expect({ costsScreen2026, costsScreen2027 }).toEqual({ costsScreen2026: 0, costsScreen2027: board2027 });
  expect(board2027).toBe(500000);
});

it("PT-7 (adjusted B, issue carrying its local date): counted in 2026 on both screens", () => {
  const s = demoSnapshot();
  const plane = s.aircraft[0].uuid;
  const order = { uuid: "wo", aircraftUuid: plane, dateOpened: "2026-12-30" };
  s.workOrders = [order as unknown as NonNullable<Snapshot["workOrders"]>[number]];
  s.costs = [];
  s.management = [
    ...(s.management ?? []),
    {
      kind: "stock",
      uuid: "lot",
      version: 1,
      programUuid: s.aircraft.find((a) => a.uuid === plane)!.programUuid,
      partNumber: "CYL-1",
      description: "Cylinder",
      category: "part",
      condition: "new",
      locationUuid: "store",
      quantity: 0,
      minimum: 0,
      alternates: "",
      cost: 5000,
    },
  ];
  // 19:00 on 31 Dec 2026 in Chicago, which is 01:00 on 1 Jan 2027 in UTC.
  const issuedAt = Date.parse("2027-01-01T01:00:00Z");
  s.partsRequests = [
    {
      uuid: "req",
      source: { kind: "workTask", uuid: "task", workOrderUuid: order.uuid },
      lines: [{ uuid: "rl", partNumber: "CYL-1", description: "Cylinder" }],
      issues: [
        { lineUuid: "rl", stockUuid: "lot", quantity: 1, at: issuedAt, actorId: "a", date: "2026-12-31" },
      ],
    } as unknown as NonNullable<Snapshot["partsRequests"]>[number],
  ];

  // The administrator's Costs screen runs in the browser.
  process.env.TZ = "America/Chicago";
  const costsScreen2026 = budgetStatus(s, plane, 2026).actualCents;
  // The board member's totals are computed by the Convex server, in UTC.
  process.env.TZ = "UTC";
  const board2027 = boardCostTotals(s, "2027-01-15").find(
    (c) => c.aircraftUuid === plane,
  )!.yearCents;

  expect(costsScreen2026).toBe(500000);
  // Already counted in 2026 on the Costs screen, so not again in 2027.
  expect(board2027).toBe(0);
});
